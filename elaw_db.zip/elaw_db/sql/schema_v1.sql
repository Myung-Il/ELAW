-- =============================================================
--  ELAW Platform — MySQL 8.x 전체 스키마 v1.0
--  작성자 : DB/AI 담당 (오)
--  작성일 : 2026-03-01
--  Sprint  : 1  (P0 전체 테이블 확정)
--
--  실행 방법:
--    mysql -u root -p elaw_db < schema_v1.sql
--
--  주의사항:
--    · MySQL 8.x 이상 필수 (JSON 컬럼, ENUM 타입)
--    · CHARACTER SET utf8mb4 (이모지·한글 완전 지원)
--    · 테이블 삭제 순서는 FK 역방향으로 DROP
-- =============================================================

-- 데이터베이스 생성
CREATE DATABASE IF NOT EXISTS elaw_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE elaw_db;

-- 기존 테이블 DROP (개발 초기 재설치용, 운영에서는 절대 사용 금지)
-- 뷰 먼저 DROP → 자식 테이블 → 부모 테이블 순서
SET FOREIGN_KEY_CHECKS = 0;
DROP VIEW  IF EXISTS v_user_solve_summary;
DROP VIEW  IF EXISTS v_platform_stats;
DROP TABLE IF EXISTS ai_logs;
DROP TABLE IF EXISTS matches;
DROP TABLE IF EXISTS job_postings;
DROP TABLE IF EXISTS portfolios;
DROP TABLE IF EXISTS posts;
DROP TABLE IF EXISTS platform_links;
DROP TABLE IF EXISTS learning_stats;
DROP TABLE IF EXISTS solve_history;
DROP TABLE IF EXISTS curricula;
DROP TABLE IF EXISTS user_goals;
DROP TABLE IF EXISTS companies;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS schema_versions;
SET FOREIGN_KEY_CHECKS = 1;

-- =============================================================
-- 참고: DESC 인덱스 (idx_solve_user_solved_at 등)는 MySQL 8.0.13+ 전용
--       구버전 사용 시 DESC 키워드 제거 후 실행
-- =============================================================

-- =============================================================
-- [1] users — 통합 사용자 테이블 (학생·기업·관리자 공통)
-- =============================================================
CREATE TABLE users (
  id              BIGINT UNSIGNED     NOT NULL AUTO_INCREMENT,
  email           VARCHAR(255)        NOT NULL,
  password_hash   VARCHAR(255)        NOT NULL COMMENT 'bcrypt 해시',
  name            VARCHAR(100)        NOT NULL,
  role            ENUM(
                    'student',   
                    'company',   
                    'admin'      
                  )                   NOT NULL DEFAULT 'student',
  phone           VARCHAR(20)         NULL,
  is_active       TINYINT(1)          NOT NULL DEFAULT 1  COMMENT '계정 활성 여부',
  ai_consent      TINYINT(1)          NOT NULL DEFAULT 0  COMMENT 'AI 이용 동의',
  privacy_consent TINYINT(1)          NOT NULL DEFAULT 0  COMMENT '개인정보 수집 동의',
  created_at      DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP
                                               ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  UNIQUE KEY uq_users_email (email),
  KEY idx_users_role (role),
  KEY idx_users_created_at (created_at)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci
  COMMENT='통합 사용자 계정 (학생/기업/관리자)';

-- =============================================================
-- [2] companies — 기업 회원 프로필
--     users.role = 'company' 인 경우 1:1 대응
-- =============================================================
CREATE TABLE companies (
  id          BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT,
  user_id     BIGINT UNSIGNED  NOT NULL COMMENT 'FK → users.id',
  name        VARCHAR(200)     NOT NULL,
  industry    VARCHAR(100)     NULL  COMMENT '업종 (IT, 제조, 금융 등)',
  description TEXT             NULL  COMMENT '기업 소개',
  logo_url    VARCHAR(500)     NULL,
  website_url VARCHAR(500)     NULL,
  is_approved TINYINT(1)       NOT NULL DEFAULT 0 COMMENT '관리자 승인 여부',
  approved_at DATETIME         NULL,
  created_at  DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP
                                        ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  UNIQUE KEY uq_companies_user_id (user_id),
  KEY idx_companies_approved (is_approved),
  CONSTRAINT fk_companies_user
    FOREIGN KEY (user_id) REFERENCES users(id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci
  COMMENT='기업 회원 프로필 (관리자 승인 필요)';

-- =============================================================
-- [3] platform_links — 외부 플랫폼 연동 계정
--     백준·GitHub·프로그래머스 아이디/토큰 관리
-- =============================================================
CREATE TABLE platform_links (
  id            BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT,
  user_id       BIGINT UNSIGNED  NOT NULL,
  platform      ENUM(
                  'baekjoon',
                  'github',
                  'programmers'
                )                NOT NULL,
  external_id   VARCHAR(200)     NOT NULL COMMENT '플랫폼 내 username / handle',
  access_token  VARCHAR(500)     NULL  COMMENT 'OAuth 토큰 (AES-256 암호화 저장)',
  token_expires DATETIME         NULL,
  last_synced   DATETIME         NULL  COMMENT '마지막 데이터 수집 시각',
  is_active     TINYINT(1)       NOT NULL DEFAULT 1,
  created_at    DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP
                                          ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  UNIQUE KEY uq_platform_links_user_platform (user_id, platform),
  KEY idx_platform_links_synced (last_synced),
  CONSTRAINT fk_platform_links_user
    FOREIGN KEY (user_id) REFERENCES users(id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci
  COMMENT='외부 플랫폼 연동 계정 (백준/GitHub/프로그래머스)';

-- =============================================================
-- [4] user_goals — 목표 조사 결과
--     가입 후 목표 조사 페이지에서 입력한 정보
-- =============================================================
CREATE TABLE user_goals (
  id             BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT,
  user_id        BIGINT UNSIGNED  NOT NULL,
  goal_type      ENUM('study', 'job') NOT NULL COMMENT '공부 / 취업',
  field          VARCHAR(100)     NULL  COMMENT '컴퓨터, 전기, 조선, 토목, 건축 등',
  job_role       VARCHAR(100)     NULL  COMMENT '백엔드, AI 개발자, 데이터 엔지니어 등',
  start_date     DATE             NULL,
  end_date       DATE             NULL,
  mid_eval_date  DATE             NULL  COMMENT '중간 평가일',
  duration_weeks TINYINT UNSIGNED NULL  COMMENT '커리큘럼 기간(주)',
  is_active      TINYINT(1)       NOT NULL DEFAULT 1 COMMENT '현재 활성 목표',
  created_at     DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at     DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP
                                           ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  KEY idx_user_goals_user_id (user_id),
  KEY idx_user_goals_active (user_id, is_active),
  CONSTRAINT fk_user_goals_user
    FOREIGN KEY (user_id) REFERENCES users(id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci
  COMMENT='사용자 목표 조사 결과 (공부/취업, 분야, 직무, 기간)';

-- =============================================================
-- [5] curricula — Gemini 생성 커리큘럼
--     user_goals 기반으로 AI가 생성한 주차별 학습 계획 JSON
-- =============================================================
CREATE TABLE curricula (
  id            BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT,
  goal_id       BIGINT UNSIGNED  NOT NULL COMMENT 'FK → user_goals.id',
  user_id       BIGINT UNSIGNED  NOT NULL COMMENT 'FK → users.id (조회 편의)',
  content_json  JSON             NOT NULL COMMENT 'Gemini 생성 커리큘럼 전체 구조',
  version       TINYINT UNSIGNED NOT NULL DEFAULT 1 COMMENT '재생성 시 증가',
  is_active     TINYINT(1)       NOT NULL DEFAULT 1 COMMENT '현재 사용 중인 커리큘럼',
  generated_at  DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'AI 생성 시각',
  created_at    DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,

  -- content_json 구조 예시:
  -- {
  --   "total_weeks": 8,
  --   "field": "컴퓨터",
  --   "job_role": "백엔드 개발자",
  --   "weeks": [
  --     {
  --       "week": 1,
  --       "theme": "Python 기초 & 배열·정렬",
  --       "tasks": ["리스트 조작 실습", "버블정렬 구현", "백준 #2750 풀이"],
  --       "recommended_problems": ["2750", "1181", "10989"],
  --       "estimated_hours": 8
  --     }
  --   ]
  -- }

  PRIMARY KEY (id),
  KEY idx_curricula_user_active (user_id, is_active),
  KEY idx_curricula_goal (goal_id),
  CONSTRAINT fk_curricula_goal
    FOREIGN KEY (goal_id) REFERENCES user_goals(id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_curricula_user
    FOREIGN KEY (user_id) REFERENCES users(id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci
  COMMENT='AI(Gemini) 생성 개인 맞춤 커리큘럼 JSON';

-- =============================================================
-- [6] solve_history — 문제 풀이 이력 원본
--     백준·프로그래머스·자체 문제 풀이 기록
-- =============================================================
CREATE TABLE solve_history (
  id             BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT,
  user_id        BIGINT UNSIGNED  NOT NULL,
  platform       ENUM(
                   'baekjoon',
                   'programmers',
                   'w3schools',
                   'custom'        
                 )                NOT NULL,
  problem_id     VARCHAR(50)      NOT NULL COMMENT '플랫폼 내 문제 번호/코드',
  problem_title  VARCHAR(300)     NULL,
  status         ENUM(
                   'solved',
                   'failed',
                   'partial'
                 )                NOT NULL,
  language       VARCHAR(50)      NULL  COMMENT 'Python, Java, C++, JavaScript 등',
  algo_tags      JSON             NULL  COMMENT '["정렬","DP","그래프"] — 배열',
  difficulty     VARCHAR(30)      NULL  COMMENT 'Bronze5, Silver3, Level2 등',
  time_spent_min SMALLINT UNSIGNED NULL  COMMENT '풀이 소요 시간(분) — 선택적, 0~32767분',
  solved_at      DATETIME         NOT NULL COMMENT '실제 풀이 완료 시각',
  source         ENUM(
                   'api',          
                   'crawl',        
                   'manual'        
                 )                NOT NULL DEFAULT 'api',
  created_at     DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  -- 동일 사용자·플랫폼·문제 중복 방지
  UNIQUE KEY uq_solve_user_platform_problem (user_id, platform, problem_id),
  KEY idx_solve_user_solved_at (user_id, solved_at DESC),
  KEY idx_solve_platform (platform),
  KEY idx_solve_language (language),
  KEY idx_solve_difficulty (difficulty),
  CONSTRAINT fk_solve_history_user
    FOREIGN KEY (user_id) REFERENCES users(id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci
  COMMENT='외부 플랫폼 및 자체 문제 풀이 이력 원본 데이터';

-- =============================================================
-- [7] learning_stats — 언어·알고리즘 태그별 집계 통계
--     solve_history 를 매일 배치로 집계하여 저장
--     (대시보드·레이더 차트 데이터 소스)
-- =============================================================
CREATE TABLE learning_stats (
  id             BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT,
  user_id        BIGINT UNSIGNED  NOT NULL,
  stat_type      ENUM('language', 'algo_tag') NOT NULL,
  stat_key       VARCHAR(100)     NOT NULL COMMENT '"Python" 또는 "정렬"',
  total_count    INT UNSIGNED     NOT NULL DEFAULT 0 COMMENT '총 시도 수',
  solved_count   INT UNSIGNED     NOT NULL DEFAULT 0 COMMENT '정답 수',
  failed_count   INT UNSIGNED     NOT NULL DEFAULT 0 COMMENT '오답 수',
  correct_rate   FLOAT            NULL     COMMENT 'solved_count / total_count * 100',
  last_solved_at DATETIME         NULL     COMMENT '해당 키로 마지막 풀이 시각',
  updated_at     DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP
                                           ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  -- 사용자·타입·키 조합 고유 (UPSERT 기준)
  UNIQUE KEY uq_stats_user_type_key (user_id, stat_type, stat_key),
  KEY idx_stats_user_id (user_id),
  KEY idx_stats_correct_rate (user_id, correct_rate),
  CONSTRAINT fk_learning_stats_user
    FOREIGN KEY (user_id) REFERENCES users(id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci
  COMMENT='언어/알고리즘 태그별 집계 통계 (배치 갱신, 대시보드 데이터 소스)';

-- =============================================================
-- [8] portfolios — 자동 생성 포트폴리오
-- =============================================================
CREATE TABLE portfolios (
  id             BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT,
  user_id        BIGINT UNSIGNED  NOT NULL,
  title          VARCHAR(300)     NULL     DEFAULT '나의 개발자 포트폴리오',
  summary_text   TEXT             NULL     COMMENT 'Gemini 생성 역량 요약 (1~2문단)',
  content_json   JSON             NULL     COMMENT '섹션별 내용 구조',
  public_slug    VARCHAR(120)     NULL     COMMENT '공개 URL: /portfolio/{slug}',
  pdf_path       VARCHAR(500)     NULL     COMMENT '서버 내 PDF 파일 경로',
  language       ENUM('ko', 'en') NOT NULL DEFAULT 'ko',
  version        TINYINT UNSIGNED NOT NULL DEFAULT 1,
  is_public      TINYINT(1)       NOT NULL DEFAULT 1 COMMENT '공개 여부',
  created_at     DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at     DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP
                                           ON UPDATE CURRENT_TIMESTAMP,

  -- content_json 구조 예시:
  -- {
  --   "sections": [
  --     { "type": "summary",  "title": "자기소개", "content": "..." },
  --     { "type": "skills",   "title": "기술 스택", "items": ["Python","Django","MySQL"] },
  --     { "type": "stats",    "title": "학습 통계", "solve_count": 312, "top_lang": "Python" },
  --     { "type": "projects", "title": "프로젝트", "items": [ { "name":"ELAW", ... } ] }
  --   ]
  -- }

  PRIMARY KEY (id),
  UNIQUE KEY uq_portfolios_slug (public_slug),
  KEY idx_portfolios_user_id (user_id),
  KEY idx_portfolios_public (is_public, created_at DESC),
  CONSTRAINT fk_portfolios_user
    FOREIGN KEY (user_id) REFERENCES users(id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci
  COMMENT='AI 자동 생성 포트폴리오 (웹/PDF)';

-- =============================================================
-- [9] job_postings — 기업 채용 공고
-- =============================================================
CREATE TABLE job_postings (
  id               BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT,
  company_id       BIGINT UNSIGNED  NOT NULL COMMENT 'FK → companies.id',
  title            VARCHAR(300)     NOT NULL,
  description      TEXT             NULL,
  required_skills  JSON             NULL  COMMENT '["Python","Django","MySQL"]',
  preferred_skills JSON             NULL  COMMENT '우대 기술 스택',
  job_role         VARCHAR(100)     NULL  COMMENT '백엔드, AI, 데이터 엔지니어 등',
  career_level     ENUM(
                     'new',         
                     'junior',      
                     'senior',      
                     'any'
                   )                NOT NULL DEFAULT 'any',
  deadline         DATE             NULL,
  is_active        TINYINT(1)       NOT NULL DEFAULT 1,
  view_count       INT UNSIGNED     NOT NULL DEFAULT 0,
  created_at       DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at       DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP
                                             ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  KEY idx_job_postings_company (company_id, is_active),
  KEY idx_job_postings_role (job_role),
  KEY idx_job_postings_deadline (deadline, is_active),
  CONSTRAINT fk_job_postings_company
    FOREIGN KEY (company_id) REFERENCES companies(id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci
  COMMENT='기업 채용 공고';

-- =============================================================
-- [10] matches — AI 매칭 결과 및 지원 현황
-- =============================================================
CREATE TABLE matches (
  id            BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT,
  user_id       BIGINT UNSIGNED  NOT NULL,
  posting_id    BIGINT UNSIGNED  NOT NULL COMMENT 'FK → job_postings.id',
  match_score   FLOAT            NULL     COMMENT 'AI 계산 매칭 점수 (0~100)',
  status        ENUM(
                  'recommended', 
                  'viewed',      
                  'scrapped',    
                  'applied',     
                  'rejected'     
                )                NOT NULL DEFAULT 'recommended',
  applied_at    DATETIME         NULL     COMMENT '지원 완료 시각',
  created_at    DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP
                                          ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  UNIQUE KEY uq_matches_user_posting (user_id, posting_id),
  KEY idx_matches_user_score (user_id, match_score DESC),
  KEY idx_matches_posting_status (posting_id, status),
  KEY idx_matches_status (status),
  CONSTRAINT fk_matches_user
    FOREIGN KEY (user_id) REFERENCES users(id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_matches_posting
    FOREIGN KEY (posting_id) REFERENCES job_postings(id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci
  COMMENT='AI 채용 매칭 결과 및 지원 현황 추적';

-- =============================================================
-- [11] posts — 게시판 (공지·대회·이벤트)
-- =============================================================
CREATE TABLE posts (
  id          BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT,
  author_id   BIGINT UNSIGNED  NOT NULL COMMENT 'FK → users.id (관리자만 작성)',
  category    ENUM(
                'notice',     
                'contest',    
                'event'       
              )                NOT NULL,
  title       VARCHAR(300)     NOT NULL,
  content     TEXT             NOT NULL,
  is_pinned   TINYINT(1)       NOT NULL DEFAULT 0 COMMENT '상단 고정',
  view_count  INT UNSIGNED     NOT NULL DEFAULT 0,
  created_at  DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP
                                        ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  KEY idx_posts_category_date (category, created_at DESC),
  KEY idx_posts_pinned (is_pinned, created_at DESC),
  CONSTRAINT fk_posts_author
    FOREIGN KEY (author_id) REFERENCES users(id)
    ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci
  COMMENT='게시판 (공지/대회/이벤트) — 관리자만 작성';

-- =============================================================
-- [12] ai_logs — Gemini API 호출 이력
--     디버깅, 비용 추적, 에러 분석용
-- =============================================================
CREATE TABLE ai_logs (
  id             BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT,
  user_id        BIGINT UNSIGNED  NULL  COMMENT 'FK → users.id (배치 작업은 NULL)',
  feature        ENUM(
                   'curriculum',      
                   'weakness',        
                   'recommendation',  
                   'portfolio',       
                   'matching',        
                   'problem_gen'      
                 )                NOT NULL,
  prompt_tokens  INT UNSIGNED     NULL  COMMENT '입력 토큰 수',
  output_tokens  INT UNSIGNED     NULL  COMMENT '출력 토큰 수',
  latency_ms     INT UNSIGNED     NULL  COMMENT 'API 응답 지연(ms)',
  status         ENUM(
                   'success',
                   'error',
                   'timeout',
                   'cached'           
                 )                NOT NULL DEFAULT 'success',
  error_message  VARCHAR(500)     NULL,
  created_at     DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  KEY idx_ai_logs_user_feature (user_id, feature),
  KEY idx_ai_logs_created_at (created_at DESC),
  KEY idx_ai_logs_status (status),
  CONSTRAINT fk_ai_logs_user
    FOREIGN KEY (user_id) REFERENCES users(id)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci
  COMMENT='Gemini API 호출 이력 (비용 추적 및 디버깅)';

-- =============================================================
-- 관리자용 통계 뷰 (P3 — 미리 정의만, 배포 시 적용)
-- =============================================================

-- 사용자별 전체 풀이 요약 뷰
CREATE OR REPLACE VIEW v_user_solve_summary AS
SELECT
  u.id          AS user_id,
  u.name,
  u.email,
  COUNT(sh.id)                                                        AS total_attempts,
  COALESCE(SUM(sh.status = 'solved'), 0)                              AS total_solved,
  CASE
    WHEN COUNT(sh.id) = 0 THEN NULL
    ELSE ROUND(SUM(sh.status = 'solved') / COUNT(sh.id) * 100, 1)
  END                                                                  AS overall_correct_rate,
  COUNT(DISTINCT sh.language)                                          AS languages_used,
  MAX(sh.solved_at)                                                    AS last_activity
FROM users u
LEFT JOIN solve_history sh ON sh.user_id = u.id
WHERE u.role = 'student'
GROUP BY u.id, u.name, u.email;

-- 플랫폼 전체 통계 뷰 (관리자 대시보드용)
CREATE OR REPLACE VIEW v_platform_stats AS
SELECT
  (SELECT COUNT(*) FROM users WHERE role = 'student' AND is_active = 1)  AS active_students,
  (SELECT COUNT(*) FROM users WHERE role = 'company' AND is_active = 1)  AS active_companies,
  (SELECT COUNT(*) FROM solve_history WHERE DATE(solved_at) = CURDATE())  AS solves_today,
  (SELECT COUNT(*) FROM job_postings WHERE is_active = 1)                AS active_postings,
  (SELECT COUNT(*) FROM matches WHERE status = 'applied')                AS total_applications,
  (SELECT COUNT(*) FROM portfolios WHERE is_public = 1)                  AS public_portfolios;

-- =============================================================
-- 스키마 버전 관리 테이블
-- =============================================================
CREATE TABLE IF NOT EXISTS schema_versions (
  version     VARCHAR(20)  NOT NULL,
  description VARCHAR(300) NOT NULL,
  applied_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (version)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO schema_versions (version, description) VALUES
  ('1.0.0', 'Initial schema — Sprint 1 전체 테이블 생성 (12 tables + 2 views)'),
  ('1.0.1', 'Bugfix — DROP VIEW 순서, time_spent_min UNSIGNED, v_user_solve_summary NULL-safe');

-- =============================================================
-- 완료 메시지
-- =============================================================
SELECT
  '✅ ELAW schema_v1.sql 적용 완료' AS message,
  COUNT(*) AS table_count
FROM information_schema.tables
WHERE table_schema = 'elaw_db'
  AND table_type = 'BASE TABLE';
