#!/bin/bash
# =============================================================
#  ELAW Platform — MySQL 백업 스크립트
#  파일    : batch/backup_mysql.sh
#  작성자  : DB/AI 담당 (오)  |  Sprint 6
#
#  실행: ELAW_DB_PASSWORD=비밀번호 ./batch/backup_mysql.sh
#  복구: gunzip -c /backup/mysql/elaw_20260322_020000.sql.gz | \
#        mysql -u elaw_user -p elaw_db
# =============================================================

set -euo pipefail

DB_NAME="elaw_db"
DB_USER="elaw_user"
DB_PASS="${ELAW_DB_PASSWORD:-}"   # .env 파일의 ELAW_DB_PASSWORD 환경변수 사용
BACKUP_DIR="/backup/mysql"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
FILENAME="${BACKUP_DIR}/elaw_${TIMESTAMP}.sql.gz"

# DB_PASS가 비어 있으면 종료
if [ -z "${DB_PASS}" ]; then
    echo "[$(date)] 오류: ELAW_DB_PASSWORD 환경변수가 설정되지 않았습니다."
    echo "사용법: ELAW_DB_PASSWORD=비밀번호 ./backup_mysql.sh"
    exit 1
fi

# 백업 디렉토리 존재 확인
if [ ! -d "${BACKUP_DIR}" ]; then
    echo "[$(date)] 오류: 백업 디렉토리가 없습니다: ${BACKUP_DIR}"
    echo "먼저 실행: sudo mkdir -p ${BACKUP_DIR} && sudo chown \$(whoami) ${BACKUP_DIR}"
    exit 1
fi

echo "[$(date)] 백업 시작: ${FILENAME}"

# mysqldump 옵션 설명:
#   --single-transaction  : InnoDB 무잠금 일관성 백업 (테이블 잠금 없음)
#   --routines            : 뷰·저장 프로시저 포함
#   --triggers            : 트리거 포함
#   --add-drop-table      : 복구 시 기존 테이블 DROP 후 CREATE
mysqldump \
    --user="${DB_USER}" \
    --password="${DB_PASS}" \
    --host=localhost \
    --single-transaction \
    --routines \
    --triggers \
    --add-drop-table \
    "${DB_NAME}" \
| gzip > "${FILENAME}"

SIZE=$(du -sh "${FILENAME}" | cut -f1)
echo "[$(date)] 백업 완료: ${FILENAME} (${SIZE})"

# 7일 초과 백업 삭제
DELETED=$(find "${BACKUP_DIR}" -name "*.sql.gz" -mtime +7 -print -delete | wc -l)
echo "[$(date)] 오래된 백업 ${DELETED}개 삭제"
