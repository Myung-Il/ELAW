"""
ELAW Platform — Redis 캐시 레이어
파일    : cache/redis_cache.py
작성자  : DB/AI 담당 (오)  |  Sprint 5

역할:
  · Gemini API 응답 캐싱 — API 비용 절감
  · 대시보드 집계 지표 캐싱 — DB 부하 감소
  · 세션/인증 토큰 저장 (Refresh Token 블랙리스트)

캐시 키 패턴 및 TTL:
  curriculum:{user_id}:{goal_hash}    1시간   커리큘럼 JSON
  weakness:{user_id}                  30분    취약점 분석 결과
  recommend:{user_id}                 15분    오늘의 추천 문제
  dashboard:{user_id}                 5분     대시보드 지표
  match_scores:{user_id}              1시간   매칭 점수 리스트
  portfolio:{user_id}:latest          2시간   최신 포트폴리오
  blacklist:token:{jti}               7일     로그아웃 토큰 블랙리스트

설치:
  pip install redis

환경변수:
  REDIS_HOST=localhost
  REDIS_PORT=6379
  REDIS_DB=0
  REDIS_PASSWORD=           (빈 값이면 인증 없음)
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
from typing import Any

logger = logging.getLogger(__name__)

# ── TTL 상수 (초)
TTL = {
    "curriculum":   3600,   # 1시간
    "weakness":     1800,   # 30분
    "recommend":     900,   # 15분
    "dashboard":     300,   #  5분
    "match_scores": 3600,   # 1시간
    "portfolio":    7200,   # 2시간
    "blacklist":  604800,   # 7일
}


class ElawCache:
    """
    ELAW 전용 Redis 캐시 클라이언트

    사용 예시:
        cache = ElawCache()

        # 저장
        cache.set_curriculum(user_id=1, goal_id=3, data={"weeks": [...]})

        # 조회 (없으면 None)
        data = cache.get_curriculum(user_id=1, goal_id=3)

        # 삭제 (커리큘럼 재생성 시)
        cache.delete("curriculum:1:*")
    """

    def __init__(self):
        self._client = None
        self._available = False
        self._connect()

    def _connect(self) -> None:
        try:
            # 실제 Redis 연결 (배포 시 활성화)
            # import redis
            # self._client = redis.Redis(
            #     host=os.environ.get("REDIS_HOST", "localhost"),
            #     port=int(os.environ.get("REDIS_PORT", 6379)),
            #     db=int(os.environ.get("REDIS_DB", 0)),
            #     password=os.environ.get("REDIS_PASSWORD") or None,
            #     decode_responses=True,
            #     socket_timeout=2,
            #     socket_connect_timeout=2,
            # )
            # self._client.ping()
            # self._available = True
            # logger.info("Redis 연결 성공")

            # 개발 환경 Mock 클라이언트
            self._client   = _MockRedis()
            self._available = True
            logger.info("Redis Mock 클라이언트 초기화 (개발 환경)")

        except Exception as e:
            self._available = False
            logger.warning(f"Redis 연결 실패 — 캐시 없이 동작: {e}")

    # ──────────────────────────────────────────────
    # 내부 GET/SET
    # ──────────────────────────────────────────────

    def _get(self, key: str) -> Any | None:
        if not self._available:
            return None
        try:
            raw = self._client.get(key)
            if raw is None:
                return None
            return json.loads(raw)
        except Exception as e:
            logger.error(f"캐시 GET 실패 [{key}]: {e}")
            return None

    def _set(self, key: str, data: Any, ttl: int) -> bool:
        if not self._available:
            return False
        try:
            self._client.setex(key, ttl, json.dumps(data, ensure_ascii=False))
            logger.debug(f"캐시 SET [{key}] TTL={ttl}s")
            return True
        except Exception as e:
            logger.error(f"캐시 SET 실패 [{key}]: {e}")
            return False

    def _del(self, key: str) -> None:
        if not self._available:
            return
        try:
            self._client.delete(key)
            logger.debug(f"캐시 DEL [{key}]")
        except Exception as e:
            logger.error(f"캐시 DEL 실패 [{key}]: {e}")

    @staticmethod
    def _goal_hash(goal_id: int) -> str:
        return hashlib.md5(str(goal_id).encode()).hexdigest()[:8]

    # ──────────────────────────────────────────────
    # ① 커리큘럼
    # ──────────────────────────────────────────────

    def get_curriculum(self, user_id: int, goal_id: int) -> dict | None:
        return self._get(f"curriculum:{user_id}:{self._goal_hash(goal_id)}")

    def set_curriculum(self, user_id: int, goal_id: int, data: dict) -> bool:
        return self._set(
            f"curriculum:{user_id}:{self._goal_hash(goal_id)}",
            data, TTL["curriculum"]
        )

    def invalidate_curriculum(self, user_id: int) -> None:
        """커리큘럼 재생성 시 캐시 무효화"""
        # 실제 Redis: SCAN으로 패턴 삭제 필요
        # keys = self._client.scan_iter(f"curriculum:{user_id}:*")
        # for k in keys: self._client.delete(k)
        logger.info(f"커리큘럼 캐시 무효화: user={user_id}")

    # ──────────────────────────────────────────────
    # ② 취약점 분석
    # ──────────────────────────────────────────────

    def get_weakness(self, user_id: int) -> dict | None:
        return self._get(f"weakness:{user_id}")

    def set_weakness(self, user_id: int, data: dict) -> bool:
        return self._set(f"weakness:{user_id}", data, TTL["weakness"])

    # ──────────────────────────────────────────────
    # ③ 추천 문제
    # ──────────────────────────────────────────────

    def get_recommendations(self, user_id: int) -> list | None:
        return self._get(f"recommend:{user_id}")

    def set_recommendations(self, user_id: int, data: list) -> bool:
        return self._set(f"recommend:{user_id}", data, TTL["recommend"])

    # ──────────────────────────────────────────────
    # ④ 대시보드
    # ──────────────────────────────────────────────

    def get_dashboard(self, user_id: int) -> dict | None:
        return self._get(f"dashboard:{user_id}")

    def set_dashboard(self, user_id: int, data: dict) -> bool:
        return self._set(f"dashboard:{user_id}", data, TTL["dashboard"])

    def invalidate_dashboard(self, user_id: int) -> None:
        """풀이 완료 이벤트 시 대시보드 캐시 즉시 만료"""
        self._del(f"dashboard:{user_id}")

    # ──────────────────────────────────────────────
    # ⑤ 매칭 점수
    # ──────────────────────────────────────────────

    def get_match_scores(self, user_id: int) -> list | None:
        return self._get(f"match_scores:{user_id}")

    def set_match_scores(self, user_id: int, data: list) -> bool:
        return self._set(f"match_scores:{user_id}", data, TTL["match_scores"])

    # ──────────────────────────────────────────────
    # ⑥ 포트폴리오
    # ──────────────────────────────────────────────

    def get_portfolio(self, user_id: int) -> dict | None:
        return self._get(f"portfolio:{user_id}:latest")

    def set_portfolio(self, user_id: int, data: dict) -> bool:
        return self._set(f"portfolio:{user_id}:latest", data, TTL["portfolio"])

    # ──────────────────────────────────────────────
    # ⑦ 토큰 블랙리스트 (로그아웃)
    # ──────────────────────────────────────────────

    def blacklist_token(self, jti: str) -> bool:
        """로그아웃한 Refresh Token JTI를 블랙리스트에 등록"""
        return self._set(f"blacklist:token:{jti}", 1, TTL["blacklist"])

    def is_token_blacklisted(self, jti: str) -> bool:
        return self._get(f"blacklist:token:{jti}") is not None

    # ──────────────────────────────────────────────
    # 유틸리티
    # ──────────────────────────────────────────────

    def health_check(self) -> bool:
        """Redis 연결 상태 확인 — 모든 예외를 캐치하여 False 반환"""
        if not self._available:
            return False
        try:
            result = self._client.ping()
            return bool(result)
        except AttributeError:
            logger.error("Redis 클라이언트가 ping 메서드를 지원하지 않음")
            return False
        except Exception as e:
            logger.warning(f"Redis health check 실패: {e}")
            self._available = False   # 이후 캐시 우회
            return False

    def flush_user(self, user_id: int) -> None:
        """
        사용자 탈퇴 또는 전체 초기화 시 해당 사용자의 모든 캐시 삭제

        curriculum 키는 goal_hash가 포함된 패턴 사용:
          curriculum:{user_id}:{8자리 hash}
        Mock에서는 keys() 스캔으로 처리, 실제 Redis에서는 SCAN 명령 사용
        """
        if not self._available:
            return
        try:
            # 실제 Redis: SCAN으로 패턴 매칭 삭제
            # for key in self._client.scan_iter(f"*:{user_id}:*"):
            #     self._client.delete(key)
            # for key in self._client.scan_iter(f"*:{user_id}"):
            #     self._client.delete(key)

            # MockRedis: keys() 전체 스캔 후 user_id 포함 키 삭제
            prefix_str = f":{user_id}"
            all_keys = self._client.keys("*")
            deleted = 0
            for key in all_keys:
                if f":{user_id}:" in key or key.endswith(prefix_str):
                    self._del(key)
                    deleted += 1

            # 명시적 고정 키도 추가 삭제
            fixed_keys = [
                f"weakness:{user_id}", f"recommend:{user_id}",
                f"dashboard:{user_id}", f"match_scores:{user_id}",
                f"portfolio:{user_id}:latest",
            ]
            for k in fixed_keys:
                self._del(k)

            logger.info(f"user={user_id} 캐시 {deleted}개 삭제 완료")
        except Exception as e:
            logger.error(f"flush_user 실패 user={user_id}: {e}")


# ──────────────────────────────────────────────────────────────
# 개발 환경 Mock Redis (메모리 딕셔너리)
# ──────────────────────────────────────────────────────────────

class _MockRedis:
    """Redis 없이 개발 가능한 인메모리 Mock"""

    def __init__(self):
        self._store: dict[str, str] = {}

    def get(self, key: str) -> str | None:
        return self._store.get(key)

    def setex(self, key: str, ttl: int, value: str) -> None:
        self._store[key] = value        # TTL 무시 (개발용)

    def delete(self, *keys) -> None:
        for k in keys:
            self._store.pop(k, None)

    def ping(self) -> bool:
        return True

    def keys(self, pattern: str = "*") -> list[str]:
        """패턴 인자는 MockRedis에서 무시 — 전체 키 반환 (개발 전용)"""
        return list(self._store.keys())


# ──────────────────────────────────────────────────────────────
# 동작 확인
# ──────────────────────────────────────────────────────────────
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s [%(levelname)s] %(message)s")

    cache = ElawCache()
    print(f"\nRedis 상태: {'연결됨' if cache.health_check() else '연결 실패'}")

    # 커리큘럼 캐시
    sample = {"total_weeks": 8, "weeks": [{"week": 1, "theme": "Python 기초"}]}
    cache.set_curriculum(user_id=1, goal_id=3, data=sample)
    result = cache.get_curriculum(user_id=1, goal_id=3)
    print(f"\n① 커리큘럼 캐시 HIT: {result['total_weeks']}주 커리큘럼")

    miss = cache.get_curriculum(user_id=999, goal_id=1)
    print(f"   캐시 MISS: {miss}")

    # 대시보드 캐시 & 무효화
    dashboard = {"total_solved": 312, "this_week": 18, "streak_days": 7}
    cache.set_dashboard(user_id=1, data=dashboard)
    print(f"\n② 대시보드 캐시 HIT: {cache.get_dashboard(user_id=1)}")
    cache.invalidate_dashboard(user_id=1)
    print(f"   무효화 후 MISS: {cache.get_dashboard(user_id=1)}")

    # 추천 문제
    recs = [{"id": "1463", "title": "1로 만들기"}, {"id": "9095", "title": "1,2,3 더하기"}]
    cache.set_recommendations(user_id=1, data=recs)
    print(f"\n③ 추천 문제 캐시 HIT: {len(cache.get_recommendations(user_id=1))}개 문제")

    # 토큰 블랙리스트
    jti = "abc-refresh-token-jti-12345"
    cache.blacklist_token(jti)
    print(f"\n④ 토큰 블랙리스트 등록: {cache.is_token_blacklisted(jti)}")
    print(f"   미등록 토큰 확인:    {cache.is_token_blacklisted('other-jti')}")

    # 사용자 전체 캐시 삭제
    cache.flush_user(user_id=1)
    print(f"\n⑤ 전체 삭제 후 MISS: {cache.get_curriculum(user_id=1, goal_id=3)}")
