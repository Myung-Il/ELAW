"""
ELAW Platform — AI 분석 모듈 (Gemini API 연동)
파일    : ai_module/gemini_client.py
작성자  : DB/AI 담당 (오)  |  Sprint 3

담당 기능:
  1. 커리큘럼 자동 생성
  2. 취약점 분석
  3. 포트폴리오 텍스트 생성
  4. 채용 매칭 점수 계산
  5. AI 호출 이력 기록 (ai_logs)

의존성:
  pip install google-generativeai          (Gemini SDK)
  pip install django                        (ORM 활용)

환경변수:
  GEMINI_API_KEY=your_api_key_here
"""

from __future__ import annotations

import json
import logging
import os
import time
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────
# 설정
# ──────────────────────────────────────────────────────────────

GEMINI_MODEL      = "gemini-1.5-pro"
MAX_RETRIES       = 3
RETRY_DELAY_SEC   = 2
MAX_OUTPUT_TOKENS = 4096


# ──────────────────────────────────────────────────────────────
# 데이터 클래스
# ──────────────────────────────────────────────────────────────

@dataclass
class UserProfile:
    """AI 분석에 필요한 사용자 데이터 집합"""
    user_id:       int
    name:          str
    goal_type:     str                    # 'study' | 'job'
    field:         str
    job_role:      str
    duration_weeks: int
    # learning_stats 집계
    language_stats: list[dict]            # [{"lang":"Python","solved":50,"rate":85.0}]
    algo_tag_stats: list[dict]            # [{"tag":"DP","solved":10,"rate":60.0}]
    total_solved:   int = 0
    # GitHub
    github_repos:   int = 0
    github_commits: int = 0
    top_language:   str = ""


@dataclass
class AiResult:
    """Gemini API 호출 결과"""
    feature:       str
    status:        str                    # success | error | timeout | cached
    data:          Any         = None     # 파싱된 결과물
    raw_text:      str         = ""
    prompt_tokens: int         = 0
    output_tokens: int         = 0
    latency_ms:    int         = 0
    error_message: str         = ""


# ──────────────────────────────────────────────────────────────
# Gemini 클라이언트
# ──────────────────────────────────────────────────────────────

class GeminiClient:
    """
    Gemini 1.5 Pro API 래퍼
    - 재시도 로직 (최대 3회)
    - 응답 파싱 + 유효성 검증
    - 호출 이력 → ai_logs 테이블 저장
    """

    def __init__(self):
        api_key = os.environ.get("GEMINI_API_KEY", "")
        if not api_key:
            logger.warning("GEMINI_API_KEY 환경변수가 설정되지 않았습니다.")

        # SDK 초기화 (실제 배포 시 활성화)
        # import google.generativeai as genai
        # genai.configure(api_key=api_key)
        # self._model = genai.GenerativeModel(GEMINI_MODEL)
        self._api_key = api_key

    # ── 내부: API 호출
    def _call(self, system_prompt: str, user_prompt: str, feature: str) -> AiResult:
        start = time.monotonic()
        last_error = ""

        for attempt in range(1, MAX_RETRIES + 1):
            try:
                # ── 실제 SDK 호출 코드 (배포 시 주석 해제)
                # response = self._model.generate_content(
                #     contents=[
                #         {"role": "user", "parts": [system_prompt + "\n\n" + user_prompt]}
                #     ],
                #     generation_config={"max_output_tokens": MAX_OUTPUT_TOKENS}
                # )
                # raw_text     = response.text
                # prompt_tok   = response.usage_metadata.prompt_token_count
                # output_tok   = response.usage_metadata.candidates_token_count

                # ── 개발 환경 Mock (API 키 없을 때 사용)
                raw_text   = self._mock_response(feature)
                prompt_tok = len(user_prompt.split()) * 2
                output_tok = len(raw_text.split()) * 2

                latency_ms = int((time.monotonic() - start) * 1000)
                return AiResult(
                    feature=feature, status="success",
                    raw_text=raw_text,
                    prompt_tokens=prompt_tok, output_tokens=output_tok,
                    latency_ms=latency_ms
                )

            except Exception as e:
                last_error = str(e)
                logger.warning(f"[{feature}] Gemini 호출 실패 (시도 {attempt}/{MAX_RETRIES}): {e}")
                if attempt < MAX_RETRIES:
                    time.sleep(RETRY_DELAY_SEC * attempt)

        latency_ms = int((time.monotonic() - start) * 1000)
        return AiResult(
            feature=feature, status="error",
            latency_ms=latency_ms, error_message=last_error
        )

    # ── 내부: JSON 파싱 (마크다운 코드블록 제거)
    @staticmethod
    def _parse_json(raw: str) -> dict | list | None:
        # ```json ... ``` 또는 ``` ... ``` 제거
        clean = raw.strip()
        for fence in ("```json", "```"):
            if clean.startswith(fence):
                clean = clean[len(fence):]
        if clean.endswith("```"):
            clean = clean[:-3]
        clean = clean.strip()
        try:
            return json.loads(clean)
        except json.JSONDecodeError as e:
            logger.error(f"JSON 파싱 실패: {e}\n원문: {clean[:300]}")
            return None

    # ── 내부: 개발 환경 Mock 응답
    @staticmethod
    def _mock_response(feature: str) -> str:
        mocks = {
            "curriculum": json.dumps({
                "total_weeks": 8,
                "field": "컴퓨터",
                "job_role": "백엔드 개발자",
                "weeks": [
                    {"week": 1, "theme": "Python 기초 & 배열·정렬",
                     "tasks": ["리스트·딕셔너리 실습", "버블정렬 구현", "백준 #2750"],
                     "recommended_problems": ["2750", "1181", "10989"],
                     "estimated_hours": 8},
                    {"week": 2, "theme": "스택·큐·덱",
                     "tasks": ["스택 응용 문제", "백준 #10828, #10845"],
                     "recommended_problems": ["10828", "10845", "10866"],
                     "estimated_hours": 10},
                ]
            }, ensure_ascii=False),

            "weakness": json.dumps({
                "weak_tags": [
                    {"tag": "DP",       "correct_rate": 55.0, "advice": "피보나치→LCS→배낭 문제 순서로 점진적 학습을 추천합니다."},
                    {"tag": "이분탐색", "correct_rate": 60.0, "advice": "탐색 범위 설정과 종료 조건 패턴을 반복 숙지하세요."},
                    {"tag": "트리",     "correct_rate": 62.5, "advice": "순회(전위·중위·후위)부터 시작해 트리 DP로 발전하세요."},
                ],
                "strong_tags": ["구현", "정렬", "그리디"],
                "overall_comment": "정렬·그리디는 매우 안정적입니다. DP와 이분탐색 집중 보완을 권장합니다."
            }, ensure_ascii=False),

            "portfolio": json.dumps({
                "sections": [
                    {"type": "summary",  "title": "자기소개",
                     "content": "Python을 주력으로 Django 기반 백엔드 개발에 집중하고 있습니다. 알고리즘 300문제 이상 풀이 경험으로 문제 해결 역량을 키웠습니다."},
                    {"type": "skills",   "title": "기술 스택",
                     "items": ["Python", "Django", "MySQL", "Git", "Docker"]},
                    {"type": "stats",    "title": "학습 통계",
                     "solve_count": 320, "top_lang": "Python", "top_tag": "그래프"},
                    {"type": "projects", "title": "프로젝트",
                     "items": [{"name": "ELAW", "desc": "AI 기반 학습 포트폴리오 플랫폼", "tech": ["Django", "MySQL", "Gemini"]}]}
                ]
            }, ensure_ascii=False),

            "matching": json.dumps({
                "match_score": 82.5,
                "matched_skills": ["Python", "Django", "MySQL"],
                "missing_skills": ["Docker", "Redis"],
                "comment": "핵심 스택은 부합하나 인프라 경험(Docker/Redis) 보완을 권장합니다."
            }, ensure_ascii=False),

            "recommendation": json.dumps({
                "problems": [
                    {"id": "1463", "title": "1로 만들기",    "reason": "DP 기초 패턴 연습에 적합합니다."},
                    {"id": "9095", "title": "1,2,3 더하기",  "reason": "경우의 수 DP 유형입니다."},
                    {"id": "11053","title": "가장 긴 증가하는 부분 수열", "reason": "LIS 패턴 습득에 필수적입니다."},
                ]
            }, ensure_ascii=False),
        }
        return mocks.get(feature, '{"result": "mock response"}')

    # ──────────────────────────────────────────────────────────
    # ① 커리큘럼 생성
    # ──────────────────────────────────────────────────────────
    def generate_curriculum(self, profile: UserProfile) -> AiResult:
        """
        사용자 목표 + 학습 이력 기반 주차별 커리큘럼 JSON 생성

        Returns:
            AiResult.data = {
                "total_weeks": int,
                "field": str,
                "job_role": str,
                "weeks": [ { "week":int, "theme":str, "tasks":list,
                             "recommended_problems":list, "estimated_hours":int } ]
            }
        """
        system_prompt = """당신은 개발자 교육 전문가입니다.
사용자의 학습 이력과 목표를 분석하여 개인 맞춤형 학습 커리큘럼을 JSON 형식으로 작성합니다.
반드시 아래 JSON 스키마만 출력하고, 마크다운이나 추가 설명은 포함하지 마세요.
{
  "total_weeks": <정수>,
  "field": "<분야>",
  "job_role": "<목표 직무>",
  "weeks": [
    {
      "week": <주차>,
      "theme": "<주제>",
      "tasks": ["<과제1>", "<과제2>"],
      "recommended_problems": ["<백준번호>"],
      "estimated_hours": <예상시간>
    }
  ]
}"""

        # 취약 태그 상위 3개 추출
        weak_tags = sorted(
            [s for s in profile.algo_tag_stats if s.get("rate", 100) < 70],
            key=lambda x: x["rate"]
        )[:3]
        weak_str = ", ".join(t["tag"] for t in weak_tags) if weak_tags else "없음"

        # 언어별 통계 요약
        lang_str = " / ".join(
            f"{s['lang']} {s['solved']}문제({s['rate']:.0f}%)"
            for s in sorted(profile.language_stats, key=lambda x: -x["solved"])[:3]
        )

        user_prompt = f"""
사용자 정보:
- 이름: {profile.name}
- 목표: {profile.goal_type} / 분야: {profile.field} / 직무: {profile.job_role}
- 기간: {profile.duration_weeks}주
- 총 풀이 문제 수: {profile.total_solved}문제
- 언어별 성취도: {lang_str if lang_str else '데이터 없음'}
- 취약 알고리즘 태그: {weak_str}
- GitHub 커밋 수: {profile.github_commits}

위 정보를 바탕으로 {profile.duration_weeks}주 커리큘럼을 생성해주세요.
취약 태그({weak_str})를 중점적으로 다루는 주차를 배치하고,
후반부에는 {profile.job_role} 실무 역량(프레임워크·프로젝트)을 포함하세요.
"""
        result = self._call(system_prompt, user_prompt, "curriculum")
        if result.status == "success":
            result.data = self._parse_json(result.raw_text)
        return result

    # ──────────────────────────────────────────────────────────
    # ② 취약점 분석
    # ──────────────────────────────────────────────────────────
    def analyze_weakness(self, profile: UserProfile) -> AiResult:
        """
        학습 통계 기반 취약점 분석 및 개선 제안

        Returns:
            AiResult.data = {
                "weak_tags": [ {"tag":str, "correct_rate":float, "advice":str} ],
                "strong_tags": [str],
                "overall_comment": str
            }
        """
        system_prompt = """당신은 알고리즘 교육 전문가입니다.
학습자의 알고리즘 태그별 정답률 데이터를 분석하여
취약점과 강점을 파악하고, 개선 방안을 JSON으로 제시하세요.
출력 형식:
{
  "weak_tags": [{"tag": "태그명", "correct_rate": 정답률, "advice": "구체적 개선 조언"}],
  "strong_tags": ["잘하는 태그1", "잘하는 태그2"],
  "overall_comment": "전체적인 평가 한 줄"
}"""

        stats_str = "\n".join(
            f"  - {s['tag']}: 시도 {s['total']}회, 정답 {s['solved']}회, 정답률 {s['rate']:.1f}%"
            for s in sorted(profile.algo_tag_stats, key=lambda x: x["rate"])
        )

        user_prompt = f"""
사용자 {profile.name}의 알고리즘 태그별 통계 (최근 90일):
{stats_str if stats_str else '  - 데이터 없음'}

총 {profile.total_solved}문제 풀이 완료.
취약 태그(정답률 70% 미만)와 강점 태그(정답률 85% 이상)를 분석하고
각 취약 태그에 대한 구체적인 학습 조언을 제공하세요.
"""
        result = self._call(system_prompt, user_prompt, "weakness")
        if result.status == "success":
            result.data = self._parse_json(result.raw_text)
        return result

    # ──────────────────────────────────────────────────────────
    # ③ 포트폴리오 텍스트 생성
    # ──────────────────────────────────────────────────────────
    def generate_portfolio(self, profile: UserProfile) -> AiResult:
        """
        학습 이력 기반 포트폴리오 섹션 자동 생성

        Returns:
            AiResult.data = {
                "sections": [
                    {"type": "summary",  "title": str, "content": str},
                    {"type": "skills",   "title": str, "items": [str]},
                    {"type": "stats",    "title": str, ...},
                    {"type": "projects", "title": str, "items": [...]}
                ]
            }
        """
        system_prompt = """당신은 10년 경력의 IT 채용 전문가입니다.
개발자 지망생의 학습 데이터를 바탕으로 채용 담당자에게 인상적인
포트폴리오 섹션 내용을 JSON으로 생성하세요.
출력 형식:
{
  "sections": [
    {"type": "summary",  "title": "자기소개", "content": "2~3문단 자기소개"},
    {"type": "skills",   "title": "기술 스택", "items": ["기술1", "기술2"]},
    {"type": "stats",    "title": "학습 통계", "solve_count": 숫자, "top_lang": "언어", "top_tag": "태그"},
    {"type": "projects", "title": "프로젝트", "items": [{"name":str, "desc":str, "tech":[str]}]}
  ]
}"""

        top_langs = sorted(profile.language_stats, key=lambda x: -x["solved"])[:3]
        top_tags  = sorted(profile.algo_tag_stats, key=lambda x: -x["solved"])[:5]

        user_prompt = f"""
학습자 정보:
- 이름: {profile.name}
- 목표 직무: {profile.job_role}
- 총 풀이 문제: {profile.total_solved}개
- 주력 언어: {', '.join(l['lang'] for l in top_langs)}
- 잘하는 알고리즘: {', '.join(t['tag'] for t in top_tags if t.get('rate',0) >= 75)}
- GitHub 리포지토리: {profile.github_repos}개, 커밋: {profile.github_commits}회

위 데이터를 바탕으로 {profile.job_role} 취업을 목표로 한
신입 개발자 포트폴리오 섹션을 생성하세요.
자기소개는 데이터 기반으로 구체적이고 진정성 있게 작성하세요.
"""
        result = self._call(system_prompt, user_prompt, "portfolio")
        if result.status == "success":
            result.data = self._parse_json(result.raw_text)
        return result

    # ──────────────────────────────────────────────────────────
    # ④ 채용 매칭 점수 계산
    # ──────────────────────────────────────────────────────────
    def calculate_match_score(
        self,
        profile: UserProfile,
        required_skills: list[str],
        preferred_skills: list[str],
        job_role: str
    ) -> AiResult:
        """
        지원자 역량 ↔ 채용 요구사항 매칭 점수 계산 (0~100)

        1단계: 언어·태그 기반 규칙 점수 계산
        2단계: Gemini로 보정 및 코멘트 생성

        Returns:
            AiResult.data = {
                "match_score": float (0~100),
                "matched_skills": [str],
                "missing_skills": [str],
                "comment": str
            }
        """
        # 1단계: 규칙 기반 점수
        user_langs = {s["lang"].lower() for s in profile.language_stats if s.get("solved", 0) > 0}
        req_lower  = [s.lower() for s in required_skills]
        pref_lower = [s.lower() for s in preferred_skills]

        matched_req  = [s for s in req_lower  if any(s in ul or ul in s for ul in user_langs)]
        matched_pref = [s for s in pref_lower if any(s in ul or ul in s for ul in user_langs)]

        req_score  = (len(matched_req)  / max(len(req_lower), 1))  * 60
        pref_score = (len(matched_pref) / max(len(pref_lower), 1)) * 20
        base_score = req_score + pref_score

        # 2단계: Gemini 보정
        system_prompt = """당신은 기술 채용 전문가입니다.
지원자 프로필과 채용 요구사항을 분석하여 매칭 점수와 피드백을 JSON으로 제시하세요.
{
  "match_score": <0~100 사이 소수 첫째 자리 점수>,
  "matched_skills": ["매칭된 스킬1"],
  "missing_skills": ["부족한 스킬1"],
  "comment": "한 줄 피드백"
}"""

        user_prompt = f"""
지원자: {profile.name} (목표 직무: {profile.job_role})
주력 언어·도구: {', '.join(s['lang'] for s in sorted(profile.language_stats, key=lambda x:-x['solved'])[:5])}
총 풀이 수: {profile.total_solved}문제
강점 알고리즘: {', '.join(t['tag'] for t in profile.algo_tag_stats if t.get('rate',0) >= 75)[:3]}

채용 공고 직무: {job_role}
필수 기술: {', '.join(required_skills)}
우대 기술: {', '.join(preferred_skills)}
규칙 기반 기초 점수: {base_score:.1f}점

위 기초 점수를 참고하여 최종 매칭 점수(0~100)와 피드백을 제시하세요.
"""
        result = self._call(system_prompt, user_prompt, "matching")
        if result.status == "success":
            result.data = self._parse_json(result.raw_text)
        return result

    # ──────────────────────────────────────────────────────────
    # ⑤ 문제 추천
    # ──────────────────────────────────────────────────────────
    def recommend_problems(self, profile: UserProfile) -> AiResult:
        """
        취약 태그 기반 오늘의 추천 문제 생성

        Returns:
            AiResult.data = {
                "problems": [
                    {"id": str, "title": str, "reason": str}
                ]
            }
        """
        system_prompt = """당신은 알고리즘 문제 추천 전문가입니다.
학습자의 취약 태그를 분석하여 백준 온라인 저지의 문제 번호와 추천 이유를 JSON으로 제시하세요.
{
  "problems": [
    {"id": "백준번호", "title": "문제 제목", "reason": "추천 이유"}
  ]
}
정확히 3~5개 문제를 추천하세요."""

        weak = sorted(
            [s for s in profile.algo_tag_stats if s.get("rate", 100) < 70],
            key=lambda x: x["rate"]
        )[:2]
        weak_str = ", ".join(t["tag"] for t in weak) if weak else "기초 알고리즘"

        user_prompt = f"""
학습자 정보:
- 목표 직무: {profile.job_role}
- 취약 태그: {weak_str}
- 현재 실력: {self._estimate_level(profile.total_solved)}

취약 태그({weak_str})를 보완할 수 있는 백준 문제 3~5개를 추천하세요.
현재 실력에 맞게 난이도를 조절하고, 각 문제를 추천하는 이유를 명확히 설명하세요.
"""
        result = self._call(system_prompt, user_prompt, "recommendation")
        if result.status == "success":
            result.data = self._parse_json(result.raw_text)
        return result

    @staticmethod
    def _estimate_level(total_solved: int) -> str:
        if total_solved < 30:  return "입문 (Bronze 위주)"
        if total_solved < 100: return "초급 (Silver 위주)"
        if total_solved < 300: return "중급 (Gold 진입)"
        return "고급 (Gold 이상)"


# ──────────────────────────────────────────────────────────────
# ai_logs DB 저장 헬퍼 (Django ORM 사용)
# ──────────────────────────────────────────────────────────────

def save_ai_log(result: AiResult, user_id: int | None = None) -> None:
    """
    AiResult 를 ai_logs 테이블에 저장

    Django ORM을 사용하므로 Django 앱 컨텍스트 필요:
      import django; django.setup()
    """
    try:
        # Django ORM import (배포 환경에서 활성화)
        # from core.models import AiLog, User
        # user = User.objects.get(id=user_id) if user_id else None
        # AiLog.objects.create(
        #     user=user,
        #     feature=result.feature,
        #     prompt_tokens=result.prompt_tokens,
        #     output_tokens=result.output_tokens,
        #     latency_ms=result.latency_ms,
        #     status=result.status,
        #     error_message=result.error_message or None,
        # )
        logger.info(
            f"[AI LOG] feature={result.feature} user={user_id} "
            f"status={result.status} latency={result.latency_ms}ms "
            f"tokens={result.prompt_tokens}+{result.output_tokens}"
        )
    except Exception as e:
        # ai_logs 저장 실패는 서비스 중단 없이 경고만 — 비용 추적 누락 허용
        logger.warning(f"ai_logs 저장 실패 (비용 추적 누락 가능): feature={result.feature} error={e}")


# ──────────────────────────────────────────────────────────────
# Django View에서 사용하는 서비스 함수
# ──────────────────────────────────────────────────────────────

class AiService:
    """
    백엔드 View → AiService → GeminiClient 호출 흐름
    캐시 레이어(Redis)도 이 계층에서 처리
    """

    def __init__(self):
        self.client = GeminiClient()

    def get_curriculum(self, user_id: int, goal_id: int) -> dict | None:
        """
        커리큘럼 생성 서비스

        1. DB에서 사용자 프로필 조회
        2. 캐시 확인 (Redis TTL 1h)
        3. 캐시 미스 → Gemini 호출
        4. curricula 테이블 저장
        5. ai_logs 저장
        """
        profile = self._load_profile(user_id)
        if not profile:
            return None

        # Redis 캐시 확인 (배포 시 활성화)
        # from cache.redis_cache import ElawCache
        # cache = ElawCache()
        # cached = cache.get_curriculum(user_id, goal_id)  # goal_hash 자동 처리
        # if cached:
        #     save_ai_log(AiResult(feature="curriculum", status="cached"), user_id)
        #     return cached
        # cache_key = f"curriculum:{user_id}:{cache._goal_hash(goal_id)}"
        # cached = redis_client.get(cache_key)
        # if cached:
        #     save_ai_log(AiResult(feature="curriculum", status="cached"), user_id)
        #     return json.loads(cached)

        result = self.client.generate_curriculum(profile)
        save_ai_log(result, user_id)

        if result.status == "success" and result.data:
            # DB 저장 (배포 시 활성화)
            # from core.models import Curriculum, UserGoal
            # goal = UserGoal.objects.get(id=goal_id)
            # Curriculum.objects.filter(user_id=user_id, is_active=True).update(is_active=False)
            # cur = Curriculum.objects.create(
            #     goal=goal, user_id=user_id,
            #     content_json=result.data, version=..., is_active=True
            # )
            # redis_client.setex(cache_key, 3600, json.dumps(result.data))
            return result.data

        return None

    def get_weakness_analysis(self, user_id: int) -> dict | None:
        """취약점 분석 서비스 (캐시 TTL 30분)"""
        profile = self._load_profile(user_id)
        if not profile:
            return None

        result = self.client.analyze_weakness(profile)
        save_ai_log(result, user_id)
        return result.data if result.status == "success" else None

    def get_portfolio_content(self, user_id: int) -> dict | None:
        """포트폴리오 생성 서비스"""
        profile = self._load_profile(user_id)
        if not profile:
            return None

        result = self.client.generate_portfolio(profile)
        save_ai_log(result, user_id)
        return result.data if result.status == "success" else None

    def calculate_job_match(
        self, user_id: int, posting_id: int,
        required_skills: list[str], preferred_skills: list[str], job_role: str
    ) -> float:
        """매칭 점수 계산 후 matches 테이블 저장"""
        profile = self._load_profile(user_id)
        if not profile:
            return 0.0

        result = self.client.calculate_match_score(
            profile, required_skills, preferred_skills, job_role
        )
        save_ai_log(result, user_id)

        if result.status == "success" and result.data:
            score = float(result.data.get("match_score", 0))
            # DB 저장 (배포 시 활성화)
            # from core.models import Match
            # Match.objects.update_or_create(
            #     user_id=user_id, posting_id=posting_id,
            #     defaults={"match_score": score}
            # )
            return score

        return 0.0

    def get_recommendations(self, user_id: int) -> list[dict]:
        """오늘의 추천 문제 (캐시 TTL 15분)"""
        profile = self._load_profile(user_id)
        if not profile:
            return []

        result = self.client.recommend_problems(profile)
        save_ai_log(result, user_id)

        if result.status == "success" and result.data:
            return result.data.get("problems", [])
        return []

    @staticmethod
    def _load_profile(user_id: int) -> UserProfile | None:
        """
        DB에서 사용자 프로필 조회 (배포 시 실제 ORM 쿼리로 교체)

        실제 구현:
          user         = User.objects.select_related('goals').get(id=user_id)
          active_goal  = user.goals.filter(is_active=True).first()
          lang_stats   = LearningStats.objects.filter(user_id=user_id, stat_type='language')
          tag_stats    = LearningStats.objects.filter(user_id=user_id, stat_type='algo_tag')
          total_solved = SolveHistory.objects.filter(user_id=user_id, status='solved').count()
        """
        # ── Mock 데이터 (개발·테스트용) — user_id별로 다른 프로필 반환
        _MOCK_PROFILES = {
            1: UserProfile(
                user_id=1, name="김민준", goal_type="job",
                field="컴퓨터", job_role="백엔드 개발자", duration_weeks=16,
                language_stats=[
                    {"lang": "Python", "solved": 45, "total": 50, "rate": 90.0},
                    {"lang": "Java",   "solved": 12, "total": 15, "rate": 80.0},
                ],
                algo_tag_stats=[
                    {"tag": "구현",    "solved": 18, "total": 20, "rate": 90.0},
                    {"tag": "정렬",    "solved": 10, "total": 11, "rate": 90.9},
                    {"tag": "DP",      "solved":  8, "total": 14, "rate": 57.1},
                    {"tag": "BFS",     "solved":  6, "total":  7, "rate": 85.7},
                    {"tag": "그리디",  "solved":  9, "total": 10, "rate": 90.0},
                    {"tag": "이분탐색","solved":  4, "total":  7, "rate": 57.1},
                ],
                total_solved=57, github_repos=5, github_commits=120, top_language="Python",
            ),
            2: UserProfile(
                user_id=2, name="이서연", goal_type="study",
                field="컴퓨터", job_role="AI 개발자", duration_weeks=16,
                language_stats=[
                    {"lang": "Python", "solved": 30, "total": 33, "rate": 90.9},
                ],
                algo_tag_stats=[
                    {"tag": "DP",   "solved": 10, "total": 11, "rate": 90.9},
                    {"tag": "BFS",  "solved":  8, "total":  9, "rate": 88.9},
                    {"tag": "스택", "solved":  3, "total":  6, "rate": 50.0},
                ],
                total_solved=30, github_repos=3, github_commits=45, top_language="Python",
            ),
            3: UserProfile(
                user_id=3, name="박지호", goal_type="job",
                field="컴퓨터", job_role="데이터 엔지니어", duration_weeks=16,
                language_stats=[
                    {"lang": "Java",   "solved": 20, "total": 25, "rate": 80.0},
                    {"lang": "Python", "solved": 10, "total": 13, "rate": 76.9},
                ],
                algo_tag_stats=[
                    {"tag": "정렬",  "solved": 8,  "total":  8, "rate": 100.0},
                    {"tag": "그리디","solved": 6,  "total":  7, "rate":  85.7},
                    {"tag": "DP",    "solved": 0,  "total":  5, "rate":   0.0},
                ],
                total_solved=30, github_repos=2, github_commits=30, top_language="Java",
            ),
        }
        # user_id에 해당 Mock이 없으면 기본 프로필 반환
        default_profile = UserProfile(
            user_id=user_id, name=f"사용자{user_id}", goal_type="study",
            field="컴퓨터", job_role="백엔드 개발자", duration_weeks=8,
            language_stats=[{"lang": "Python", "solved": 10, "total": 12, "rate": 83.3}],
            algo_tag_stats=[{"tag": "구현", "solved": 5, "total": 6, "rate": 83.3}],
            total_solved=10, github_repos=1, github_commits=10, top_language="Python",
        )
        return _MOCK_PROFILES.get(user_id, default_profile)


# ──────────────────────────────────────────────────────────────
# 동작 확인 (직접 실행 시)
# ──────────────────────────────────────────────────────────────
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s [%(levelname)s] %(message)s")

    service = AiService()

    print("\n" + "="*60)
    print("① 커리큘럼 생성 테스트")
    print("="*60)
    curriculum = service.get_curriculum(user_id=1, goal_id=1)
    if curriculum:
        print(f"총 {curriculum['total_weeks']}주 커리큘럼 생성 완료")
        print(f"1주차: {curriculum['weeks'][0]['theme']}")
        print(f"       예상 시간: {curriculum['weeks'][0]['estimated_hours']}시간")

    print("\n" + "="*60)
    print("② 취약점 분석 테스트")
    print("="*60)
    weakness = service.get_weakness_analysis(user_id=1)
    if weakness:
        print(f"전체 평가: {weakness['overall_comment']}")
        for w in weakness.get("weak_tags", []):
            print(f"  취약 태그: {w['tag']} ({w['correct_rate']:.1f}%)")
            print(f"  조언: {w['advice']}")

    print("\n" + "="*60)
    print("③ 포트폴리오 생성 테스트")
    print("="*60)
    portfolio = service.get_portfolio_content(user_id=1)
    if portfolio:
        for sec in portfolio.get("sections", []):
            print(f"  [{sec['type']}] {sec['title']}")

    print("\n" + "="*60)
    print("④ 채용 매칭 점수 테스트")
    print("="*60)
    score = service.calculate_job_match(
        user_id=1, posting_id=1,
        required_skills=["Python", "Django", "MySQL", "REST API"],
        preferred_skills=["Docker", "Redis", "AWS"],
        job_role="백엔드 개발자"
    )
    print(f"매칭 점수: {score:.1f}점")

    print("\n" + "="*60)
    print("⑤ 문제 추천 테스트")
    print("="*60)
    recs = service.get_recommendations(user_id=1)
    for r in recs:
        print(f"  #{r['id']} {r['title']}: {r['reason']}")
