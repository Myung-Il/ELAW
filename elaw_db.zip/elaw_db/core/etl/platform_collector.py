"""
ELAW Platform — ETL 파이프라인 (외부 플랫폼 데이터 수집)
파일    : etl/platform_collector.py
배포 경로: core/etl/platform_collector.py  (Django 프로젝트 내)
⚠ Django 배포 시 모듈 내 ORM import를 활성화하고
  "from core.models import ..." 형태로 사용하세요.
작성자  : DB/AI 담당 (오)  |  Sprint 4

처리 흐름 (ETL):
  Extract  → 백준(solved.ac API) / GitHub REST API 에서 데이터 수집
  Transform → 플랫폼별 데이터를 내부 표준 형식으로 정규화
  Load     → solve_history INSERT, learning_stats UPSERT

Django management command 연동:
  python manage.py sync_platforms          전체 사용자 동기화
  python manage.py sync_platforms --user 1  특정 사용자만

cron 등록 (orion 서버):
  0 3 * * * cd /srv/elaw && python manage.py sync_platforms >> /var/log/elaw/etl.log 2>&1
  0 4 * * * cd /srv/elaw && python manage.py rebuild_stats  >> /var/log/elaw/etl.log 2>&1
"""

from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

logger = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────
# 설정
# ──────────────────────────────────────────────────────────────

BAEKJOON_API_BASE  = "https://solved.ac/api/v3"
GITHUB_API_BASE    = "https://api.github.com"
REQUEST_TIMEOUT    = 10      # 초
REQUEST_DELAY      = 0.5     # API 호출 간격 (초) — Rate limit 방지
MAX_RETRIES        = 3


# ──────────────────────────────────────────────────────────────
# 데이터 클래스
# ──────────────────────────────────────────────────────────────

@dataclass
class SolveRecord:
    """정규화된 풀이 이력 레코드 (solve_history 한 행)"""
    user_id:       int
    platform:      str           # baekjoon | programmers | w3schools | custom
    problem_id:    str
    problem_title: str
    status:        str           # solved | failed | partial
    language:      str
    algo_tags:     list[str]
    difficulty:    str
    solved_at:     datetime
    source:        str = "api"


@dataclass
class CollectionResult:
    """플랫폼별 수집 결과 요약"""
    platform:       str
    user_id:        int
    new_records:    int  = 0
    skipped:        int  = 0
    errors:         int  = 0
    error_messages: list[str] = field(default_factory=list)

    def success_rate(self) -> float:
        total = self.new_records + self.skipped + self.errors
        return (self.new_records + self.skipped) / max(total, 1) * 100


# ──────────────────────────────────────────────────────────────
# solved.ac → 백준 난이도 매핑
# ──────────────────────────────────────────────────────────────

BAEKJOON_TIER_MAP = {
    # solved.ac tier 번호 → 표시 문자열
    1:  "Bronze5", 2:  "Bronze4", 3:  "Bronze3", 4:  "Bronze2", 5:  "Bronze1",
    6:  "Silver5", 7:  "Silver4", 8:  "Silver3", 9:  "Silver2", 10: "Silver1",
    11: "Gold5",   12: "Gold4",   13: "Gold3",   14: "Gold2",   15: "Gold1",
    16: "Platinum5",17: "Platinum4",18: "Platinum3",19: "Platinum2",20: "Platinum1",
    21: "Diamond5", 22: "Diamond4",
    0:  "Unrated",
}

# solved.ac 태그 영문 → 한국어 매핑 (주요 태그만)
TAG_KO_MAP = {
    "implementation":      "구현",
    "math":                "수학",
    "sorting":             "정렬",
    "string":              "문자열",
    "data_structures":     "자료구조",
    "graphs":              "그래프",
    "bfs":                 "BFS",
    "dfs":                 "DFS",
    "dp":                  "DP",
    "greedy":              "그리디",
    "binary_search":       "이분탐색",
    "two_pointer":         "투포인터",
    "stack":               "스택",
    "queue":               "큐",
    "deque":               "덱",
    "priority_queue":      "힙",
    "tree":                "트리",
    "graph_traversal":     "그래프탐색",
    "shortest_path":       "최단경로",
    "minimum_spanning_tree":"MST",
    "backtracking":        "백트래킹",
    "divide_and_conquer":  "분할정복",
    "number_theory":       "정수론",
    "geometry":            "기하학",
    "simulation":          "시뮬레이션",
    "ad_hoc":              "애드혹",
    "brute_force":         "브루트포스",
}


# ──────────────────────────────────────────────────────────────
# Extract — 백준 (solved.ac API)
# ──────────────────────────────────────────────────────────────

class BaekjoonExtractor:
    """
    solved.ac 비공식 API를 사용해 백준 풀이 데이터를 수집

    사용하는 API 엔드포인트:
      GET /user/show?handle={handle}            사용자 기본 정보
      GET /user/problem_stats?handle={handle}   태그별 풀이 통계
      GET /search/problem?query=solved_by:{handle}&page={n}  풀이 문제 목록
    """

    def __init__(self):
        # requests 라이브러리 (배포 시 import)
        # import requests
        # self._session = requests.Session()
        # self._session.headers.update({"User-Agent": "ELAW-Platform/1.0"})
        pass

    def _get(self, endpoint: str, params: dict = None) -> dict | None:
        """GET 요청 + 재시도 로직"""
        url = f"{BAEKJOON_API_BASE}{endpoint}"
        for attempt in range(1, MAX_RETRIES + 1):
            try:
                # 실제 호출 (배포 시 활성화)
                # resp = self._session.get(url, params=params, timeout=REQUEST_TIMEOUT)
                # resp.raise_for_status()
                # time.sleep(REQUEST_DELAY)
                # return resp.json()

                # ── Mock 응답 (개발 환경)
                return self._mock_api_response(endpoint, params)

            except Exception as e:
                logger.warning(f"[백준 API] {url} 호출 실패 (시도 {attempt}/{MAX_RETRIES}): {e}")
                if attempt < MAX_RETRIES:
                    time.sleep(REQUEST_DELAY * attempt * 2)
        return None

    @staticmethod
    def _mock_api_response(endpoint: str, params: dict = None) -> dict:
        """개발 환경 Mock 응답"""
        if "user/show" in endpoint:
            handle = (params or {}).get("handle", "test_user")
            return {
                "handle": handle,
                "solvedCount": 45,
                "tier": 9,  # Silver2
                "rating": 1245,
                "bio": f"{handle}'s profile",
            }
        if "search/problem" in endpoint:
            return {
                "count": 3,
                "items": [
                    {"problemId": 1260, "titleKo": "DFS와 BFS",
                     "level": 9, "tags": [{"key":"bfs"},{"key":"dfs"},{"key":"graphs"}]},
                    {"problemId": 2178, "titleKo": "미로 탐색",
                     "level": 10, "tags": [{"key":"bfs"}]},
                    {"problemId": 1463, "titleKo": "1로 만들기",
                     "level": 8, "tags": [{"key":"dp"}]},
                ]
            }
        return {}

    def get_user_info(self, handle: str) -> dict | None:
        """사용자 기본 정보 조회"""
        return self._get("/user/show", {"handle": handle})

    def get_solved_problems(self, handle: str) -> list[dict]:
        """
        풀이 완료 문제 전체 목록 조회
        solved.ac는 페이지당 50개 반환 → 전체 페이지 순회
        """
        all_items = []
        page = 1
        while True:
            data = self._get("/search/problem", {
                "query":  f"solved_by:{handle}",
                "page":   page,
                "sort":   "id",
                "order":  "desc",
            })
            if not data or not data.get("items"):
                break
            all_items.extend(data["items"])
            total = data.get("count", 0)
            if len(all_items) >= total:
                break
            page += 1
            time.sleep(REQUEST_DELAY)
        return all_items


# ──────────────────────────────────────────────────────────────
# Extract — GitHub REST API
# ──────────────────────────────────────────────────────────────

class GitHubExtractor:
    """GitHub REST API v3를 통해 커밋 수·언어 통계 수집"""

    def __init__(self, access_token: str = ""):
        self._token = access_token

    def _get(self, endpoint: str, params: dict = None) -> Any:
        url = f"{GITHUB_API_BASE}{endpoint}"
        headers = {
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
        }
        if self._token:
            headers["Authorization"] = f"Bearer {self._token}"

        for attempt in range(1, MAX_RETRIES + 1):
            try:
                # 실제 호출 (배포 시 활성화)
                # resp = requests.get(url, headers=headers, params=params,
                #                     timeout=REQUEST_TIMEOUT)
                # if resp.status_code == 403:
                #     logger.warning("GitHub Rate limit 도달")
                #     time.sleep(60)
                #     continue
                # resp.raise_for_status()
                # time.sleep(REQUEST_DELAY)
                # return resp.json()

                return self._mock_github_response(endpoint)

            except Exception as e:
                logger.warning(f"[GitHub API] {url} 호출 실패 (시도 {attempt}/{MAX_RETRIES}): {e}")
                if attempt < MAX_RETRIES:
                    time.sleep(REQUEST_DELAY * attempt * 2)
        return None

    @staticmethod
    def _mock_github_response(endpoint: str) -> Any:
        if "/repos" in endpoint and "/languages" in endpoint:
            return {"Python": 45230, "JavaScript": 8540, "Shell": 1200}
        if "/repos" in endpoint:
            return [
                {"name": "algorithm-study",  "description": "백준 풀이 모음", "language": "Python",
                 "stargazers_count": 3, "updated_at": "2026-03-01T10:00:00Z"},
                {"name": "django-portfolio", "description": "포트폴리오 웹앱", "language": "Python",
                 "stargazers_count": 1, "updated_at": "2026-02-15T10:00:00Z"},
                {"name": "elaw-project",     "description": "ELAW 플랫폼",    "language": "Python",
                 "stargazers_count": 0, "updated_at": "2026-03-20T10:00:00Z"},
            ]
        if "/commits" in endpoint:
            return [{"sha": f"abc{i}", "commit": {"message": f"feat: commit {i}",
                     "author": {"date": "2026-03-01T10:00:00Z"}}} for i in range(5)]
        return {}

    def get_repos(self, login: str) -> list[dict]:
        return self._get(f"/users/{login}/repos", {"per_page": 100, "sort": "updated"}) or []

    def get_commit_count(self, login: str, repo_name: str) -> int:
        commits = self._get(f"/repos/{login}/{repo_name}/commits", {"per_page": 1, "author": login})
        return len(commits) if isinstance(commits, list) else 0

    def get_languages(self, login: str, repo_name: str) -> dict:
        return self._get(f"/repos/{login}/{repo_name}/languages") or {}

    def get_summary(self, login: str) -> dict:
        """사용자 GitHub 활동 요약"""
        repos    = self.get_repos(login)
        total_commits = 0
        all_languages: dict[str, int] = {}

        for repo in repos[:10]:  # 최근 10개 리포만 조회 (API 절약)
            lang_data = self.get_languages(login, repo["name"])
            for lang, bytes_count in lang_data.items():
                all_languages[lang] = all_languages.get(lang, 0) + bytes_count
            commits = self.get_commit_count(login, repo["name"])
            total_commits += commits

        top_lang = max(all_languages, key=all_languages.get) if all_languages else ""
        return {
            "login":         login,
            "repo_count":    len(repos),
            "total_commits": total_commits,
            "languages":     all_languages,
            "top_language":  top_lang,
        }


# ──────────────────────────────────────────────────────────────
# Transform — 정규화
# ──────────────────────────────────────────────────────────────

class DataTransformer:
    """플랫폼별 원시 데이터 → 내부 표준 형식 변환"""

    @staticmethod
    def baekjoon_problem_to_record(
        user_id: int,
        raw_problem: dict,
        language: str = "",
        solved_at: datetime | None = None
    ) -> SolveRecord:
        """solved.ac 문제 객체 → SolveRecord"""
        tier      = raw_problem.get("level", 0)
        difficulty = BAEKJOON_TIER_MAP.get(tier, "Unrated")
        raw_tags  = raw_problem.get("tags", [])
        algo_tags = [
            TAG_KO_MAP.get(t.get("key", ""), t.get("key", ""))
            for t in raw_tags
        ]
        # language가 빈 문자열이면 None 처리 (Unknown 저장 방지)
        clean_language = language.strip() if language and language.strip() else None

        return SolveRecord(
            user_id=user_id,
            platform="baekjoon",
            problem_id=str(raw_problem["problemId"]),
            problem_title=raw_problem.get("titleKo", ""),
            status="solved",              # solved.ac는 solved 문제만 반환
            language=clean_language or "",
            algo_tags=[t for t in algo_tags if t],
            difficulty=difficulty,
            solved_at=solved_at or datetime.now(timezone.utc),
            # NOTE: solved.ac API는 실제 풀이 시각 미제공 → 수집 시각으로 대체
            # 개선 방안: solved.ac v3 /user/problem 에 solved_at 포함 시 해당 값 사용
            source="api",
        )

    @staticmethod
    def normalize_language(lang: str) -> str:
        """플랫폼마다 다른 언어명 → 내부 표준 언어명"""
        mapping = {
            "python3": "Python", "python 3": "Python", "pypy3": "Python",
            "java11": "Java", "java8": "Java",
            "c++17": "C++", "c++14": "C++", "c++": "C++",
            "c#": "C#", "node.js": "JavaScript", "javascript": "JavaScript",
            "kotlin": "Kotlin", "go": "Go", "rust": "Rust",
        }
        return mapping.get(lang.lower().strip(), lang.strip())


# ──────────────────────────────────────────────────────────────
# Load — DB 저장
# ──────────────────────────────────────────────────────────────

class DataLoader:
    """정규화된 데이터를 MySQL에 적재"""

    @staticmethod
    def load_solve_records(records: list[SolveRecord]) -> tuple[int, int]:
        """
        solve_history 에 INSERT IGNORE (중복 자동 스킵)

        Returns:
            (inserted_count, skipped_count)
        """
        inserted = skipped = 0
        for rec in records:
            try:
                # Django ORM (배포 시 활성화)
                # from core.models import SolveHistory
                # _, created = SolveHistory.objects.get_or_create(
                #     user_id=rec.user_id,
                #     platform=rec.platform,
                #     problem_id=rec.problem_id,
                #     defaults={
                #         "problem_title":  rec.problem_title,
                #         "status":         rec.status,
                #         "language":       rec.language,
                #         "algo_tags":      rec.algo_tags,
                #         "difficulty":     rec.difficulty,
                #         "solved_at":      rec.solved_at,
                #         "source":         rec.source,
                #     }
                # )
                # if created: inserted += 1
                # else:       skipped  += 1

                # Mock: 항상 성공으로 처리
                inserted += 1

            except Exception as e:
                logger.error(f"solve_history 저장 실패 (user={rec.user_id}, "
                             f"platform={rec.platform}, pid={rec.problem_id}): {e}")
        return inserted, skipped

    @staticmethod
    def rebuild_learning_stats(user_id: int) -> None:
        """
        solve_history 집계 → learning_stats UPSERT

        실행 SQL (Django ORM으로 대체 가능):
          -- 언어별 집계
          INSERT INTO learning_stats (user_id, stat_type, stat_key,
                  total_count, solved_count, failed_count, correct_rate, last_solved_at)
          SELECT
            user_id, 'language', language,
            COUNT(*),
            SUM(status = 'solved'),
            SUM(status = 'failed'),
            ROUND(SUM(status = 'solved') / COUNT(*) * 100, 1),
            MAX(solved_at)
          FROM solve_history
          WHERE user_id = %s AND language IS NOT NULL
          GROUP BY user_id, language
          ON DUPLICATE KEY UPDATE
            total_count    = VALUES(total_count),
            solved_count   = VALUES(solved_count),
            failed_count   = VALUES(failed_count),
            correct_rate   = VALUES(correct_rate),
            last_solved_at = VALUES(last_solved_at),
            updated_at     = NOW();
        """
        # 실제 구현 (배포 시 활성화)
        # from django.db import connection
        # with connection.cursor() as cursor:
        #     # 언어별 통계
        #     cursor.execute("""
        #         INSERT INTO learning_stats
        #           (user_id, stat_type, stat_key, total_count, solved_count,
        #            failed_count, correct_rate, last_solved_at)
        #         SELECT user_id, 'language', language,
        #                COUNT(*),
        #                SUM(status='solved'), SUM(status='failed'),
        #                ROUND(SUM(status='solved')/COUNT(*)*100,1),
        #                MAX(solved_at)
        #         FROM solve_history
        #         WHERE user_id=%s AND language IS NOT NULL
        #         GROUP BY user_id, language
        #         ON DUPLICATE KEY UPDATE
        #           total_count=VALUES(total_count),
        #           solved_count=VALUES(solved_count),
        #           failed_count=VALUES(failed_count),
        #           correct_rate=VALUES(correct_rate),
        #           last_solved_at=VALUES(last_solved_at),
        #           updated_at=NOW()
        #     """, [user_id])
        logger.info(f"[LOAD] user_id={user_id} learning_stats 재집계 완료 (Mock)")


# ──────────────────────────────────────────────────────────────
# 메인 파이프라인 오케스트레이터
# ──────────────────────────────────────────────────────────────

class ETLPipeline:
    """
    전체 ETL 파이프라인 실행

    Django management command 에서 호출:
      from core.etl.platform_collector import ETLPipeline
      pipeline = ETLPipeline()
      pipeline.run_all_users()
    """

    def __init__(self):
        self.boj_extractor = BaekjoonExtractor()
        self.gh_extractor  = GitHubExtractor()
        self.transformer   = DataTransformer()
        self.loader        = DataLoader()

    def run_user(self, user_id: int, boj_handle: str, github_login: str = "") -> dict:
        """
        단일 사용자 ETL 실행

        Returns:
            { "boj": CollectionResult, "github": dict }
        """
        results = {}
        start   = time.monotonic()
        logger.info(f"[ETL START] user_id={user_id} boj={boj_handle} github={github_login}")

        # ── 1. 백준 ETL ────────────────────────
        boj_result = CollectionResult(platform="baekjoon", user_id=user_id)
        try:
            raw_problems = self.boj_extractor.get_solved_problems(boj_handle)
            records = []
            for prob in raw_problems:
                try:
                    rec = self.transformer.baekjoon_problem_to_record(user_id, prob)
                    records.append(rec)
                except Exception as e:
                    boj_result.errors += 1
                    boj_result.error_messages.append(str(e))

            ins, skip = self.loader.load_solve_records(records)
            boj_result.new_records = ins
            boj_result.skipped     = skip

            # learning_stats 재집계 트리거
            self.loader.rebuild_learning_stats(user_id)

        except Exception as e:
            boj_result.errors += 1
            boj_result.error_messages.append(f"치명적 오류: {e}")
            logger.error(f"[ETL] 백준 수집 실패 user={user_id}: {e}")

        results["boj"] = boj_result
        logger.info(f"[ETL 백준] user={user_id} 신규={boj_result.new_records} "
                    f"스킵={boj_result.skipped} 오류={boj_result.errors}")

        # ── 2. GitHub ETL ───────────────────────
        if github_login:
            try:
                gh_summary = self.gh_extractor.get_summary(github_login)
                results["github"] = gh_summary

                # platform_links.last_synced 업데이트 (배포 시 활성화)
                # PlatformLink.objects.filter(
                #     user_id=user_id, platform='github'
                # ).update(last_synced=datetime.now(timezone.utc))

                logger.info(f"[ETL GitHub] user={user_id} repos={gh_summary['repo_count']} "
                            f"commits={gh_summary['total_commits']} top={gh_summary['top_language']}")
            except Exception as e:
                logger.error(f"[ETL] GitHub 수집 실패 user={user_id}: {e}")
                results["github"] = {"error": str(e)}

        elapsed = time.monotonic() - start
        logger.info(f"[ETL END] user_id={user_id} 소요={elapsed:.2f}s")
        return results

    def run_all_users(self) -> list[dict]:
        """
        platform_links 에 등록된 전체 사용자 순차 실행

        배포 시 실제 구현:
          links = PlatformLink.objects.filter(is_active=True).select_related('user')
          for link in links:
              ...
        """
        # ⚠ 개발 Mock — 배포 시 아래 ORM 쿼리로 교체 필요:
        # links = PlatformLink.objects.filter(is_active=True).select_related("user")
        # for link in links:
        #     boj = link.external_id if link.platform == "baekjoon" else ""
        #     gh  = link.external_id if link.platform == "github"   else ""
        #     self.run_user(link.user_id, boj, gh)
        mock_users = [
            {"user_id": 1, "boj_handle": "kimjun_boj",  "github": "kimjun"},
            {"user_id": 2, "boj_handle": "lee_seo",     "github": ""},
            {"user_id": 3, "boj_handle": "park_jiho99", "github": "park99"},
        ]
        all_results = []
        for u in mock_users:
            result = self.run_user(u["user_id"], u["boj_handle"], u.get("github", ""))
            all_results.append({
                "user_id": u["user_id"],
                "boj_new": result.get("boj", CollectionResult("boj", 0)).new_records,
                "github_commits": result.get("github", {}).get("total_commits", 0),
            })
        return all_results


# ──────────────────────────────────────────────────────────────
# Django Management Command 뼈대
# ──────────────────────────────────────────────────────────────

MANAGEMENT_COMMAND_TEMPLATE = '''
# 파일 위치: core/management/commands/sync_platforms.py

from django.core.management.base import BaseCommand
from core.etl.platform_collector import ETLPipeline

class Command(BaseCommand):
    help = "외부 플랫폼(백준/GitHub) 데이터 동기화"

    def add_arguments(self, parser):
        parser.add_argument("--user", type=int, help="특정 user_id만 동기화")

    def handle(self, *args, **options):
        pipeline = ETLPipeline()
        if options["user"]:
            # 특정 사용자만
            from core.models import PlatformLink
            links = PlatformLink.objects.filter(user_id=options["user"], is_active=True)
            for link in links:
                pipeline.run_user(link.user_id, link.external_id)
        else:
            # 전체 사용자
            results = pipeline.run_all_users()
            self.stdout.write(f"동기화 완료: {len(results)}명")


# 파일 위치: core/management/commands/rebuild_stats.py

from django.core.management.base import BaseCommand
from core.etl.platform_collector import DataLoader
from core.models import User

class Command(BaseCommand):
    help = "learning_stats 전체 재집계"

    def handle(self, *args, **options):
        loader = DataLoader()
        users = User.objects.filter(role="student", is_active=True)
        for user in users:
            loader.rebuild_learning_stats(user.id)
        self.stdout.write(f"재집계 완료: {users.count()}명")
'''


# ──────────────────────────────────────────────────────────────
# 동작 확인
# ──────────────────────────────────────────────────────────────
if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
    )

    print("="*60)
    print("ELAW ETL 파이프라인 동작 테스트")
    print("="*60)

    pipeline = ETLPipeline()

    print("\n[단일 사용자 테스트] user_id=1, boj=kimjun_boj, github=kimjun")
    result = pipeline.run_user(
        user_id=1,
        boj_handle="kimjun_boj",
        github_login="kimjun"
    )

    boj_r = result.get("boj")
    gh_r  = result.get("github", {})

    print(f"\n백준 수집 결과:")
    print(f"  신규 적재: {boj_r.new_records}건")
    print(f"  중복 스킵: {boj_r.skipped}건")
    print(f"  오류:      {boj_r.errors}건")
    print(f"  성공률:    {boj_r.success_rate():.1f}%")

    print(f"\nGitHub 수집 결과:")
    print(f"  리포지토리: {gh_r.get('repo_count', 0)}개")
    print(f"  총 커밋:   {gh_r.get('total_commits', 0)}회")
    print(f"  주력 언어: {gh_r.get('top_language', 'N/A')}")
    print(f"  언어 분포: {gh_r.get('languages', {})}")

    print("\n[전체 사용자 배치 테스트]")
    all_results = pipeline.run_all_users()
    print("\n요약:")
    for r in all_results:
        print(f"  user_id={r['user_id']} | 백준 신규={r['boj_new']}건 | GitHub 커밋={r['github_commits']}회")

    print(f"\nManagement Command 뼈대 코드:")
    print(MANAGEMENT_COMMAND_TEMPLATE[:300] + "  ...")
