"""
ELAW Platform — 채용 매칭 엔진
파일    : matching/match_engine.py
작성자  : DB/AI 담당 (오)  |  Sprint 5

역할:
  · 지원자 역량 벡터  ↔  채용 공고 요구사항  매칭 점수(0~100) 계산
  · 결과를 matches 테이블에 UPSERT
  · Gemini AI 보정 점수 호출 (ai_module.gemini_client.AiService 재사용)

알고리즘 (2단계):
  1단계 — 규칙 기반 점수 (빠름, 무료)
      required_skills 매칭  60점 만점
      preferred_skills 매칭 20점 만점
      풀이 수·정답률 보너스 20점 만점
  2단계 — Gemini 보정    (캐시 TTL 1h)
      1단계 점수를 seed로 넘겨 자연어 이해 기반 미세 조정

호출 흐름:
  MatchEngine.run_all(user_id)
    └─ _score_rule(profile, posting)   → base_score
    └─ AiService.calculate_job_match() → final_score  (캐시 또는 Gemini)
    └─ _save_match(user_id, posting_id, score)
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────────
# 스킬 정규화 사전
#   posting의 required_skills 와 사용자 언어·태그를
#   동일한 키로 비교하기 위한 매핑
# ─────────────────────────────────────────────────
SKILL_ALIAS: dict[str, str] = {
    # 언어
    "python3": "python", "pypy": "python", "py": "python",
    "javascript": "js",  "node.js": "js",  "nodejs": "js",
    "c++": "cpp", "c++17": "cpp", "c++14": "cpp",
    "java11": "java", "java8": "java",
    # 프레임워크
    "django rest framework": "drf", "django-rest-framework": "drf",
    "fastapi": "fastapi",
    # DB
    "mysql": "mysql", "mariadb": "mysql",
    "postgresql": "postgres", "postgres": "postgres",
    "mongodb": "mongodb", "mongo": "mongodb",
    # 인프라
    "docker": "docker", "kubernetes": "k8s", "k8s": "k8s",
    "aws": "aws", "amazon web services": "aws",
    "gcp": "gcp", "google cloud": "gcp",
    # AI/ML
    "pytorch": "pytorch", "torch": "pytorch",
    "tensorflow": "tensorflow", "tf": "tensorflow",
    "scikit-learn": "sklearn", "sklearn": "sklearn",
}

def normalize_skill(s: str) -> str:
    s = s.lower().strip()
    return SKILL_ALIAS.get(s, s)


# ─────────────────────────────────────────────────
# 데이터 클래스
# ─────────────────────────────────────────────────

@dataclass
class CandidateVector:
    """지원자 역량 벡터 — learning_stats + platform_links 기반"""
    user_id:        int
    languages:      dict[str, float]   # {"python": 90.0, "java": 80.0}  key=정규화, val=정답률
    algo_tags:      dict[str, float]   # {"DP": 65.0, "BFS": 90.0}
    total_solved:   int
    github_repos:   int
    github_commits: int
    job_role:       str                # 목표 직무 (user_goals)

    def skill_set(self) -> set[str]:
        """언어·도구 정규화 집합 반환"""
        return {normalize_skill(k) for k in self.languages}


@dataclass
class PostingVector:
    """채용 공고 요구사항 벡터"""
    posting_id:      int
    job_role:        str
    required_skills: list[str]         # 정규화 전 원본
    preferred_skills: list[str]
    career_level:    str               # new | junior | senior | any

    def req_normalized(self) -> list[str]:
        return [normalize_skill(s) for s in self.required_skills]

    def pref_normalized(self) -> list[str]:
        return [normalize_skill(s) for s in self.preferred_skills]


@dataclass
class MatchResult:
    user_id:         int
    posting_id:      int
    rule_score:      float
    final_score:     float
    matched_req:     list[str]
    missing_req:     list[str]
    matched_pref:    list[str]
    bonus_score:     float
    comment:         str = ""      # Gemini 보정 후 채워짐


# ─────────────────────────────────────────────────
# 규칙 기반 점수 계산기
# ─────────────────────────────────────────────────

class RuleScorer:
    """
    1단계: 규칙 기반 점수 계산 (Gemini 호출 없음)

    점수 구조 (합계 100점):
      required_skills 매칭률 × 60   → 최대 60점
      preferred_skills 매칭률 × 20  → 최대 20점
      풀이 수 보너스                 → 최대 10점
      평균 정답률 보너스             → 최대 10점
    """

    # 풀이 수 → 보너스 점수 (로그 스케일)
    SOLVE_BONUS_CURVE = [
        (300, 10), (200, 8), (100, 6), (50, 4), (20, 2), (0, 0)
    ]

    def score(self, cand: CandidateVector, post: PostingVector) -> MatchResult:
        cand_skills = cand.skill_set()
        req_norm    = post.req_normalized()
        pref_norm   = post.pref_normalized()

        # ① required 매칭
        matched_req  = [s for s in req_norm  if s in cand_skills]
        missing_req  = [s for s in req_norm  if s not in cand_skills]
        req_score    = (len(matched_req) / max(len(req_norm), 1)) * 60

        # ② preferred 매칭
        matched_pref = [s for s in pref_norm if s in cand_skills]
        pref_score   = (len(matched_pref) / max(len(pref_norm), 1)) * 20

        # ③ 풀이 수 보너스
        solve_bonus = 0.0
        for threshold, pts in self.SOLVE_BONUS_CURVE:
            if cand.total_solved >= threshold:
                solve_bonus = float(pts)
                break

        # ④ 평균 정답률 보너스
        if cand.languages:
            avg_rate   = sum(cand.languages.values()) / len(cand.languages)
            rate_bonus = min(avg_rate / 100 * 10, 10.0)
        else:
            avg_rate   = 0.0
            rate_bonus = 0.0

        total_bonus = solve_bonus + rate_bonus
        rule_score  = min(req_score + pref_score + total_bonus, 100.0)

        return MatchResult(
            user_id=cand.user_id,
            posting_id=post.posting_id,
            rule_score=round(rule_score, 1),
            final_score=round(rule_score, 1),   # Gemini 보정 전 동일
            matched_req=[r for r in post.required_skills
                         if normalize_skill(r) in {normalize_skill(m) for m in matched_req}],
            missing_req=[r for r in post.required_skills
                         if normalize_skill(r) in {normalize_skill(m) for m in missing_req}],
            matched_pref=matched_pref,
            bonus_score=round(total_bonus, 1),
        )


# ─────────────────────────────────────────────────
# 메인 매칭 엔진
# ─────────────────────────────────────────────────

class MatchEngine:
    """
    전체 매칭 파이프라인

    사용 예시:
        engine = MatchEngine()
        engine.run_all_postings(user_id=1)   # 사용자 1명 → 전체 공고 매칭
        engine.run_all_users()               # 전체 사용자 배치 매칭
    """

    def __init__(self):
        self.scorer = RuleScorer()

    # ── 단일 (사용자, 공고) 점수 계산
    def score_one(self, cand: CandidateVector, post: PostingVector) -> MatchResult:
        result = self.scorer.score(cand, post)

        # Gemini 보정 (배포 시 활성화 — 캐시 TTL 1h)
        # from ai_module.gemini_client import AiService
        # from core.models import UserGoal, LearningStats
        # profile = AiService._load_profile(cand.user_id)
        # ai_result = AiService().client.calculate_match_score(
        #     profile, post.required_skills, post.preferred_skills, post.job_role
        # )
        # if ai_result.status == "success" and ai_result.data:
        #     ai_score = float(ai_result.data.get("match_score", result.rule_score))
        #     result.final_score = round((result.rule_score * 0.4 + ai_score * 0.6), 1)
        #     result.comment     = ai_result.data.get("comment", "")

        return result

    # ── 사용자 1명 → 전체 활성 공고 매칭
    def run_all_postings(self, user_id: int) -> list[MatchResult]:
        cand     = self._load_candidate(user_id)
        postings = self._load_postings()
        results  = []

        for post in postings:
            result = self.score_one(cand, post)
            self._save_match(result)
            results.append(result)
            logger.debug(f"  posting={post.posting_id} rule={result.rule_score} "
                         f"final={result.final_score}")

        results.sort(key=lambda r: -r.final_score)
        logger.info(f"[MATCH] user={user_id} 총 {len(results)}개 공고 매칭 완료")
        return results

    # ── 전체 사용자 배치 매칭
    def run_all_users(self) -> dict[int, list[MatchResult]]:
        """
        배포 시 실제 구현:
          users = User.objects.filter(role='student', is_active=True)
          for user in users:
              self.run_all_postings(user.id)
        """
        all_results = {}
        for uid in range(1, 4):   # Mock: 학생 3명만
            all_results[uid] = self.run_all_postings(uid)
        return all_results

    # ── DB 저장 (matches 테이블 UPSERT)
    @staticmethod
    def _save_match(result: MatchResult) -> None:
        """
        matches 테이블에 매칭 결과 저장 (UPSERT)

        배포 시 실제 구현:
          from core.models import Match
          Match.objects.update_or_create(
              user_id=result.user_id,
              posting_id=result.posting_id,
              defaults={
                  "match_score": result.final_score,
                  "status": "recommended",   # 기존 상태 유지 위해 defaults에서 제외 가능
              }
          )
        """
        # ⚠ 개발 Mock — 실제로는 DB 저장하지 않음
        logger.info(
            f"[MATCH SAVE Mock] user={result.user_id} posting={result.posting_id} "
            f"score={result.final_score} "
            f"matched={result.matched_req} missing={result.missing_req}"
        )

    # ── Mock 데이터 로더 (배포 시 DB 조회로 교체)
    @staticmethod
    def _load_candidate(user_id: int) -> CandidateVector:
        mock_data = {
            1: CandidateVector(
                user_id=1, job_role="백엔드 개발자",
                languages={"python": 90.0, "java": 75.0},
                algo_tags={"구현": 100.0, "정렬": 100.0, "DP": 66.7,
                           "BFS": 100.0, "그리디": 100.0},
                total_solved=200, github_repos=5, github_commits=120,
            ),
            2: CandidateVector(
                user_id=2, job_role="AI 개발자",
                languages={"python": 88.0},
                algo_tags={"DP": 90.0, "BFS": 90.0, "그래프": 85.0},
                total_solved=120, github_repos=3, github_commits=45,
            ),
            3: CandidateVector(
                user_id=3, job_role="데이터 엔지니어",
                languages={"java": 82.0, "python": 70.0},
                algo_tags={"정렬": 100.0, "그리디": 100.0, "DP": 0.0},
                total_solved=80, github_repos=2, github_commits=30,
            ),
        }
        return mock_data.get(user_id, CandidateVector(
            user_id=user_id, job_role="기타",
            languages={}, algo_tags={}, total_solved=0,
            github_repos=0, github_commits=0,
        ))

    @staticmethod
    def _load_postings() -> list[PostingVector]:
        return [
            PostingVector(
                posting_id=1, job_role="백엔드 개발자", career_level="new",
                required_skills=["Python", "Django", "MySQL", "REST API", "Git"],
                preferred_skills=["Docker", "Redis", "AWS", "FastAPI"],
            ),
            PostingVector(
                posting_id=2, job_role="AI 개발자", career_level="new",
                required_skills=["Python", "PyTorch", "scikit-learn", "SQL"],
                preferred_skills=["LLM", "RAG", "AWS SageMaker", "MLflow"],
            ),
            PostingVector(
                posting_id=3, job_role="풀스택 개발자", career_level="junior",
                required_skills=["Python", "Django", "JavaScript", "React", "MySQL"],
                preferred_skills=["TypeScript", "Docker", "GraphQL"],
            ),
            PostingVector(
                posting_id=4, job_role="데이터 엔지니어", career_level="any",
                required_skills=["Python", "SQL", "Spark", "Airflow", "AWS"],
                preferred_skills=["Kafka", "dbt", "Redshift", "Terraform"],
            ),
            PostingVector(
                posting_id=5, job_role="데이터 분석가", career_level="new",
                required_skills=["SQL", "Python", "Tableau", "Excel"],
                preferred_skills=["R", "Power BI", "dbt"],
            ),
            PostingVector(
                posting_id=6, job_role="ML 엔지니어", career_level="junior",
                required_skills=["Python", "Kubernetes", "Docker", "MLflow", "SQL"],
                preferred_skills=["Kubeflow", "Spark", "Kafka", "Terraform"],
            ),
        ]


# ─────────────────────────────────────────────────
# 동작 확인
# ─────────────────────────────────────────────────
if __name__ == "__main__":
    import sys
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
        stream=sys.stdout,
    )

    engine = MatchEngine()

    print("\n" + "="*62)
    print(" 학생 1 (김민준 — 백엔드 지망) 전체 공고 매칭")
    print("="*62)
    results = engine.run_all_postings(user_id=1)
    print(f"\n{'순위':>2}  {'공고ID':>5}  {'점수':>6}  {'매칭 스킬':<30}  {'부족 스킬'}")
    print("-"*80)
    for rank, r in enumerate(results, 1):
        matched = ", ".join(r.matched_req) if r.matched_req else "—"
        missing = ", ".join(r.missing_req) if r.missing_req else "없음"
        print(f"{rank:>2}  posting={r.posting_id}  {r.final_score:>5.1f}점"
              f"  매칭:[{matched}]  부족:[{missing}]")

    print("\n" + "="*62)
    print(" 전체 사용자 배치 매칭 (학생 3명)")
    print("="*62)
    all_results = engine.run_all_users()
    for uid, rs in all_results.items():
        top = rs[0] if rs else None
        if top:
            print(f"\n  user={uid}  최고 매칭: posting={top.posting_id} "
                  f"점수={top.final_score}점  "
                  f"매칭 스킬={top.matched_req}")
