#!/bin/bash
# =============================================================
#  ELAW Platform — 배치 스케줄 & 백업 스크립트
#  파일    : batch/cron_setup.sh
#  작성자  : DB/AI 담당 (오)  |  Sprint 6
#
#  실행 방법 (orion 서버 최초 1회):
#    chmod +x batch/cron_setup.sh
#    ./batch/cron_setup.sh
#
#  확인:
#    crontab -l
# =============================================================

set -euo pipefail

ELAW_DIR="/srv/elaw"          # Django 프로젝트 루트 (orion 서버 기준)
VENV="${ELAW_DIR}/.venv/bin/python"
LOG_DIR="/var/log/elaw"
BACKUP_DIR="/backup/mysql"
DB_NAME="elaw_db"
DB_USER="elaw_user"

# 로그·백업 디렉토리 생성
mkdir -p "${LOG_DIR}" "${BACKUP_DIR}"

echo "=== ELAW cron 등록 시작 ==="

# 기존 ELAW cron 제거 (중복 방지)
crontab -l 2>/dev/null | grep -v "# ELAW" | crontab -

# 새 cron 항목 추가
(crontab -l 2>/dev/null; cat <<'CRON'

# ─── ELAW 플랫폼 배치 작업 ────────────────────────────────────

# [01] 외부 플랫폼 데이터 수집 — 매일 새벽 3:00
0 3 * * * cd /srv/elaw && .venv/bin/python manage.py sync_platforms >> /var/log/elaw/sync.log 2>&1 # ELAW

# [02] learning_stats 재집계 — 매일 새벽 4:00 (수집 완료 후)
0 4 * * * cd /srv/elaw && .venv/bin/python manage.py rebuild_stats >> /var/log/elaw/stats.log 2>&1 # ELAW

# [03] 만료 채용 공고 비활성화 — 매일 자정
0 0 * * * cd /srv/elaw && .venv/bin/python manage.py expire_postings >> /var/log/elaw/postings.log 2>&1 # ELAW

# [04] 매칭 점수 일괄 재계산 — 매주 일요일 새벽 5:00
0 5 * * 0 cd /srv/elaw && .venv/bin/python manage.py run_matching_batch >> /var/log/elaw/matching.log 2>&1 # ELAW

# [05] MySQL 전체 백업 — 매일 새벽 2:00
0 2 * * * /srv/elaw/batch/backup_mysql.sh >> /var/log/elaw/backup.log 2>&1 # ELAW

# [06] 오래된 백업 삭제 — 매일 새벽 2:30 (7일 초과 삭제)
30 2 * * * find /backup/mysql -name "*.sql.gz" -mtime +7 -delete >> /var/log/elaw/backup.log 2>&1 # ELAW

# [07] AI 비용 일일 리포트 — 매일 오전 9:00
0 9 * * * cd /srv/elaw && .venv/bin/python manage.py ai_cost_report >> /var/log/elaw/ai_cost.log 2>&1 # ELAW

CRON
) | crontab -

echo "=== cron 등록 완료 ==="
crontab -l | grep "ELAW"
