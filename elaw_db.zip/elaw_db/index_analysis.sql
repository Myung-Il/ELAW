-- =============================================================
--  ELAW Platform — 인덱스 검증 쿼리 모음
--  파일    : index/index_analysis.sql
--  작성자  : DB/AI 담당 (오)  |  Sprint 5
--
--  목적:
--    · 주요 API 엔드포인트에서 실행되는 쿼리의 EXPLAIN 분석
--    · Full Table Scan(type=ALL) 이 있으면 인덱스 추가
--    · 실제 MySQL 서버에서 아래 EXPLAIN 구문을 실행 후 결과 확인
--
--  판정 기준:
--    type     → ref / range / index 이상이면 양호, ALL(풀스캔)이면 위험
--    rows     → 스캔 행 수가 적을수록 좋음
--    Extra    → Using filesort / Using temporary 가 없어야 좋음
-- =============================================================

USE elaw_db;


-- ============================================================
-- [A] 대시보드 API — 최근 7일 풀이 수 조회
-- 엔드포인트: GET /api/study/dashboard
-- ============================================================

-- A-1. 사용자 최근 30일 풀이 이력 조회
EXPLAIN
SELECT
  DATE(solved_at) AS solve_date,
  COUNT(*)        AS daily_count,
  SUM(status = 'solved') AS solved_count
FROM solve_history
WHERE user_id  = 1
  AND solved_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
GROUP BY DATE(solved_at)
ORDER BY solve_date DESC;
-- 기대 결과: type=ref (idx_solve_user_solved_at 사용)

-- A-2. 언어·태그별 통계 조회 (레이더 차트 데이터)
EXPLAIN
SELECT stat_type, stat_key, solved_count, total_count, correct_rate
FROM learning_stats
WHERE user_id   = 1
  AND stat_type = 'language'
ORDER BY solved_count DESC;
-- 기대 결과: type=ref (uq_stats_user_type_key 사용)


-- ============================================================
-- [B] 공부 페이지 — 추천 문제 조회
-- 엔드포인트: GET /api/study/recommendations
-- ============================================================

-- B-1. 취약 알고리즘 태그 추출 (정답률 낮은 순 Top-5)
EXPLAIN
SELECT stat_key, correct_rate, solved_count
FROM learning_stats
WHERE user_id   = 1
  AND stat_type = 'algo_tag'
  AND correct_rate < 70.0
ORDER BY correct_rate ASC
LIMIT 5;
-- 기대 결과: type=ref (uq_stats_user_type_key), Extra=Using filesort 허용

-- B-2. 이미 푼 문제 제외 조회 (추천 전처리)
EXPLAIN
SELECT problem_id
FROM solve_history
WHERE user_id  = 1
  AND platform = 'baekjoon';
-- 기대 결과: type=ref (uq_solve_user_platform_problem 사용)


-- ============================================================
-- [C] 취업 페이지 — 추천 공고 조회
-- 엔드포인트: GET /api/jobs
-- ============================================================

-- C-1. 활성 공고 최신순 목록
EXPLAIN
SELECT jp.id, jp.title, jp.job_role, jp.deadline,
       c.name AS company_name
FROM job_postings jp
JOIN companies    c  ON c.id = jp.company_id
WHERE jp.is_active = 1
  AND (jp.deadline IS NULL OR jp.deadline >= CURDATE())
ORDER BY jp.created_at DESC
LIMIT 20;
-- 기대 결과: type=ref (idx_job_postings_deadline 사용)

-- C-2. 사용자 매칭 점수 기반 공고 추천 (내림차순)
EXPLAIN
SELECT m.posting_id, m.match_score, m.status,
       jp.title, jp.job_role, jp.deadline,
       c.name AS company_name
FROM matches      m
JOIN job_postings jp ON jp.id = m.posting_id
JOIN companies    c  ON c.id  = jp.company_id
WHERE m.user_id   = 1
  AND m.status   IN ('recommended','viewed','scrapped')
  AND jp.is_active = 1
ORDER BY m.match_score DESC
LIMIT 10;
-- 기대 결과: type=ref (idx_matches_user_score 사용)


-- ============================================================
-- [D] 기업 페이지 — 지원자 목록 조회
-- 엔드포인트: GET /api/jobs/mine/applicants
-- ============================================================

-- D-1. 특정 공고 지원자 목록 (기업 담당자용)
EXPLAIN
SELECT m.user_id, m.match_score, m.applied_at,
       u.name, u.email
FROM matches m
JOIN users   u ON u.id = m.user_id
WHERE m.posting_id = 1
  AND m.status     = 'applied'
ORDER BY m.match_score DESC;
-- 기대 결과: type=ref (idx_matches_posting_status 사용)

-- D-2. 기업의 전체 공고 목록
EXPLAIN
SELECT id, title, job_role, deadline,
       (SELECT COUNT(*) FROM matches WHERE posting_id = jp.id AND status='applied') AS applicants
FROM job_postings jp
WHERE company_id = 1
  AND is_active  = 1
ORDER BY created_at DESC;
-- 기대 결과: type=ref (idx_job_postings_company 사용)


-- ============================================================
-- [E] 포트폴리오 — 공개 URL 조회
-- 엔드포인트: GET /api/portfolio/:slug
-- ============================================================

EXPLAIN
SELECT p.*, u.name, u.email
FROM portfolios p
JOIN users      u ON u.id = p.user_id
WHERE p.public_slug = 'kimjun-portfolio-2026'
  AND p.is_public   = 1;
-- 기대 결과: type=const (uq_portfolios_slug UNIQUE KEY 사용)


-- ============================================================
-- [F] 관리자 통계 — 플랫폼 전체 현황
-- 엔드포인트: GET /api/admin/stats
-- ============================================================

-- F-1. v_platform_stats 뷰 조회
EXPLAIN
SELECT * FROM v_platform_stats;

-- F-2. 일별 풀이 수 추이 (최근 14일)
EXPLAIN
SELECT
  DATE(solved_at) AS day,
  COUNT(*)        AS total_solves,
  COUNT(DISTINCT user_id) AS active_users
FROM solve_history
WHERE solved_at >= DATE_SUB(NOW(), INTERVAL 14 DAY)
GROUP BY DATE(solved_at)
ORDER BY day DESC;
-- idx_solve_user_solved_at 에 solved_at 컬럼 포함되어 있어 range 스캔 가능


-- ============================================================
-- 추가 인덱스 후보 (EXPLAIN 결과 이후 필요 시 적용)
-- ============================================================

-- solve_history: 날짜만으로 전체 집계 시 (관리자 배치)
-- ALTER TABLE solve_history ADD INDEX idx_solve_solved_at (solved_at);

-- matches: 상태별 집계 (관리자 대시보드)
-- ALTER TABLE matches ADD INDEX idx_matches_status_created (status, created_at);

-- portfolios: 공개 목록 페이지네이션
-- ALTER TABLE portfolios ADD INDEX idx_portfolios_public_created (is_public, created_at DESC);


-- ============================================================
-- 인덱스 목록 확인 쿼리
-- ============================================================
SELECT
  TABLE_NAME,
  INDEX_NAME,
  COLUMN_NAME,
  NON_UNIQUE,
  SEQ_IN_INDEX
FROM information_schema.STATISTICS
WHERE TABLE_SCHEMA = 'elaw_db'
ORDER BY TABLE_NAME, INDEX_NAME, SEQ_IN_INDEX;
