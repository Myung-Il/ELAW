# ELAW DB 모듈 — 실행 가이드

> **대상 서버:** 목포대학교 orion 서버 (Ubuntu 20.04 / 22.04 / 24.04)  
> **작성자:** DB/AI 담당 (오)  
> **기준 환경:** Python 3.10+, MySQL 8.0.13+, Redis 6+

---

## 전체 흐름 한눈에 보기

```
[Step 1] 서버 필수 패키지 설치
    ↓
[Step 2] MySQL DB 생성 + 스키마 적용
    ↓
[Step 3] Python 가상환경 + Django 프로젝트 생성
    ↓
[Step 4] settings.py 설정
    ↓
[Step 5] DB 모듈 파일 → Django 프로젝트 통합
    ↓
[Step 6] Django Migration (--fake-initial)
    ↓
[Step 7] .env 환경변수 설정
    ↓
[Step 8] 시드 데이터 주입
    ↓
[Step 9] Redis 연동 확인
    ↓
[Step 10] 독립 테스트 실행 (39/39 통과 확인)
    ↓
[Step 11] Django 통합 테스트
    ↓
[Step 12] cron 배치 등록
```

> **작업 디렉토리 기준 안내**
> - `elaw_db/` — 다운로드한 DB 모듈 디렉토리 (이 가이드의 파일들이 있는 곳)
> - `/srv/elaw/` — orion 서버의 Django 프로젝트 루트 (생성 예정)
> - Step 5의 복사 명령까지는 **`elaw_db/` 안에서**, Step 6 이후는 **`/srv/elaw/` 안에서** 실행

---

## Step 1. 서버 필수 패키지 설치

```bash
sudo apt-get update
sudo apt-get install -y \
    python3 python3-pip python3-venv \
    python3-dev libffi-dev gcc \
    mysql-server mysql-client \
    libmysqlclient-dev pkg-config \
    redis-server \
    git curl

# 서비스 시작 및 부팅 자동 실행 등록
sudo systemctl start  mysql redis-server
sudo systemctl enable mysql redis-server

# 설치 확인
mysql --version        # mysql  Ver 8.x.x
redis-cli ping         # PONG
python3 --version      # Python 3.10+
```

---

## Step 2. MySQL 설정 및 스키마 적용

### 2-1. DB 사용자 생성

```bash
sudo mysql -u root
```

```sql
-- MySQL 콘솔 안에서 실행
CREATE USER 'elaw_user'@'localhost' IDENTIFIED BY '여기에_강력한_비밀번호_입력';
GRANT ALL PRIVILEGES ON elaw_db.* TO 'elaw_user'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

### 2-2. 스키마 적용 (elaw_db/ 디렉토리에서 실행)

```bash
# elaw_db/ 디렉토리 안에서 실행
mysql -u elaw_user -p < sql/schema_v1.sql
```

성공 시 마지막 출력:
```
message                          table_count
✅ ELAW schema_v1.sql 적용 완료  13
```

### 2-3. 테이블 생성 확인

```bash
mysql -u elaw_user -p elaw_db -e "SHOW TABLES;"
```

13개 테이블 + 2개 뷰가 나타나면 정상입니다.

---

## Step 3. Python 가상환경 + Django 프로젝트 생성

```bash
# Django 프로젝트 루트 생성
sudo mkdir -p /srv/elaw
sudo chown $(whoami) /srv/elaw
cd /srv/elaw

# Python 가상환경 생성 및 활성화
python3 -m venv .venv
source .venv/bin/activate      # 이후 모든 명령은 venv 활성 상태에서 실행

# 패키지 설치 (elaw_db/docs/requirements.txt 복사 후)
pip install -r /path/to/elaw_db/docs/requirements.txt

# Django 프로젝트 생성
django-admin startproject config .
python manage.py startapp core

# management commands 디렉토리 생성
mkdir -p core/management/commands
touch core/management/__init__.py
touch core/management/commands/__init__.py

# 서브 모듈 디렉토리 생성
mkdir -p core/ai core/etl core/matching core/cache
touch core/ai/__init__.py core/etl/__init__.py
touch core/matching/__init__.py core/cache/__init__.py

# 로그 + 백업 + 스크립트 디렉토리 생성
sudo mkdir -p /var/log/elaw /backup/mysql
sudo chown $(whoami) /var/log/elaw /backup/mysql
mkdir -p scripts docs tests batch
```

---

## Step 4. settings.py 설정

`docs/settings_example.py`를 `config/settings.py`에 덮어씁니다:

```bash
cp /path/to/elaw_db/docs/settings_example.py /srv/elaw/config/settings.py
```

이후 `config/settings.py`에서 수정이 필요한 항목:

```python
ALLOWED_HOSTS = ['localhost', '127.0.0.1', 'orion.mokpo.ac.kr']  # 실제 도메인으로 변경
```

---

## Step 5. DB 모듈 파일 → Django 프로젝트 통합

**elaw_db/ 디렉토리 안에서** 아래 명령을 실행합니다:

```bash
DJANGO=/srv/elaw

# 1. ORM 모델 (managed=False — schema_v1.sql과 충돌 방지)
cp migrations/models.py  $DJANGO/core/models.py

# 2. AI 모듈
cp ai_module/gemini_client.py   $DJANGO/core/ai/gemini_client.py

# 3. ETL 파이프라인
cp etl/platform_collector.py   $DJANGO/core/etl/platform_collector.py

# 4. 매칭 엔진
cp matching/match_engine.py    $DJANGO/core/matching/match_engine.py

# 5. Redis 캐시
cp cache/redis_cache.py        $DJANGO/core/cache/redis_cache.py

# 6. 시드 스크립트
cp seed/generate_seed.py       $DJANGO/scripts/generate_seed.py

# 7. 인덱스 분석 SQL
cp index/index_analysis.sql    $DJANGO/docs/index_analysis.sql
cp sql/schema_v1.sql           $DJANGO/docs/schema_v1.sql

# 8. 테스트 파일
cp test/test_db_ai.py          $DJANGO/tests/test_db_ai.py

# 9. 배치 스크립트
cp batch/backup_mysql.sh       $DJANGO/batch/backup_mysql.sh
cp batch/cron_setup.sh         $DJANGO/batch/cron_setup.sh
chmod +x $DJANGO/batch/*.sh
```

### Step 5-a. Management Commands 파일 생성

```bash
DJANGO=/srv/elaw

# sync_platforms
cat > $DJANGO/core/management/commands/sync_platforms.py << 'EOF'
import logging
from django.core.management.base import BaseCommand
from core.models import PlatformLink
from core.etl.platform_collector import ETLPipeline

logger = logging.getLogger(__name__)

class Command(BaseCommand):
    help = "외부 플랫폼(백준/GitHub) 풀이 이력 수집 및 DB 적재"

    def add_arguments(self, parser):
        parser.add_argument("--user", type=int, default=None,
                            help="특정 user_id만 동기화 (생략 시 전체)")

    def handle(self, *args, **options):
        pipeline = ETLPipeline()
        links = PlatformLink.objects.filter(is_active=True).select_related("user")
        if options["user"]:
            links = links.filter(user_id=options["user"])
        total_new = 0
        for link in links:
            try:
                result = pipeline.run_user(
                    user_id=link.user_id,
                    boj_handle=link.external_id if link.platform == "baekjoon" else "",
                    github_login=link.external_id if link.platform == "github" else "",
                )
                boj = result.get("boj")
                if boj:
                    total_new += boj.new_records
            except Exception as e:
                logger.error(f"user={link.user_id} 수집 실패: {e}")
        self.stdout.write(f"동기화 완료 | 신규 적재: {total_new}건")
EOF

# rebuild_stats
cat > $DJANGO/core/management/commands/rebuild_stats.py << 'EOF'
from django.core.management.base import BaseCommand
from django.db import connection
from core.models import User

class Command(BaseCommand):
    help = "solve_history 기반 learning_stats 전체 재집계"

    def handle(self, *args, **options):
        students = User.objects.filter(role="student", is_active=True)
        with connection.cursor() as cursor:
            for user in students:
                cursor.execute("""
                    INSERT INTO learning_stats
                      (user_id, stat_type, stat_key, total_count, solved_count,
                       failed_count, correct_rate, last_solved_at)
                    SELECT %s, 'language', language,
                           COUNT(*), SUM(status='solved'), SUM(status='failed'),
                           ROUND(SUM(status='solved')/COUNT(*)*100,1), MAX(solved_at)
                    FROM solve_history
                    WHERE user_id=%s AND language IS NOT NULL AND language != ''
                    GROUP BY language
                    ON DUPLICATE KEY UPDATE
                      total_count=VALUES(total_count),
                      solved_count=VALUES(solved_count),
                      failed_count=VALUES(failed_count),
                      correct_rate=VALUES(correct_rate),
                      last_solved_at=VALUES(last_solved_at),
                      updated_at=NOW()
                """, [user.id, user.id])
        self.stdout.write(f"재집계 완료: {students.count()}명")
EOF

# expire_postings
cat > $DJANGO/core/management/commands/expire_postings.py << 'EOF'
from datetime import date
from django.core.management.base import BaseCommand
from core.models import JobPosting

class Command(BaseCommand):
    help = "마감된 채용 공고 비활성화"

    def handle(self, *args, **options):
        expired = JobPosting.objects.filter(
            is_active=True, deadline__lt=date.today()
        )
        count = expired.count()
        expired.update(is_active=False)
        self.stdout.write(f"만료 공고 {count}건 비활성화")
EOF

# run_matching_batch
cat > $DJANGO/core/management/commands/run_matching_batch.py << 'EOF'
from django.core.management.base import BaseCommand
from core.models import User
from core.matching.match_engine import MatchEngine

class Command(BaseCommand):
    help = "전체 학생 ↔ 활성 공고 매칭 점수 일괄 재계산"

    def handle(self, *args, **options):
        engine   = MatchEngine()
        students = User.objects.filter(role="student", is_active=True)
        total    = 0
        for user in students:
            results = engine.run_all_postings(user.id)
            total  += len(results)
        self.stdout.write(f"매칭 완료: {students.count()}명")
EOF

# ai_cost_report
cat > $DJANGO/core/management/commands/ai_cost_report.py << 'EOF'
from datetime import date, timedelta
from django.core.management.base import BaseCommand
from django.db.models import Sum, Count, Avg
from core.models import AiLog

PRICE_PER_1K_INPUT  = 0.00125
PRICE_PER_1K_OUTPUT = 0.00375

class Command(BaseCommand):
    help = "Gemini API 호출 비용 일일 리포트"

    def add_arguments(self, parser):
        parser.add_argument("--days", type=int, default=1)

    def handle(self, *args, **options):
        since = date.today() - timedelta(days=options["days"])
        logs  = AiLog.objects.filter(
            created_at__date__gte=since,
            status__in=["success", "error", "timeout"]
        )
        stats = logs.aggregate(
            total_calls    = Count("id"),
            total_input_tk = Sum("prompt_tokens"),
            total_output_tk= Sum("output_tokens"),
            avg_latency    = Avg("latency_ms"),
        )
        in_tk  = stats["total_input_tk"]  or 0
        out_tk = stats["total_output_tk"] or 0
        cost   = (in_tk / 1000 * PRICE_PER_1K_INPUT
                + out_tk / 1000 * PRICE_PER_1K_OUTPUT)
        self.stdout.write(f"총 호출: {stats['total_calls']}회 | "
                          f"토큰: {in_tk}+{out_tk} | 예상비용: ${cost:.4f}")
EOF

echo "✅ Management commands 5개 생성 완료"
```

---

## Step 6. Django Migration 적용

`schema_v1.sql`을 이미 MySQL에 적용했으므로 `--fake-initial`을 사용합니다:

```bash
cd /srv/elaw
source .venv/bin/activate

# Migration 파일 생성
python manage.py makemigrations core

# DB에 이미 테이블이 있으므로 --fake-initial로 충돌 없이 동기화
python manage.py migrate --fake-initial

# 결과 확인
python manage.py showmigrations core
```

> **`--fake-initial`이란?**  
> Django가 "이미 이 테이블들이 DB에 존재한다"고 인식하고, 실제 CREATE TABLE은 건너뜁니다.  
> `schema_v1.sql`과 ORM 모델이 동시에 공존할 수 있는 방법입니다.

---

## Step 7. .env 환경변수 설정

```bash
# env_example.txt를 .env로 복사 (elaw_db/ 디렉토리에서 실행)
cp docs/env_example.txt /srv/elaw/.env

# 실제 값 입력 (nano 또는 vim 사용)
nano /srv/elaw/.env
```

**.env에서 반드시 교체해야 할 항목 3가지:**

```bash
DJANGO_SECRET_KEY=...  # 아래 명령으로 생성
DB_PASSWORD=...        # Step 2-1에서 설정한 MySQL 비밀번호
GEMINI_API_KEY=...     # Google AI Studio에서 발급
```

**SECRET_KEY 생성:**
```bash
cd /srv/elaw && source .venv/bin/activate
python -c "from django.core.management.utils import get_random_secret_key; print(get_random_secret_key())"
```

**Gemini API 키 발급:**
1. [https://aistudio.google.com](https://aistudio.google.com) 접속 → Google 계정 로그인
2. 좌측 `Get API key` → `Create API key` 클릭
3. 발급된 `AIzaSy...` 키를 `.env`의 `GEMINI_API_KEY`에 붙여넣기

```bash
# .env 파일 권한 보호 (소유자만 읽기)
chmod 600 /srv/elaw/.env
```

---

## Step 8. 시드 데이터 주입

```bash
# elaw_db/ 디렉토리에서 실행
mysql -u elaw_user -p elaw_db < seed/seed_data.sql

# 풀이 이력 추가 생성 (~350건)
python3 seed/generate_seed.py > seed/seed_solve_history.sql
mysql -u elaw_user -p elaw_db < seed/seed_solve_history.sql

# 데이터 확인
mysql -u elaw_user -p elaw_db -e "
SELECT 'users'         AS 테이블, COUNT(*) AS 건수 FROM users         UNION ALL
SELECT 'solve_history',            COUNT(*)         FROM solve_history UNION ALL
SELECT 'curricula',                COUNT(*)         FROM curricula     UNION ALL
SELECT 'job_postings',             COUNT(*)         FROM job_postings  UNION ALL
SELECT 'matches',                  COUNT(*)         FROM matches;"
```

예상 출력:
```
+--------------+------+
| 테이블        | 건수 |
+--------------+------+
| users        |   15 |
| solve_history|  400 |
| curricula    |   10 |
| job_postings |    6 |
| matches      |   20 |
+--------------+------+
```

---

## Step 9. Redis 연동 확인

```bash
# Redis 상태 확인
redis-cli ping          # PONG

# Python에서 연결 테스트
cd /srv/elaw && source .venv/bin/activate
python -c "
import redis
r = redis.Redis(host='localhost', port=6379, db=0)
r.set('elaw_test', 'ok')
print('Redis 연결:', r.get('elaw_test').decode())
r.delete('elaw_test')
"
# 출력: Redis 연결: ok
```

---

## Step 10. 독립 테스트 실행 (elaw_db/ 디렉토리 기준)

MySQL·Redis·Django 없이도 실행 가능한 **단독 테스트**입니다.

```bash
# elaw_db/ 디렉토리 안에서 실행 (Django 프로젝트 불필요)
cd /path/to/elaw_db
python3 test/test_db_ai.py
```

**기대 결과:**
```
==============================================================
  테스트 결과: 39/39 통과
==============================================================
  ✅  스키마 — 12개 테이블 정의 확인
  ✅  스키마 — DROP VIEW가 DROP TABLE 앞에 있음 확인
  ... (총 39개 모두 ✅)
==============================================================
```

---

## Step 11. Django 통합 테스트

```bash
cd /srv/elaw
source .venv/bin/activate

# 11-1. Django 기본 설정 검사
python manage.py check

# 11-2. DB 연결 확인
python manage.py dbshell -c "SELECT COUNT(*) AS user_count FROM users;"

# 11-3. AI 모듈 테스트 (GEMINI_API_KEY 설정 후)
python manage.py shell -c "
import sys
sys.path.insert(0, '.')
from core.ai.gemini_client import AiService
svc = AiService()
result = svc.get_curriculum(user_id=1, goal_id=1)
print('커리큘럼:', result['total_weeks'] if result else '실패')
"

# 11-4. ETL 동기화 테스트 (Mock 모드)
python manage.py sync_platforms --user 1

# 11-5. 학습 통계 재집계
python manage.py rebuild_stats

# 11-6. 만료 공고 처리
python manage.py expire_postings

# 11-7. Django 프로젝트 내 테스트 실행
python3 tests/test_db_ai.py
```

---

## Step 12. cron 배치 등록

```bash
cd /srv/elaw

# 실행 권한 부여
chmod +x batch/backup_mysql.sh batch/cron_setup.sh

# cron 등록 (7개 배치 작업 자동 등록)
./batch/cron_setup.sh

# 등록 확인
crontab -l | grep ELAW
```

**등록 결과 (7개 배치 작업):**
```
0 3 * * *   sync_platforms    — 백준/GitHub 데이터 수집
0 4 * * *   rebuild_stats     — 학습 통계 재집계
0 0 * * *   expire_postings   — 마감 공고 비활성화
0 5 * * 0   run_matching_batch — 매칭 점수 재계산 (주 1회)
0 2 * * *   backup_mysql.sh   — DB 백업
30 2 * * *  (백업 7일 초과 삭제)
0 9 * * *   ai_cost_report    — AI 비용 리포트
```

---

## 자주 발생하는 문제 해결

### `mysqlclient` 설치 실패
```bash
sudo apt-get install -y libmysqlclient-dev pkg-config
pip install mysqlclient
```

### `redis` 연결 거부
```bash
sudo systemctl start redis-server
redis-cli ping   # PONG 확인
```

### `migrate` 시 `table already exists`
```bash
# schema_v1.sql을 이미 적용했을 때
python manage.py migrate --fake-initial
```

### `No module named 'core.etl'`
```bash
# __init__.py 누락 확인
touch core/etl/__init__.py core/ai/__init__.py
touch core/matching/__init__.py core/cache/__init__.py
```

### Gemini API 403 오류
```bash
# API 키 확인
echo $GEMINI_API_KEY
# .env 로드 확인
python -c "from dotenv import load_dotenv; load_dotenv(); import os; print(os.environ.get('GEMINI_API_KEY','없음')[:10])"
```

### cron 등록 후 배치 미실행
```bash
sudo systemctl status cron
cat /var/log/elaw/sync.log
```

---

## 빠른 참조 — 자주 쓰는 명령어

```bash
# 가상환경 활성화
source /srv/elaw/.venv/bin/activate

# 개발 서버 실행
cd /srv/elaw && python manage.py runserver 0.0.0.0:8000

# 독립 단위 테스트 (elaw_db/ 에서)
python3 test/test_db_ai.py

# Django 통합 테스트 (/srv/elaw/ 에서)
python3 tests/test_db_ai.py

# 수동 데이터 수집 (특정 사용자)
python manage.py sync_platforms --user 1

# 학습 통계 재집계
python manage.py rebuild_stats

# MySQL 직접 접속
mysql -u elaw_user -p elaw_db

# Redis 키 목록 확인
redis-cli keys "*"

# AI 비용 조회 (최근 7일)
python manage.py ai_cost_report --days 7

# DB 백업 수동 실행
ELAW_DB_PASSWORD=비밀번호 bash /srv/elaw/batch/backup_mysql.sh
```
