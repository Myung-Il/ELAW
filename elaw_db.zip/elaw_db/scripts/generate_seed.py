#!/usr/bin/env python3
"""
ELAW Platform — solve_history 대량 시드 데이터 생성기
작성자  : DB/AI 담당 (오)  |  Sprint 2

용도    : seed_data.sql 의 50건 외 나머지 ~450건을 Python으로 생성
출력    : seed_solve_history.sql (MySQL INSERT 구문)

실행    : python3 generate_seed.py > seed_solve_history.sql
"""

import random
from datetime import datetime, timedelta

# ── 상수 정의
STUDENTS = list(range(1, 11))   # user_id 1~10

BAEKJOON_PROBLEMS = [
    # (problem_id, title, difficulty, tags)
    ("1000", "A+B",                 "Bronze5",  ["구현"]),
    ("2557", "Hello World",          "Bronze5",  ["구현"]),
    ("2750", "수 정렬하기",           "Bronze2",  ["정렬"]),
    ("1181", "단어 정렬",             "Silver5",  ["정렬", "문자열"]),
    ("10989","수 정렬하기 3",         "Bronze1",  ["정렬", "카운팅정렬"]),
    ("10828","스택",                  "Silver4",  ["스택"]),
    ("10845","큐",                    "Silver4",  ["큐"]),
    ("10866","덱",                    "Silver4",  ["덱"]),
    ("1260", "DFS와 BFS",             "Silver2",  ["그래프", "BFS", "DFS"]),
    ("2178", "미로 탐색",             "Silver1",  ["BFS"]),
    ("11724","연결 요소의 개수",       "Silver2",  ["그래프", "DFS"]),
    ("1463", "1로 만들기",            "Silver3",  ["DP"]),
    ("9095", "1, 2, 3 더하기",        "Silver3",  ["DP"]),
    ("11053","가장 긴 증가하는 부분 수열","Silver2",["DP"]),
    ("12015","가장 긴 증가하는 부분 수열 2","Gold2",["DP", "이분탐색"]),
    ("1003", "피보나치 함수",          "Silver3",  ["DP"]),
    ("2579", "계단 오르기",            "Silver3",  ["DP"]),
    ("1920", "수 찾기",               "Silver4",  ["이분탐색"]),
    ("2805", "나무 자르기",            "Silver2",  ["이분탐색", "매개변수탐색"]),
    ("2003", "수들의 합 2",            "Silver4",  ["투포인터"]),
    ("11047","동전 0",                "Silver1",  ["그리디"]),
    ("1931", "회의실 배정",            "Silver1",  ["그리디"]),
    ("1541", "잃어버린 괄호",          "Silver2",  ["그리디"]),
    ("1927", "최소 힙",               "Silver2",  ["자료구조", "힙"]),
    ("11279","최대 힙",               "Silver2",  ["자료구조", "힙"]),
    ("1991", "트리 순회",             "Silver1",  ["트리"]),
    ("11725","트리의 부모 찾기",       "Silver2",  ["트리", "BFS"]),
    ("1197", "최소 스패닝 트리",       "Gold4",    ["그래프", "MST"]),
    ("1753", "최단경로",              "Gold4",    ["그래프", "다익스트라"]),
    ("1854", "K번째 최단경로 찾기",    "Gold2",    ["그래프", "다익스트라"]),
    ("2493", "탑",                    "Gold5",    ["스택"]),
    ("6198", "옥상 정원 꾸미기",       "Gold5",    ["스택"]),
    ("1916", "최소비용 구하기",        "Gold5",    ["그래프", "다익스트라"]),
    ("1987", "알파벳",                "Gold4",    ["그래프", "DFS", "백트래킹"]),
    ("9663", "N-Queen",              "Gold4",    ["백트래킹"]),
    ("1941", "소문난 칠공주",          "Gold4",    ["BFS", "백트래킹"]),
    ("7569", "토마토",                "Gold5",    ["BFS"]),
    ("14502","연구소",                "Gold4",    ["BFS", "구현"]),
    ("14501","퇴사",                  "Silver3",  ["DP", "브루트포스"]),
    ("15649","N과 M (1)",             "Silver3",  ["백트래킹"]),
]

LANGUAGES_BY_GOAL = {
    "백엔드 개발자":     ["Python", "Python", "Python", "Java"],
    "AI 개발자":         ["Python", "Python", "Python"],
    "데이터 엔지니어":   ["Python", "Java",   "SQL"],
    "프론트엔드 개발자": ["JavaScript", "Python"],
    "DevOps 엔지니어":  ["Python", "C++", "Go"],
}

USER_GOALS = {
    1:  "백엔드 개발자",
    2:  "AI 개발자",
    3:  "데이터 엔지니어",
    4:  "프론트엔드 개발자",
    5:  "백엔드 개발자",
    6:  "DevOps 엔지니어",
    7:  "AI 개발자",
    8:  "데이터 엔지니어",
    9:  "백엔드 개발자",
    10: "프론트엔드 개발자",
}

# 학생별 취약 태그 (DP 취약, 그리디 강세 등 패턴 부여)
WEAKNESS = {
    1:  ["DP", "이분탐색"],       # 김민준 — DP 취약
    2:  ["스택", "트리"],         # 이서연 — 자료구조 취약
    3:  ["DP", "그래프"],         # 박지호 — DP·그래프 취약
    4:  ["BFS", "DFS", "DP"],    # 최유진 — 탐색 취약
    5:  ["그리디", "이분탐색"],   # 정하은 — 그리디 취약
    6:  ["DP", "트리"],           # 강도현 — DP 취약
    7:  ["스택", "큐"],           # 윤세진 — 자료구조 취약
    8:  ["그래프", "MST"],        # 임채원 — 고급 그래프 취약
    9:  ["DP", "백트래킹"],       # 송예준 — DP 취약
    10: ["정렬", "이분탐색"],     # 한수아 — 알고리즘 기초 취약
}

def random_date(start_days_ago: int, end_days_ago: int = 0) -> str:
    """최근 N일 전~M일 전 범위에서 랜덤 datetime 생성"""
    start = datetime.now() - timedelta(days=start_days_ago)
    end   = datetime.now() - timedelta(days=end_days_ago)
    delta = end - start
    rand  = start + timedelta(seconds=random.randint(0, int(delta.total_seconds())))
    return rand.strftime("%Y-%m-%d %H:%M:%S")

def escape_sql(s: str) -> str:
    return s.replace("'", "\\'")

def get_status(user_id: int, tags: list[str]) -> str:
    """취약 태그이면 50% 확률로 failed, 아니면 90% solved"""
    weakness = WEAKNESS.get(user_id, [])
    if any(t in weakness for t in tags):
        return "failed" if random.random() < 0.50 else "solved"
    return "solved" if random.random() < 0.90 else "failed"

def generate():
    rows = []
    used: dict[int, set] = {uid: set() for uid in STUDENTS}

    # 학생 1~3은 이미 seed_data.sql에서 20~10건 입력됨
    # 나머지를 채워 학생당 평균 50건 목표
    target = {
        1: 30,   # 20건 기입력 → 30건 추가
        2: 20,   # 10건 기입력 → 20건 추가
        3: 20,   # 10건 기입력 → 20건 추가
        4: 50, 5: 50, 6: 50, 7: 50, 8: 50, 9: 50, 10: 50,
    }

    for uid, count in target.items():
        goal = USER_GOALS[uid]
        lang_pool = LANGUAGES_BY_GOAL.get(goal, ["Python"])
        added = 0
        attempts = 0
        problems_shuffled = BAEKJOON_PROBLEMS.copy()
        random.shuffle(problems_shuffled)

        for prob in problems_shuffled * 3:  # 반복 순환으로 충분히 채우기
            if added >= count:
                break
            pid = prob[0]
            if pid in used[uid]:
                continue
            used[uid].add(pid)

            ptitle = escape_sql(prob[1])
            diff   = prob[2]
            tags   = prob[3]
            status = get_status(uid, tags)
            lang   = random.choice(lang_pool)
            tags_json = str(tags).replace("'", '"')
            solved_at = random_date(60, 1)

            rows.append(
                f"({uid},'baekjoon','{pid}','{ptitle}','{status}',"
                f"'{lang}','{tags_json}','{diff}','{solved_at}','api')"
            )
            added += 1

    return rows

def main():
    random.seed(42)
    rows = generate()

    print("-- ============================================================")
    print("--  ELAW — solve_history 추가 시드 데이터 (~450건)")
    print("--  생성일시:", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    print("-- ============================================================")
    print("USE elaw_db;")
    print()
    print("INSERT IGNORE INTO solve_history")
    print("  (user_id, platform, problem_id, problem_title, status,")
    print("   language, algo_tags, difficulty, solved_at, source)")
    print("VALUES")

    chunk_size = 50
    for i in range(0, len(rows), chunk_size):
        chunk = rows[i:i + chunk_size]
        is_last_chunk = (i + chunk_size >= len(rows))
        for j, row in enumerate(chunk):
            is_last_row_in_chunk = (j == len(chunk) - 1)
            if is_last_chunk and is_last_row_in_chunk:
                print(f"  {row};")
            else:
                print(f"  {row},")
        if not is_last_chunk:
            print()
            print("INSERT IGNORE INTO solve_history")
            print("  (user_id, platform, problem_id, problem_title, status,")
            print("   language, algo_tags, difficulty, solved_at, source)")
            print("VALUES")

    print()
    print("-- 생성 완료 확인")
    print("SELECT COUNT(*) AS total_solve_history FROM solve_history;")

if __name__ == "__main__":
    main()
