-- =============================================================
--  ELAW Platform — 개발·시연용 시드 데이터 v1.0
--  작성자 : DB/AI 담당 (오)  |  Sprint 2
--
--  데이터 규모:
--    users          15건 (학생 10, 기업담당자 3, 관리자 2)
--    companies       3건
--    platform_links 10건
--    user_goals     10건
--    curricula      10건 (JSON 구조 샘플)
--    solve_history 500건 (Python 스크립트로 생성 → 하단 참고)
--    learning_stats 30건
--    job_postings    6건
--    matches        20건
--    posts           5건
--
--  실행 방법:
--    mysql -u root -p elaw_db < seed_data.sql
--
--  주의:
--    · 비밀번호는 모두 'test1234' 의 bcrypt 해시 (실제 서비스 금지)
--    · 개발·시연 전용 데이터
-- =============================================================

USE elaw_db;

-- 기존 시드 데이터 초기화 (개발 환경 재설치용)
SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE TABLE ai_logs;
TRUNCATE TABLE matches;
TRUNCATE TABLE job_postings;
TRUNCATE TABLE portfolios;
TRUNCATE TABLE posts;
TRUNCATE TABLE platform_links;
TRUNCATE TABLE learning_stats;
TRUNCATE TABLE solve_history;
TRUNCATE TABLE curricula;
TRUNCATE TABLE user_goals;
TRUNCATE TABLE companies;
TRUNCATE TABLE users;
SET FOREIGN_KEY_CHECKS = 1;


-- =============================================================
-- [1] users — 15건
--     비밀번호 'test1234' → bcrypt 해시 (실제 구현 시 Python bcrypt 사용)
--     $2b$12$dummyhash.여기는실제bcrypt해시로교체필요
-- =============================================================
INSERT INTO users
  (id, email, password_hash, name, role, phone, is_active, ai_consent, privacy_consent)
VALUES
-- 학생 10명
  ( 1, 'student01@elaw.dev', '##DEV##0978f3f394ca25b939c924bf0ff97f3f7d1875a001ee3ff248b24', '김민준', 'student', '010-1111-0001', 1, 1, 1),
  ( 2, 'student02@elaw.dev', '##DEV##0bc8823ad58ea7ad5f477bd714562d6b653d73027b6547ea483e7', '이서연', 'student', '010-1111-0002', 1, 1, 1),
  ( 3, 'student03@elaw.dev', '##DEV##8b5a7167c0b8aaede90013537fb0b5e0c4b5ea101b6321a8b9e29', '박지호', 'student', '010-1111-0003', 1, 1, 1),
  ( 4, 'student04@elaw.dev', '##DEV##8eb9a7daf2a926f1af28bedf1b8c6d4998b39f91129065a61828a', '최유진', 'student', '010-1111-0004', 1, 1, 1),
  ( 5, 'student05@elaw.dev', '##DEV##f810cd470d32dd4d9554dc80d7ab8b249d93452acee8d4b4fe964', '정하은', 'student', '010-1111-0005', 1, 1, 1),
  ( 6, 'student06@elaw.dev', '##DEV##29e8fbe4b0ed9e1ba0407f04d003b3dd549209a4df64e0db91f9f', '강도현', 'student', '010-1111-0006', 1, 1, 1),
  ( 7, 'student07@elaw.dev', '##DEV##a0865e757c329717fbcec4c57e0a8f8ca32227a0c75e6c14c9248', '윤세진', 'student', '010-1111-0007', 1, 1, 1),
  ( 8, 'student08@elaw.dev', '##DEV##316304807cade39fb1fe6a7636372f3d117f49f7d112ec5005b9b', '임채원', 'student', '010-1111-0008', 1, 1, 1),
  ( 9, 'student09@elaw.dev', '##DEV##b484523e5b9555a59e4367992f60a54fb4c0511d44dae28807852', '송예준', 'student', '010-1111-0009', 1, 1, 1),
  (10, 'student10@elaw.dev', '##DEV##3b7e6232df77d3dc9139cc306f5888c1cfcaf94acbd8ab6a86f26', '한수아', 'student', '010-1111-0010', 1, 1, 1),

-- 기업 담당자 3명
  (11, 'company01@elaw.dev', '##DEV##98a8d49a384bbd172209dcf83a4e24cca831b089461068a0b68a2', '박승현', 'company', '02-1234-0001', 1, 1, 1),
  (12, 'company02@elaw.dev', '##DEV##ae84f013b83d38476afa0b95adf134083670985cad714432a2600', '이지원', 'company', '02-1234-0002', 1, 1, 1),
  (13, 'company03@elaw.dev', '##DEV##2a1a0f6c957b27cae11eac61831863a7ef9d343ebab67ed6ade65', '김태영', 'company', '02-1234-0003', 1, 1, 1),

-- 관리자 2명
  (14, 'admin01@elaw.dev',   '##DEV##dcfe7d123f6c0e75513591d113543bdf83f7c8c8f8a4af6ea3947',   '관리자A', 'admin', NULL, 1, 1, 1),
  (15, 'admin02@elaw.dev',   '##DEV##2a41d2e6ad999fa46d6c961849153a8531a5938066c60f6c26c46',   '관리자B', 'admin', NULL, 1, 1, 1);


-- =============================================================
-- [2] companies — 3건 (2개 승인, 1개 대기)
-- =============================================================
INSERT INTO companies
  (id, user_id, name, industry, description, is_approved, approved_at)
VALUES
  (1, 11, '넥스트소프트',
   'IT/소프트웨어',
   '스타트업 환경에서 백엔드·AI 개발자를 양성하는 테크 기업입니다.',
   1, '2026-02-15 09:00:00'),

  (2, 12, '데이터브릿지',
   'IT/데이터',
   '데이터 엔지니어링과 ML 플랫폼 전문 기업으로, 다양한 프로젝트를 운영합니다.',
   1, '2026-02-20 10:30:00'),

  (3, 13, '클라우드웨이브',
   'IT/클라우드',
   '클라우드 인프라 및 DevOps 솔루션을 제공하는 기업입니다.',
   0, NULL);  -- 승인 대기


-- =============================================================
-- [3] platform_links — 학생 10명 백준 연동
-- =============================================================
INSERT INTO platform_links
  (user_id, platform, external_id, last_synced, is_active)
VALUES
  ( 1, 'baekjoon', 'kimjun_boj',   '2026-03-01 03:00:00', 1),
  ( 2, 'baekjoon', 'lee_seo',      '2026-03-01 03:00:00', 1),
  ( 3, 'baekjoon', 'park_jiho99',  '2026-03-01 03:00:00', 1),
  ( 4, 'baekjoon', 'choi_yujin',   '2026-03-01 03:00:00', 1),
  ( 5, 'baekjoon', 'jung_haeun',   '2026-03-01 03:00:00', 1),
  ( 6, 'baekjoon', 'kang_dev',     '2026-03-01 03:00:00', 1),
  ( 7, 'baekjoon', 'yoon_sejin',   '2026-03-01 03:00:00', 1),
  ( 8, 'baekjoon', 'lim_chaewon',  '2026-03-01 03:00:00', 1),
  ( 9, 'baekjoon', 'song_yejun',   '2026-03-01 03:00:00', 1),
  (10, 'baekjoon', 'han_sua_boj',  '2026-03-01 03:00:00', 1);


-- =============================================================
-- [4] user_goals — 10건 (취업 3명, 공부 7명)
-- =============================================================
INSERT INTO user_goals
  (user_id, goal_type, field, job_role, start_date, end_date, mid_eval_date, duration_weeks, is_active)
VALUES
  ( 1, 'job',   '컴퓨터', '백엔드 개발자',     '2026-03-01', '2026-06-28', '2026-05-01', 16, 1),
  ( 2, 'study', '컴퓨터', 'AI 개발자',         '2026-03-01', '2026-06-28', '2026-05-01', 16, 1),
  ( 3, 'job',   '컴퓨터', '데이터 엔지니어',   '2026-03-01', '2026-06-28', '2026-05-01', 16, 1),
  ( 4, 'study', '컴퓨터', '프론트엔드 개발자', '2026-03-01', '2026-06-28', '2026-05-01', 16, 1),
  ( 5, 'study', '컴퓨터', '백엔드 개발자',     '2026-03-01', '2026-06-28', '2026-05-01', 16, 1),
  ( 6, 'job',   '컴퓨터', 'DevOps 엔지니어',   '2026-03-01', '2026-06-28', '2026-05-01', 16, 1),
  ( 7, 'study', '컴퓨터', 'AI 개발자',         '2026-03-01', '2026-06-28', '2026-05-01', 16, 1),
  ( 8, 'study', '컴퓨터', '데이터 엔지니어',   '2026-03-01', '2026-06-28', '2026-05-01', 16, 1),
  ( 9, 'study', '컴퓨터', '백엔드 개발자',     '2026-03-01', '2026-06-28', '2026-05-01', 16, 1),
  (10, 'study', '컴퓨터', '프론트엔드 개발자', '2026-03-01', '2026-06-28', '2026-05-01', 16, 1);


-- =============================================================
-- [5] curricula — 10건 (AI 생성 JSON 구조 샘플)
-- =============================================================
INSERT INTO curricula (goal_id, user_id, content_json, version, is_active)
VALUES
(1, 1, '{
  "total_weeks": 16,
  "field": "컴퓨터",
  "job_role": "백엔드 개발자",
  "weeks": [
    {"week": 1, "theme": "Python 기초 & 자료구조", "tasks": ["리스트·딕셔너리 실습", "백준 #1000, #2557"], "recommended_problems": ["1000","2557","1001"], "estimated_hours": 8},
    {"week": 2, "theme": "정렬 알고리즘", "tasks": ["버블·선택·삽입 정렬 구현", "백준 #2750, #1181"], "recommended_problems": ["2750","1181","10989"], "estimated_hours": 10},
    {"week": 3, "theme": "스택·큐·덱", "tasks": ["스택 응용문제", "백준 #10828, #10845"], "recommended_problems": ["10828","10845","10866"], "estimated_hours": 10},
    {"week": 4, "theme": "그래프 기초 (BFS/DFS)", "tasks": ["BFS 미로탐색", "DFS 연결요소"], "recommended_problems": ["1260","2178","11724"], "estimated_hours": 12},
    {"week": 5, "theme": "동적 프로그래밍 기초", "tasks": ["피보나치 DP", "LCS"], "recommended_problems": ["1463","9095","12015"], "estimated_hours": 12},
    {"week": 6, "theme": "이분탐색 & 투포인터", "tasks": ["이분탐색 응용", "투포인터 실습"], "recommended_problems": ["1920","2805","2003"], "estimated_hours": 10},
    {"week": 7, "theme": "Django 기초", "tasks": ["MTV 패턴 이해", "ORM 기본 CRUD"], "recommended_problems": [], "estimated_hours": 12},
    {"week": 8, "theme": "중간 평가 & 복습", "tasks": ["1~7주차 취약 유형 재풀이", "미니 프로젝트 시작"], "recommended_problems": [], "estimated_hours": 8},
    {"week": 9, "theme": "Django REST Framework", "tasks": ["Serializer·ViewSet", "JWT 인증 구현"], "recommended_problems": [], "estimated_hours": 14},
    {"week": 10, "theme": "데이터베이스 심화", "tasks": ["정규화 실습", "인덱스 설계"], "recommended_problems": [], "estimated_hours": 10},
    {"week": 11, "theme": "그리디 알고리즘", "tasks": ["그리디 패턴 학습", "백준 #11047, #1931"], "recommended_problems": ["11047","1931","1541"], "estimated_hours": 10},
    {"week": 12, "theme": "트리 & 힙", "tasks": ["이진 트리 순회", "우선순위 큐"], "recommended_problems": ["1991","1927","11279"], "estimated_hours": 12},
    {"week": 13, "theme": "백엔드 포트폴리오 프로젝트", "tasks": ["API 서버 설계·구현", "README 작성"], "recommended_problems": [], "estimated_hours": 16},
    {"week": 14, "theme": "모의 코딩테스트", "tasks": ["프로그래머스 Level 2 5문제", "시간 내 풀이 연습"], "recommended_problems": [], "estimated_hours": 10},
    {"week": 15, "theme": "이력서 & 포트폴리오 완성", "tasks": ["ELAW 포트폴리오 생성", "GitHub 정리"], "recommended_problems": [], "estimated_hours": 8},
    {"week": 16, "theme": "최종 점검 & 지원", "tasks": ["취약점 최종 보완", "기업 지원"], "recommended_problems": [], "estimated_hours": 6}
  ]
}', 1, 1),

(2, 2, '{
  "total_weeks": 16,
  "field": "컴퓨터",
  "job_role": "AI 개발자",
  "weeks": [
    {"week": 1, "theme": "Python & NumPy 기초", "tasks": ["NumPy 배열 연산", "Matplotlib 시각화"], "recommended_problems": ["1000","2557"], "estimated_hours": 10},
    {"week": 2, "theme": "통계 & 선형대수", "tasks": ["평균·분산·상관계수", "행렬 연산"], "recommended_problems": [], "estimated_hours": 10},
    {"week": 3, "theme": "머신러닝 기초 (sklearn)", "tasks": ["회귀·분류 모델 실습", "교차검증"], "recommended_problems": [], "estimated_hours": 12},
    {"week": 4, "theme": "DP & 알고리즘 (AI 코테 대비)", "tasks": ["DP 패턴 학습"], "recommended_problems": ["1463","9095"], "estimated_hours": 10},
    {"week": 5, "theme": "딥러닝 기초 (PyTorch)", "tasks": ["텐서 연산", "선형 모델 학습"], "recommended_problems": [], "estimated_hours": 14},
    {"week": 6, "theme": "CNN & 이미지 처리", "tasks": ["MNIST CNN 학습", "데이터 증강"], "recommended_problems": [], "estimated_hours": 14},
    {"week": 7, "theme": "NLP 기초", "tasks": ["토크나이징", "Word2Vec"], "recommended_problems": [], "estimated_hours": 12},
    {"week": 8, "theme": "중간 평가 & 프로젝트 기획", "tasks": ["Kaggle 입문 대회 참가"], "recommended_problems": [], "estimated_hours": 10}
  ]
}', 1, 1),

(3, 3, '{"total_weeks":16,"field":"컴퓨터","job_role":"데이터 엔지니어","weeks":[{"week":1,"theme":"SQL 기초","tasks":["SELECT·JOIN·집계함수"],"recommended_problems":[],"estimated_hours":8},{"week":2,"theme":"Python & Pandas","tasks":["DataFrame 조작"],"recommended_problems":[],"estimated_hours":10}]}', 1, 1),
(4, 4, '{"total_weeks":16,"field":"컴퓨터","job_role":"프론트엔드 개발자","weeks":[{"week":1,"theme":"HTML & CSS 기초","tasks":["Flexbox·Grid 실습"],"recommended_problems":[],"estimated_hours":8}]}', 1, 1),
(5, 5, '{"total_weeks":16,"field":"컴퓨터","job_role":"백엔드 개발자","weeks":[{"week":1,"theme":"Python 기초","tasks":["자료구조 실습"],"recommended_problems":["1000","2557"],"estimated_hours":8}]}', 1, 1),
(6, 6, '{"total_weeks":16,"field":"컴퓨터","job_role":"DevOps 엔지니어","weeks":[{"week":1,"theme":"Linux 기초","tasks":["쉘 명령어","파일 시스템"],"recommended_problems":[],"estimated_hours":8}]}', 1, 1),
(7, 7, '{"total_weeks":16,"field":"컴퓨터","job_role":"AI 개발자","weeks":[{"week":1,"theme":"Python & NumPy","tasks":["배열 연산 실습"],"recommended_problems":[],"estimated_hours":10}]}', 1, 1),
(8, 8, '{"total_weeks":16,"field":"컴퓨터","job_role":"데이터 엔지니어","weeks":[{"week":1,"theme":"SQL 기초","tasks":["기본 쿼리 실습"],"recommended_problems":[],"estimated_hours":8}]}', 1, 1),
(9, 9, '{"total_weeks":16,"field":"컴퓨터","job_role":"백엔드 개발자","weeks":[{"week":1,"theme":"Python 기초","tasks":["변수·함수 실습"],"recommended_problems":["1000"],"estimated_hours":8}]}', 1, 1),
(10,10, '{"total_weeks":16,"field":"컴퓨터","job_role":"프론트엔드 개발자","weeks":[{"week":1,"theme":"JavaScript 기초","tasks":["DOM 조작 실습"],"recommended_problems":[],"estimated_hours":8}]}', 1, 1);


-- =============================================================
-- [6] solve_history — 50건 샘플 (나머지 450건은 Python 스크립트로 생성)
--     실제 백준 문제 번호 사용 (실버~골드 난이도)
-- =============================================================
INSERT INTO solve_history
  (user_id, platform, problem_id, problem_title, status, language, algo_tags, difficulty, solved_at, source)
VALUES
-- 학생 1 (김민준) — 백엔드 지망, Python 주력
  (1,'baekjoon','1000','A+B',           'solved','Python','["구현"]',      'Bronze5', '2026-02-01 10:00:00','api'),
  (1,'baekjoon','2557','Hello World',   'solved','Python','["구현"]',      'Bronze5', '2026-02-01 10:30:00','api'),
  (1,'baekjoon','2750','수 정렬하기',    'solved','Python','["정렬"]',      'Bronze2', '2026-02-02 11:00:00','api'),
  (1,'baekjoon','1181','단어 정렬',      'solved','Python','["정렬","문자열"]','Silver5','2026-02-03 09:00:00','api'),
  (1,'baekjoon','10828','스택',          'solved','Python','["스택"]',      'Silver4', '2026-02-04 14:00:00','api'),
  (1,'baekjoon','10845','큐',            'solved','Python','["큐"]',        'Silver4', '2026-02-04 15:00:00','api'),
  (1,'baekjoon','1260','DFS와 BFS',      'solved','Python','["그래프","BFS","DFS"]','Silver2','2026-02-05 10:00:00','api'),
  (1,'baekjoon','2178','미로 탐색',      'solved','Python','["BFS"]',       'Silver1', '2026-02-06 11:00:00','api'),
  (1,'baekjoon','1463','1로 만들기',     'solved','Python','["DP"]',        'Silver3', '2026-02-07 09:00:00','api'),
  (1,'baekjoon','9095','1,2,3 더하기',   'solved','Python','["DP"]',        'Silver3', '2026-02-08 10:00:00','api'),
  (1,'baekjoon','1920','수 찾기',        'solved','Python','["이분탐색"]',  'Silver4', '2026-02-10 11:00:00','api'),
  (1,'baekjoon','2805','나무 자르기',    'solved','Python','["이분탐색","매개변수탐색"]','Silver2','2026-02-11 09:00:00','api'),
  (1,'baekjoon','11047','동전 0',        'solved','Python','["그리디"]',    'Silver1', '2026-02-12 10:00:00','api'),
  (1,'baekjoon','1931','회의실 배정',    'solved','Python','["그리디"]',    'Silver1', '2026-02-13 11:00:00','api'),
  (1,'baekjoon','1927','최소 힙',        'solved','Python','["자료구조","힙"]','Silver2','2026-02-14 09:00:00','api'),

-- 학생 1 — 오답 포함 (DP 취약)
  (1,'baekjoon','12015','가장 긴 증가하는 부분 수열 2','failed','Python','["DP","이분탐색"]','Gold2','2026-02-15 10:00:00','api'),
  (1,'baekjoon','11053','가장 긴 증가하는 부분 수열','failed','Python','["DP"]','Silver2','2026-02-16 10:00:00','api'),
  (1,'baekjoon','1003','피보나치 함수',  'solved','Python','["DP"]',        'Silver3', '2026-02-17 09:00:00','api'),
  (1,'baekjoon','2579','계단 오르기',    'solved','Python','["DP"]',        'Silver3', '2026-02-18 10:00:00','api'),
  (1,'baekjoon','1991','트리 순회',      'solved','Python','["트리"]',      'Silver1', '2026-02-19 11:00:00','api'),

-- 학생 2 (이서연) — AI 개발자 지망, Python 주력
  (2,'baekjoon','1000','A+B',           'solved','Python','["구현"]',      'Bronze5', '2026-02-01 09:00:00','api'),
  (2,'baekjoon','2557','Hello World',   'solved','Python','["구현"]',      'Bronze5', '2026-02-01 09:30:00','api'),
  (2,'baekjoon','1463','1로 만들기',    'solved','Python','["DP"]',        'Silver3', '2026-02-02 10:00:00','api'),
  (2,'baekjoon','9095','1,2,3 더하기',  'solved','Python','["DP"]',        'Silver3', '2026-02-03 11:00:00','api'),
  (2,'baekjoon','11053','가장 긴 증가하는 부분 수열','solved','Python','["DP"]','Silver2','2026-02-04 09:00:00','api'),
  (2,'baekjoon','1260','DFS와 BFS',     'solved','Python','["그래프","BFS","DFS"]','Silver2','2026-02-05 10:00:00','api'),
  (2,'baekjoon','2178','미로 탐색',     'solved','Python','["BFS"]',       'Silver1', '2026-02-06 09:00:00','api'),
  (2,'baekjoon','11724','연결 요소의 개수','solved','Python','["그래프","DFS"]','Silver2','2026-02-07 10:00:00','api'),
  (2,'baekjoon','1927','최소 힙',       'solved','Python','["자료구조","힙"]','Silver2','2026-02-08 11:00:00','api'),
  (2,'baekjoon','10828','스택',         'failed','Java','["스택"]',        'Silver4', '2026-02-09 09:00:00','api'),

-- 학생 3 (박지호) — 데이터 엔지니어 지망, Java 주력
  (3,'baekjoon','1000','A+B',           'solved','Java','["구현"]',        'Bronze5', '2026-02-01 08:00:00','api'),
  (3,'baekjoon','2557','Hello World',   'solved','Java','["구현"]',        'Bronze5', '2026-02-01 08:30:00','api'),
  (3,'baekjoon','2750','수 정렬하기',   'solved','Java','["정렬"]',        'Bronze2', '2026-02-02 09:00:00','api'),
  (3,'baekjoon','1181','단어 정렬',     'solved','Java','["정렬","문자열"]','Silver5', '2026-02-03 10:00:00','api'),
  (3,'baekjoon','10828','스택',         'solved','Java','["스택"]',        'Silver4', '2026-02-04 11:00:00','api'),
  (3,'baekjoon','1260','DFS와 BFS',     'solved','Java','["그래프","BFS","DFS"]','Silver2','2026-02-05 09:00:00','api'),
  (3,'baekjoon','1463','1로 만들기',    'failed','Java','["DP"]',          'Silver3', '2026-02-06 10:00:00','api'),
  (3,'baekjoon','9095','1,2,3 더하기',  'failed','Java','["DP"]',          'Silver3', '2026-02-07 11:00:00','api'),
  (3,'baekjoon','11047','동전 0',       'solved','Java','["그리디"]',      'Silver1', '2026-02-08 09:00:00','api'),
  (3,'baekjoon','1931','회의실 배정',   'solved','Java','["그리디"]',      'Silver1', '2026-02-09 10:00:00','api'),

-- 학생 4~10 각 1건씩 (기본 확인용)
  (4,'baekjoon','1000','A+B','solved','JavaScript','["구현"]','Bronze5','2026-02-01 10:00:00','api'),
  (5,'baekjoon','1000','A+B','solved','Python','["구현"]','Bronze5','2026-02-01 10:00:00','api'),
  (6,'baekjoon','1000','A+B','solved','C++','["구현"]','Bronze5','2026-02-01 10:00:00','api'),
  (7,'baekjoon','1000','A+B','solved','Python','["구현"]','Bronze5','2026-02-01 10:00:00','api'),
  (8,'baekjoon','1000','A+B','solved','Python','["구현"]','Bronze5','2026-02-01 10:00:00','api'),
  (9,'baekjoon','1000','A+B','solved','Python','["구현"]','Bronze5','2026-02-01 10:00:00','api'),
  (10,'baekjoon','1000','A+B','solved','JavaScript','["구현"]','Bronze5','2026-02-01 10:00:00','api');

-- ※ 나머지 ~450건은 generate_seed.py (하단 Python 스크립트 참고)로 생성


-- =============================================================
-- [7] learning_stats — 30건 (학생 10명 × 언어 + 태그 복합)
-- =============================================================
INSERT INTO learning_stats
  (user_id, stat_type, stat_key, total_count, solved_count, failed_count, correct_rate, last_solved_at)
VALUES
-- 학생 1 (김민준) — Python 강세, DP 취약
  (1,'language','Python',  20,18,2, 90.0,'2026-02-19 11:00:00'),
  (1,'algo_tag','구현',     2, 2,0,100.0,'2026-02-01 10:30:00'),
  (1,'algo_tag','정렬',     2, 2,0,100.0,'2026-02-03 09:00:00'),
  (1,'algo_tag','DP',       6, 4,2, 66.7,'2026-02-19 11:00:00'),
  (1,'algo_tag','BFS',      2, 2,0,100.0,'2026-02-06 11:00:00'),
  (1,'algo_tag','그래프',   1, 1,0,100.0,'2026-02-05 10:00:00'),
  (1,'algo_tag','그리디',   2, 2,0,100.0,'2026-02-13 11:00:00'),

-- 학생 2 (이서연) — DP 강세
  (2,'language','Python',  10, 9,1, 90.0,'2026-02-08 11:00:00'),
  (2,'language','Java',     1, 0,1,  0.0,'2026-02-09 09:00:00'),
  (2,'algo_tag','DP',       3, 3,0,100.0,'2026-02-04 09:00:00'),
  (2,'algo_tag','BFS',      2, 2,0,100.0,'2026-02-06 09:00:00'),
  (2,'algo_tag','그래프',   1, 1,0,100.0,'2026-02-07 10:00:00'),

-- 학생 3 (박지호) — Java 주력, DP 취약
  (3,'language','Java',    10, 8,2, 80.0,'2026-02-09 10:00:00'),
  (3,'algo_tag','정렬',     2, 2,0,100.0,'2026-02-03 10:00:00'),
  (3,'algo_tag','DP',       2, 0,2,  0.0,'2026-02-07 11:00:00'),
  (3,'algo_tag','그리디',   2, 2,0,100.0,'2026-02-09 10:00:00'),
  (3,'algo_tag','그래프',   1, 1,0,100.0,'2026-02-05 09:00:00'),

-- 학생 4~10 기본값
  (4, 'language','JavaScript',1,1,0,100.0,'2026-02-01 10:00:00'),
  (5, 'language','Python',    1,1,0,100.0,'2026-02-01 10:00:00'),
  (6, 'language','C++',       1,1,0,100.0,'2026-02-01 10:00:00'),
  (7, 'language','Python',    1,1,0,100.0,'2026-02-01 10:00:00'),
  (8, 'language','Python',    1,1,0,100.0,'2026-02-01 10:00:00'),
  (9, 'language','Python',    1,1,0,100.0,'2026-02-01 10:00:00'),
  (10,'language','JavaScript',1,1,0,100.0,'2026-02-01 10:00:00');


-- =============================================================
-- [8] job_postings — 6건 (기업 2개 × 공고 3개)
-- =============================================================
INSERT INTO job_postings
  (company_id, title, description, required_skills, preferred_skills, job_role, career_level, deadline, is_active)
VALUES
-- 넥스트소프트
  (1, '백엔드 개발자 (신입/경력)',
   'Django 또는 FastAPI 기반 REST API를 개발하며, 데이터베이스 설계와 서버 최적화를 담당합니다.',
   '["Python","Django","MySQL","REST API","Git"]',
   '["Docker","Redis","AWS","FastAPI"]',
   '백엔드 개발자', 'new', '2026-05-31', 1),

  (1, 'AI/ML 엔지니어 (신입)',
   '추천 시스템 및 자연어 처리 모델을 개발하고, 프로덕션 배포를 경험합니다.',
   '["Python","PyTorch","scikit-learn","SQL"]',
   '["LLM","RAG","AWS SageMaker","MLflow"]',
   'AI 개발자', 'new', '2026-05-31', 1),

  (1, '풀스택 개발자 (주니어)',
   'React 프론트엔드와 Django 백엔드를 함께 개발합니다.',
   '["Python","Django","JavaScript","React","MySQL"]',
   '["TypeScript","Docker","GraphQL"]',
   '풀스택 개발자', 'junior', '2026-04-30', 1),

-- 데이터브릿지
  (2, '데이터 엔지니어 (신입/경력)',
   'ETL 파이프라인 설계 및 데이터 레이크 구축을 담당합니다.',
   '["Python","SQL","Spark","Airflow","AWS"]',
   '["Kafka","dbt","Redshift","Terraform"]',
   '데이터 엔지니어', 'any', '2026-06-30', 1),

  (2, '데이터 분석가 (신입)',
   'SQL 기반 데이터 분석과 시각화 대시보드를 개발합니다.',
   '["SQL","Python","Tableau","Excel"]',
   '["R","Power BI","dbt"]',
   '데이터 분석가', 'new', '2026-05-15', 1),

  (2, 'ML 플랫폼 엔지니어',
   'ML 파이프라인 자동화 및 모델 서빙 인프라를 구축합니다.',
   '["Python","Kubernetes","Docker","MLflow","SQL"]',
   '["Kubeflow","Spark","Kafka","Terraform"]',
   'ML 엔지니어', 'junior', '2026-06-30', 1);


-- =============================================================
-- [9] matches — 20건 (취업 지망 학생 3명 중심)
-- =============================================================
INSERT INTO matches (user_id, posting_id, match_score, status, applied_at)
VALUES
-- 학생 1 (백엔드 지망) → 백엔드·풀스택 공고 매칭
  (1, 1, 87.5, 'applied',     '2026-03-05 14:00:00'),
  (1, 3, 72.3, 'scrapped',    NULL),
  (1, 2, 45.0, 'viewed',      NULL),
  (1, 4, 38.2, 'recommended', NULL),

-- 학생 3 (데이터 엔지니어 지망) → 데이터 공고 매칭
  (3, 4, 91.2, 'applied',     '2026-03-06 10:00:00'),
  (3, 5, 78.4, 'scrapped',    NULL),
  (3, 6, 65.1, 'viewed',      NULL),
  (3, 1, 42.8, 'recommended', NULL),

-- 학생 6 (DevOps 지망) → 인프라 관련 공고
  (6, 6, 69.3, 'applied',     '2026-03-07 11:00:00'),
  (6, 4, 58.7, 'viewed',      NULL),
  (6, 1, 51.2, 'recommended', NULL),

-- 공부 지망 학생들도 추천 공고 표시 (status=recommended)
  (2, 2, 82.1, 'recommended', NULL),
  (2, 6, 71.5, 'recommended', NULL),
  (4, 3, 65.8, 'recommended', NULL),
  (5, 1, 78.9, 'recommended', NULL),
  (7, 2, 88.4, 'recommended', NULL),
  (8, 4, 74.6, 'recommended', NULL),
  (9, 1, 81.2, 'recommended', NULL),
  (10,3, 59.3, 'recommended', NULL),
  (2, 4, 67.8, 'viewed',      NULL);


-- =============================================================
-- [10] posts — 5건 (관리자 작성)
-- =============================================================
INSERT INTO posts (author_id, category, title, content, is_pinned)
VALUES
  (14, 'notice',  '[공지] ELAW 플랫폼 정식 오픈 안내',
   'ELAW 플랫폼이 2026년 3월 1일 정식 오픈했습니다. 회원가입 후 목표 조사를 완료하면 AI 맞춤 커리큘럼을 즉시 받아볼 수 있습니다. 많은 이용 바랍니다.',
   1),

  (14, 'notice',  '[공지] 백준 계정 연동 방법 안내',
   '프로필 페이지 → 외부 플랫폼 연동 → 백준 ID 입력 순서로 연동할 수 있습니다. 연동 후 24시간 내에 풀이 이력이 자동으로 분석됩니다.',
   0),

  (15, 'contest', '[대회] 2026 ICPC 아시아 지역 예선 안내',
   '2026년 ICPC 아시아 지역 예선이 9월에 개최될 예정입니다. ELAW 공부 페이지에서 ICPC 대비 커리큘럼을 신청할 수 있습니다.',
   0),

  (15, 'contest', '[대회] 카카오 코딩테스트 일정 공유',
   '카카오 2026 하반기 공개채용 코딩테스트 일정이 공개되었습니다. ELAW 취약점 분석으로 맞춤 준비하세요.',
   0),

  (14, 'event',   '[이벤트] 첫 포트폴리오 생성 이벤트',
   '3월 한 달간 ELAW에서 처음으로 포트폴리오를 생성한 분들께 소정의 혜택을 드립니다. 지금 바로 포트폴리오를 만들어 보세요!',
   0);


-- =============================================================
-- 확인 쿼리
-- =============================================================
SELECT '=== 시드 데이터 입력 완료 ===' AS status;

SELECT
  (SELECT COUNT(*) FROM users)          AS users,
  (SELECT COUNT(*) FROM companies)      AS companies,
  (SELECT COUNT(*) FROM platform_links) AS platform_links,
  (SELECT COUNT(*) FROM user_goals)     AS user_goals,
  (SELECT COUNT(*) FROM curricula)      AS curricula,
  (SELECT COUNT(*) FROM solve_history)  AS solve_history,
  (SELECT COUNT(*) FROM learning_stats) AS learning_stats,
  (SELECT COUNT(*) FROM job_postings)   AS job_postings,
  (SELECT COUNT(*) FROM matches)        AS matches,
  (SELECT COUNT(*) FROM posts)          AS posts;
