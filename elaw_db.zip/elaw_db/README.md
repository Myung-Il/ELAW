# ELAW — DB/AI 모듈 README
작성자: DB/AI 담당 (오) | 최종 수정: 2026-03-22

---

## 디렉토리 구조

```
elaw_db/
├── sql/
│   └── schema_v1.sql          # 전체 MySQL DDL (12테이블 + 2뷰)
│
├── migrations/
│   └── models.py              # Django ORM 모델 정의 (core/models.py 로 복사)
│
├── seed/
│   ├── seed_data.sql          # 기본 시드 데이터 (15명, 공고 6건 등)
│   ├── seed_solve_history.sql # 풀이 이력 ~350건 (generate_seed.py 출력)
│   └── generate_seed.py       # 더미 데이터 생성 스크립트
│
├── ai_module/
│   └── gemini_client.py       # Gemini API 연동 + 5개 AI 기능 모듈
│
├── etl/
│   └── platform_collector.py  # 백준·GitHub ETL 파이프라인
│
└── erd_docs/
    └── erd_v1.dbml            # ERD DBML (dbdiagram.io 붙여넣기용)
```

---

## Sprint별 완료 항목

### ✅ Sprint 1 (3월 1~2주) — DB 설계
- [x] 전체 12개 테이블 스키마 확정 (`schema_v1.sql`)
- [x] ERD DBML 작성 (`erd_v1.dbml` → dbdiagram.io 업로드)
- [x] Django ORM 모델 작성 (`models.py`)
- [x] 인덱스 전략 포함

### ✅ Sprint 2 (3월 3~4주) — 더미 데이터
- [x] 시드 데이터 작성 (`seed_data.sql`)
  - users 15건, companies 3건, platform_links 10건
  - user_goals 10건, curricula 10건 (JSON 구조 포함)
  - solve_history 50건 + 추가 ~350건 (`seed_solve_history.sql`)
  - learning_stats 24건, job_postings 6건, matches 20건, posts 5건
- [x] 더미 데이터 생성 스크립트 (`generate_seed.py`)

### ✅ Sprint 3 (4월 1~2주) — AI 모듈
- [x] Gemini API 연동 구조 (`gemini_client.py`)
  - 커리큘럼 생성, 취약점 분석, 포트폴리오 생성
  - 채용 매칭 점수, 문제 추천 — 5개 기능 완성
- [x] 재시도 로직 (최대 3회), JSON 파싱, ai_logs 저장
- [x] Mock 응답으로 API 키 없이 개발 가능

### ✅ Sprint 4 (4월 3주~5월 1주) — ETL 파이프라인
- [x] 백준 수집 (`BaekjoonExtractor`) — solved.ac API
- [x] GitHub 수집 (`GitHubExtractor`) — REST API v3
- [x] 정규화 (`DataTransformer`) — 언어명, 태그 한국어 변환
- [x] DB 적재 (`DataLoader`) — INSERT IGNORE, UPSERT
- [x] Django management command 뼈대 (`sync_platforms`, `rebuild_stats`)

---

## 실행 방법

### 1. DB 초기화
```bash
mysql -u root -p -e "CREATE DATABASE elaw_db CHARACTER SET utf8mb4;"
mysql -u root -p elaw_db < sql/schema_v1.sql
mysql -u root -p elaw_db < seed/seed_data.sql
python3 seed/generate_seed.py | mysql -u root -p elaw_db
```

### 2. Django 연동
```bash
# core/models.py 에 migrations/models.py 내용 복사
cp migrations/models.py ../elaw/core/models.py

# 마이그레이션 생성 및 적용
python manage.py makemigrations core
python manage.py migrate
```

### 3. AI 모듈 테스트
```bash
export GEMINI_API_KEY=your_api_key_here
python3 ai_module/gemini_client.py
```

### 4. ETL 배치 실행
```bash
# 전체 사용자 동기화
python manage.py sync_platforms

# 특정 사용자만
python manage.py sync_platforms --user 1

# learning_stats 재집계
python manage.py rebuild_stats
```

### 5. ERD 확인
- `erd_docs/erd_v1.dbml` 내용을 https://dbdiagram.io 에 붙여넣기

---

## 환경변수
| 변수 | 설명 | 예시 |
|------|------|------|
| `GEMINI_API_KEY` | Gemini 1.5 Pro API 키 | `AIzaSy...` |
| `DB_HOST` | MySQL 호스트 | `localhost` |
| `DB_NAME` | DB 이름 | `elaw_db` |
| `DB_USER` | DB 사용자 | `elaw_user` |
| `DB_PASSWORD` | DB 비밀번호 | `...` |
| `GITHUB_TOKEN` | GitHub Personal Access Token | `ghp_...` |

---

## 백엔드 팀 전달 체크리스트
- [ ] `schema_v1.sql` 검토 완료 (김건)
- [ ] `models.py` ORM 모델 이상 없음 확인 (김건)
- [ ] `seed_data.sql` 로컬 DB 적용 확인 (전원)
- [ ] Gemini API 키 환경변수 설정 (팀장 김태)
- [ ] `sync_platforms` management command Django 앱에 등록 (김건)
