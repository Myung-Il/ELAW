"""
ELAW Platform — DB/AI 통합 테스트 스위트
파일    : test/test_db_ai.py
작성자  : DB/AI 담당 (오)  |  Sprint 6

커버 범위:
  1. 스키마 무결성 검증 (테이블·컬럼·제약)
  2. 시드 데이터 정합성 (외래키 참조, 집계 일치)
  3. AI 모듈 입출력 계약 (JSON 스키마 검증)
  4. ETL 파이프라인 E2E
  5. 매칭 점수 계산 경계값 테스트
  6. Redis 캐시 HIT/MISS/무효화

실행:
  python3 -m pytest test/test_db_ai.py -v
  python3 test/test_db_ai.py           (pytest 없을 때)
"""

from __future__ import annotations

import json
import logging
import sys
import traceback
from dataclasses import dataclass
from typing import Callable


# ─────────────────────────────────────────────────
# 경량 테스트 러너 (pytest 없이 동작)
# ─────────────────────────────────────────────────

@dataclass
class TestResult:
    name:    str
    passed:  bool
    message: str = ""


class SimpleRunner:
    def __init__(self):
        self.results: list[TestResult] = []

    def run(self, name: str, fn: Callable) -> None:
        try:
            fn()
            self.results.append(TestResult(name, True))
        except AssertionError as e:
            self.results.append(TestResult(name, False, str(e)))
        except Exception as e:
            self.results.append(TestResult(name, False, f"{type(e).__name__}: {e}"))

    def summary(self) -> bool:
        passed = sum(1 for r in self.results if r.passed)
        total  = len(self.results)
        print(f"\n{'='*62}")
        print(f"  테스트 결과: {passed}/{total} 통과")
        print(f"{'='*62}")
        for r in self.results:
            icon = "✅" if r.passed else "❌"
            msg  = f"  — {r.message}" if not r.passed else ""
            print(f"  {icon}  {r.name}{msg}")
        print(f"{'='*62}")
        return passed == total


runner = SimpleRunner()


# =============================================================
# 1. 스키마 무결성 검증
# =============================================================

def test_schema_table_list():
    """schema_v1.sql 에 정의된 12개 테이블이 모두 존재하는지 확인"""
    expected = {
        "users", "companies", "platform_links",
        "user_goals", "curricula",
        "solve_history", "learning_stats",
        "portfolios", "job_postings", "matches",
        "posts", "ai_logs",
    }
    # 실제 DB 확인 (배포 시 활성화)
    # from django.db import connection
    # with connection.cursor() as c:
    #     c.execute("SHOW TABLES")
    #     actual = {row[0] for row in c.fetchall()}
    # assert expected.issubset(actual), f"누락 테이블: {expected - actual}"

    # Mock: schema_v1.sql 파일에서 CREATE TABLE 파싱
    with open("sql/schema_v1.sql", encoding="utf-8") as f:
        content = f.read()
    found = set()
    for line in content.splitlines():
        line = line.strip().upper()
        if line.startswith("CREATE TABLE") and "IF NOT EXISTS" not in line:
            parts = line.split()
            if len(parts) >= 3:
                tbl = parts[2].strip("`(").lower()
                if tbl not in ("schema_versions", "v_user_solve_summary", "v_platform_stats"):
                    found.add(tbl)
    missing = expected - found
    assert not missing, f"누락 테이블: {missing}"

runner.run("스키마 — 12개 테이블 정의 확인", test_schema_table_list)


def test_schema_critical_columns():
    """핵심 테이블의 필수 컬럼이 DDL에 포함되어 있는지 확인"""
    with open("sql/schema_v1.sql", encoding="utf-8") as f:
        content = f.read()

    checks = [
        ("users",         "password_hash"),
        ("users",         "ai_consent"),
        ("solve_history", "algo_tags"),
        ("solve_history", "UNIQUE KEY uq_solve_user_platform_problem"),
        ("learning_stats","correct_rate"),
        ("learning_stats","UNIQUE KEY uq_stats_user_type_key"),
        ("matches",       "match_score"),
        ("portfolios",    "public_slug"),
        ("ai_logs",       "latency_ms"),
    ]
    for table, col in checks:
        assert col in content, f"누락: {table}.{col}"

runner.run("스키마 — 필수 컬럼 및 인덱스 존재 확인", test_schema_critical_columns)


def test_schema_views():
    """통계 뷰 2개가 DDL에 정의되어 있는지 확인"""
    with open("sql/schema_v1.sql", encoding="utf-8") as f:
        content = f.read()
    assert "v_user_solve_summary" in content
    assert "v_platform_stats"     in content

runner.run("스키마 — 통계 뷰 2개 정의 확인", test_schema_views)


# =============================================================
# 2. 시드 데이터 정합성
# =============================================================

def test_seed_user_counts():
    """seed_data.sql 에 학생 10명·기업 3명·관리자 2명이 있는지 확인"""
    with open("seed/seed_data.sql", encoding="utf-8") as f:
        content = f.read()

    # INSERT 문에서 role 값 카운팅
    student_count = content.count("'student'")
    company_count = content.count("'company'")
    admin_count   = content.count("'admin'")

    assert student_count >= 10, f"학생 수 부족: {student_count}"
    assert company_count >= 3,  f"기업담당자 수 부족: {company_count}"
    assert admin_count   >= 2,  f"관리자 수 부족: {admin_count}"

runner.run("시드 — users 역할별 수 확인 (학생10·기업3·관리자2)", test_seed_user_counts)


def test_seed_job_postings():
    """채용 공고 6건이 시드에 있는지 확인"""
    with open("seed/seed_data.sql", encoding="utf-8") as f:
        content = f.read()
    assert "넥스트소프트" in content
    assert "데이터브릿지" in content
    # job_postings INSERT 내 title 6개 확인
    titles = ["백엔드 개발자", "AI/ML 엔지니어", "풀스택 개발자",
              "데이터 엔지니어", "데이터 분석가", "ML 플랫폼 엔지니어"]
    for t in titles:
        assert t in content, f"공고 누락: {t}"

runner.run("시드 — job_postings 6건 확인", test_seed_job_postings)


def test_seed_curricula_json():
    """curricula JSON 구조가 올바른지 확인 (첫 번째 커리큘럼)"""
    with open("seed/seed_data.sql", encoding="utf-8") as f:
        content = f.read()
    # 첫 번째 curriculum JSON 추출 (단순 파싱)
    assert '"total_weeks"' in content
    assert '"weeks"'       in content
    assert '"theme"'       in content
    assert '"estimated_hours"' in content

runner.run("시드 — curricula JSON 구조 확인", test_seed_curricula_json)


def test_seed_generate_script():
    """generate_seed.py 가 실행되고 SQL을 생성하는지 확인"""
    import subprocess, sys
    result = subprocess.run(
        [sys.executable, "seed/generate_seed.py"],
        capture_output=True, text=True, timeout=10
    )
    assert result.returncode == 0, f"generate_seed.py 실행 오류: {result.stderr}"
    output = result.stdout
    assert "INSERT IGNORE INTO solve_history" in output
    assert output.count("'baekjoon'") >= 50, f"풀이 이력 부족: {output.count('baekjoon')}건"

runner.run("시드 — generate_seed.py 실행 및 풀이 이력 50건+ 생성", test_seed_generate_script)


# =============================================================
# 3. AI 모듈 JSON 스키마 검증
# =============================================================

sys.path.insert(0, ".")
from core.ai.gemini_client import AiService, UserProfile

_service = AiService()
_profile = UserProfile(
    user_id=1, name="테스트", goal_type="job",
    field="컴퓨터", job_role="백엔드 개발자", duration_weeks=8,
    language_stats=[{"lang":"Python","solved":40,"total":45,"rate":88.9}],
    algo_tag_stats=[
        {"tag":"DP","solved":5,"total":10,"rate":50.0},
        {"tag":"BFS","solved":8,"total":9,"rate":88.9},
    ],
    total_solved=45, github_repos=3, github_commits=60,
)


def test_ai_curriculum_schema():
    """커리큘럼 결과가 필수 키를 포함하는지 확인"""
    result = _service.client.generate_curriculum(_profile)
    assert result.status == "success", f"AI 호출 실패: {result.error_message}"
    data = result.data
    assert data is not None,              "JSON 파싱 실패"
    assert "total_weeks" in data,         "total_weeks 누락"
    assert "weeks"       in data,         "weeks 누락"
    assert isinstance(data["weeks"], list), "weeks가 리스트가 아님"
    assert len(data["weeks"]) > 0,        "weeks가 비어있음"
    week0 = data["weeks"][0]
    assert "week"                in week0
    assert "theme"               in week0
    assert "tasks"               in week0
    assert "estimated_hours"     in week0

runner.run("AI — 커리큘럼 JSON 스키마 검증", test_ai_curriculum_schema)


def test_ai_weakness_schema():
    """취약점 분석 결과 스키마 확인"""
    result = _service.client.analyze_weakness(_profile)
    assert result.status == "success"
    data = result.data
    assert "weak_tags"       in data
    assert "overall_comment" in data
    assert isinstance(data["weak_tags"], list)
    if data["weak_tags"]:
        w = data["weak_tags"][0]
        assert "tag"          in w
        assert "correct_rate" in w
        assert "advice"       in w

runner.run("AI — 취약점 분석 JSON 스키마 검증", test_ai_weakness_schema)


def test_ai_portfolio_schema():
    """포트폴리오 생성 결과 스키마 확인"""
    result = _service.client.generate_portfolio(_profile)
    assert result.status == "success"
    data = result.data
    assert "sections" in data
    types = {s["type"] for s in data["sections"]}
    assert "summary" in types, "summary 섹션 누락"
    assert "skills"  in types, "skills 섹션 누락"

runner.run("AI — 포트폴리오 JSON 스키마 검증 (summary·skills 필수)", test_ai_portfolio_schema)


def test_ai_match_score_range():
    """매칭 점수가 0~100 범위 내인지 확인"""
    result = _service.client.calculate_match_score(
        _profile,
        required_skills=["Python", "Django", "MySQL"],
        preferred_skills=["Docker", "Redis"],
        job_role="백엔드 개발자"
    )
    assert result.status == "success"
    score = float(result.data.get("match_score", -1))
    assert 0 <= score <= 100, f"점수 범위 이탈: {score}"

runner.run("AI — 매칭 점수 0~100 범위 검증", test_ai_match_score_range)


def test_ai_recommendation_count():
    """추천 문제가 1~5개 범위 내인지 확인"""
    result = _service.client.recommend_problems(_profile)
    assert result.status == "success"
    problems = result.data.get("problems", [])
    assert 1 <= len(problems) <= 5, f"추천 문제 수 이상: {len(problems)}"
    for p in problems:
        assert "id"     in p
        assert "title"  in p
        assert "reason" in p

runner.run("AI — 추천 문제 1~5개 및 필드 검증", test_ai_recommendation_count)


# =============================================================
# 4. ETL 파이프라인 E2E
# =============================================================

from core.etl.platform_collector import (
    ETLPipeline, BaekjoonExtractor, GitHubExtractor,
    DataTransformer, BAEKJOON_TIER_MAP, TAG_KO_MAP
)


def test_etl_baekjoon_mock():
    """백준 수집 Mock이 정상 동작하는지 확인"""
    extractor = BaekjoonExtractor()
    problems  = extractor.get_solved_problems("test_handle")
    assert isinstance(problems, list), "반환값이 리스트가 아님"
    assert len(problems) > 0, "수집된 문제가 없음"
    p = problems[0]
    assert "problemId"   in p
    assert "titleKo"     in p
    assert "level"       in p

runner.run("ETL — 백준 수집 Mock 동작 확인", test_etl_baekjoon_mock)


def test_etl_github_mock():
    """GitHub 수집 Mock이 정상 동작하는지 확인"""
    extractor = GitHubExtractor()
    summary   = extractor.get_summary("test_user")
    assert "repo_count"    in summary
    assert "total_commits" in summary
    assert "top_language"  in summary
    assert summary["repo_count"] > 0

runner.run("ETL — GitHub 수집 Mock 동작 확인", test_etl_github_mock)


def test_etl_transformer_tier():
    """solved.ac tier → 난이도 문자열 변환 확인"""
    t = DataTransformer()
    raw = {"problemId": 1260, "titleKo": "DFS와 BFS", "level": 9,
           "tags": [{"key": "bfs"}, {"key": "graphs"}]}
    record = t.baekjoon_problem_to_record(user_id=1, raw_problem=raw)
    assert record.difficulty == "Silver2",  f"난이도 변환 오류: {record.difficulty}"
    assert "BFS"     in record.algo_tags,   "BFS 태그 누락"
    assert "그래프"  in record.algo_tags,   "그래프 태그 누락"
    assert record.platform    == "baekjoon"
    assert record.problem_id  == "1260"

runner.run("ETL — tier→난이도 변환 및 태그 한국어화 검증", test_etl_transformer_tier)


def test_etl_tier_map_complete():
    """BAEKJOON_TIER_MAP 이 Bronze~Diamond 전체를 포함하는지 확인"""
    assert BAEKJOON_TIER_MAP[1]  == "Bronze5"
    assert BAEKJOON_TIER_MAP[10] == "Silver1"
    assert BAEKJOON_TIER_MAP[15] == "Gold1"
    assert BAEKJOON_TIER_MAP[20] == "Platinum1"

runner.run("ETL — BAEKJOON_TIER_MAP 전체 매핑 확인", test_etl_tier_map_complete)


def test_etl_language_normalize():
    """언어명 정규화가 올바른지 확인"""
    t = DataTransformer()
    assert t.normalize_language("Python3")   == "Python"
    assert t.normalize_language("java11")    == "Java"
    assert t.normalize_language("C++17")     == "C++"
    assert t.normalize_language("node.js")   == "JavaScript"

runner.run("ETL — 언어명 정규화 (Python3→Python 등) 검증", test_etl_language_normalize)


def test_etl_full_pipeline():
    """ETL 전체 파이프라인 실행 후 CollectionResult 반환 확인"""
    pipeline = ETLPipeline()
    result   = pipeline.run_user(user_id=1, boj_handle="test", github_login="test")
    boj      = result.get("boj")
    assert boj is not None,              "boj 결과 없음"
    assert boj.new_records >= 0,         "new_records 음수"
    assert boj.success_rate() >= 0,      "success_rate 음수"
    assert "github" in result,           "github 결과 없음"
    assert "repo_count" in result["github"]

runner.run("ETL — 전체 파이프라인 E2E (수집→적재→집계)", test_etl_full_pipeline)


# =============================================================
# 5. 매칭 점수 경계값 테스트
# =============================================================

from core.matching.match_engine import MatchEngine, CandidateVector, PostingVector, RuleScorer


def test_match_perfect_score():
    """모든 required·preferred 스킬 보유 시 100점에 가까워야 함"""
    scorer = RuleScorer()
    cand = CandidateVector(
        user_id=99, job_role="백엔드",
        languages={"python": 95.0, "django": 90.0, "mysql": 88.0,
                   "js": 80.0, "docker": 85.0, "redis": 82.0, "aws": 78.0},
        algo_tags={}, total_solved=400,
        github_repos=10, github_commits=500,
    )
    post = PostingVector(
        posting_id=1, job_role="백엔드 개발자", career_level="any",
        required_skills=["Python", "Django", "MySQL"],
        preferred_skills=["Docker", "Redis", "AWS"],
    )
    result = scorer.score(cand, post)
    assert result.rule_score >= 85.0, f"완벽 매칭인데 점수 낮음: {result.rule_score}"
    assert not result.missing_req,    f"부족 스킬이 있으면 안 됨: {result.missing_req}"

runner.run("매칭 — 완벽 매칭 시 85점 이상 확인", test_match_perfect_score)


def test_match_zero_skills():
    """스킬이 전혀 없을 때 보너스 점수만 있어야 함"""
    scorer = RuleScorer()
    cand = CandidateVector(
        user_id=1, job_role="기타",
        languages={}, algo_tags={}, total_solved=0,
        github_repos=0, github_commits=0,
    )
    post = PostingVector(
        posting_id=1, job_role="백엔드", career_level="any",
        required_skills=["Python", "Django"],
        preferred_skills=["Docker"],
    )
    result = scorer.score(cand, post)
    assert result.rule_score == 0.0, f"스킬 없는데 점수 양수: {result.rule_score}"
    assert len(result.missing_req) == 2

runner.run("매칭 — 스킬 없을 때 0점 확인", test_match_zero_skills)


def test_match_score_capped_100():
    """점수가 100을 초과하지 않는지 확인"""
    scorer = RuleScorer()
    cand = CandidateVector(
        user_id=1, job_role="any",
        languages={f"skill{i}": 100.0 for i in range(20)},
        algo_tags={}, total_solved=999,
        github_repos=50, github_commits=9999,
    )
    post = PostingVector(
        posting_id=1, job_role="any", career_level="any",
        required_skills=[f"skill{i}" for i in range(20)],
        preferred_skills=[f"skill{i}" for i in range(20)],
    )
    result = scorer.score(cand, post)
    assert result.rule_score <= 100.0, f"점수 100 초과: {result.rule_score}"

runner.run("매칭 — 점수 100점 상한 검증", test_match_score_capped_100)


def test_match_skill_alias():
    """Python3 → python 별칭 정규화가 매칭에 적용되는지 확인"""
    from core.matching.match_engine import normalize_skill
    assert normalize_skill("Python3") == "python"
    assert normalize_skill("node.js") == "js"
    assert normalize_skill("PostgreSQL") == "postgres"

runner.run("매칭 — 스킬 별칭(Python3=python) 정규화 확인", test_match_skill_alias)


# =============================================================
# 6. Redis 캐시 HIT/MISS/무효화
# =============================================================

from core.cache.redis_cache import ElawCache


def test_cache_hit_miss():
    """캐시 SET 후 GET 은 HIT, 없는 키는 MISS"""
    cache = ElawCache()
    data  = {"total_solved": 100, "week": 10}
    cache.set_dashboard(user_id=777, data=data)
    hit  = cache.get_dashboard(user_id=777)
    miss = cache.get_dashboard(user_id=888)
    assert hit  is not None,        "캐시 HIT 실패"
    assert hit["total_solved"] == 100
    assert miss is None,            "존재하지 않는 키가 MISS가 아님"

runner.run("캐시 — SET 후 HIT, 없는 키 MISS 확인", test_cache_hit_miss)


def test_cache_invalidate():
    """invalidate_dashboard 호출 후 MISS가 되는지 확인"""
    cache = ElawCache()
    cache.set_dashboard(user_id=1, data={"x": 1})
    assert cache.get_dashboard(user_id=1) is not None, "무효화 전 HIT 실패"
    cache.invalidate_dashboard(user_id=1)
    assert cache.get_dashboard(user_id=1) is None,     "무효화 후 MISS 실패"

runner.run("캐시 — invalidate_dashboard 후 MISS 확인", test_cache_invalidate)


def test_cache_token_blacklist():
    """토큰 블랙리스트 등록 및 조회"""
    cache = ElawCache()
    jti   = "test-refresh-token-jti-999"
    assert not cache.is_token_blacklisted(jti),  "등록 전인데 블랙리스트로 판단"
    cache.blacklist_token(jti)
    assert cache.is_token_blacklisted(jti),      "등록 후인데 블랙리스트 아님"

runner.run("캐시 — 토큰 블랙리스트 등록/조회 검증", test_cache_token_blacklist)


def test_cache_flush_user():
    """flush_user 후 모든 캐시가 삭제되는지 확인"""
    cache = ElawCache()
    uid   = 555
    cache.set_dashboard(user_id=uid, data={"x": 1})
    cache.set_weakness(user_id=uid,  data={"y": 2})
    cache.flush_user(uid)
    assert cache.get_dashboard(user_id=uid) is None
    assert cache.get_weakness(user_id=uid)  is None

runner.run("캐시 — flush_user 후 전체 캐시 삭제 확인", test_cache_flush_user)



# =============================================================
# 7. 스키마 추가 검증 (버그픽스 확인)
# =============================================================

def test_schema_drop_views_before_tables():
    """DROP VIEW 구문이 DROP TABLE 보다 앞에 있는지 확인"""
    with open("sql/schema_v1.sql", encoding="utf-8") as f:
        content = f.read()
    view_pos  = content.find("DROP VIEW")
    table_pos = content.find("DROP TABLE")
    assert view_pos  != -1,          "DROP VIEW 구문 누락"
    assert table_pos != -1,          "DROP TABLE 구문 누락"
    assert view_pos < table_pos,     "DROP VIEW 가 DROP TABLE 보다 뒤에 있음"

runner.run("스키마 — DROP VIEW가 DROP TABLE 앞에 있음 확인", test_schema_drop_views_before_tables)


def test_schema_drop_schema_versions():
    """schema_versions 테이블도 DROP 대상에 포함되어 있는지 확인"""
    with open("sql/schema_v1.sql", encoding="utf-8") as f:
        content = f.read()
    assert "DROP TABLE IF EXISTS schema_versions" in content,         "schema_versions DROP 누락"

runner.run("스키마 — schema_versions DROP 포함 확인", test_schema_drop_schema_versions)


def test_schema_time_spent_unsigned():
    """time_spent_min 컬럼이 UNSIGNED 타입인지 확인 (음수 방지)"""
    with open("sql/schema_v1.sql", encoding="utf-8") as f:
        content = f.read()
    assert "SMALLINT UNSIGNED" in content,         "time_spent_min이 UNSIGNED가 아님 — 음수 저장 가능"

runner.run("스키마 — time_spent_min UNSIGNED 타입 확인", test_schema_time_spent_unsigned)


def test_schema_view_null_safe():
    """v_user_solve_summary 뷰가 COALESCE/CASE로 NULL-safe 집계하는지 확인"""
    with open("sql/schema_v1.sql", encoding="utf-8") as f:
        content = f.read()
    assert "COALESCE" in content, "뷰에 COALESCE 누락 — NULL 집계 오류 가능"
    assert "CASE" in content and "WHEN COUNT(sh.id) = 0" in content,         "뷰에 0분모 CASE 처리 누락"

runner.run("스키마 — v_user_solve_summary NULL-safe 집계 확인", test_schema_view_null_safe)


# =============================================================
# 8. 시드 데이터 추가 검증
# =============================================================

def test_seed_no_placeholder_hashes():
    """시드 데이터에 PLACEHOLDER 해시가 남아있지 않은지 확인"""
    with open("seed/seed_data.sql", encoding="utf-8") as f:
        content = f.read()
    assert "PLACEHOLDER" not in content,         "PLACEHOLDER 해시가 아직 남아있음 — 실제 해시로 교체 필요"
    assert "##DEV##" in content,         "개발용 해시(##DEV##)가 없음 — 비밀번호 교체가 안 됨"

runner.run("시드 — PLACEHOLDER 해시 제거 및 DEV 해시 존재 확인", test_seed_no_placeholder_hashes)


def test_seed_dev_hash_correct_length():
    """##DEV## 해시가 60자 고정 길이인지 확인"""
    import re
    with open("seed/seed_data.sql", encoding="utf-8") as f:
        content = f.read()
    hashes = re.findall(r"'(##DEV##[^']+)'", content)
    assert len(hashes) >= 15, f"해시 수 부족: {len(hashes)}개"
    for h in hashes:
        assert len(h) == 60, f"해시 길이 오류: {h!r} ({len(h)}자)"

runner.run("시드 — 개발용 해시 60자 길이 검증 (15개)", test_seed_dev_hash_correct_length)


# =============================================================
# 9. AI 모듈 추가 검증
# =============================================================

def test_ai_profile_per_user():
    """_load_profile이 user_id별로 다른 프로필을 반환하는지 확인"""
    p1 = AiService._load_profile(1)
    p2 = AiService._load_profile(2)
    p3 = AiService._load_profile(3)
    assert p1.user_id == 1,            "user_id=1 프로필 id 불일치"
    assert p2.user_id == 2,            "user_id=2 프로필 id 불일치"
    assert p3.user_id == 3,            "user_id=3 프로필 id 불일치"
    assert p1.job_role != p2.job_role, "user 1·2가 동일 job_role — Mock 분기 미작동"
    assert p1.name     != p2.name,     "user 1·2가 동일 이름 — Mock 분기 미작동"

runner.run("AI — _load_profile user_id별 다른 프로필 반환 확인", test_ai_profile_per_user)


def test_ai_unknown_user_profile():
    """없는 user_id로 _load_profile 호출 시 기본 프로필 반환 확인"""
    p = AiService._load_profile(9999)
    assert p is not None,        "None 반환 — 기본 프로필 없음"
    assert p.user_id == 9999,    f"user_id 불일치: {p.user_id}"
    assert p.total_solved >= 0,  "total_solved 음수"

runner.run("AI — 없는 user_id 기본 프로필 반환 확인", test_ai_unknown_user_profile)


# =============================================================
# 10. ETL 추가 검증
# =============================================================

def test_etl_language_empty_not_unknown():
    """language 기본값이 'Unknown'이 아닌 빈 문자열 처리인지 확인"""
    from core.etl.platform_collector import DataTransformer
    t = DataTransformer()
    raw = {"problemId": 1000, "titleKo": "A+B", "level": 1, "tags": []}
    # language 미제공 시
    record = t.baekjoon_problem_to_record(user_id=1, raw_problem=raw, language="")
    assert record.language != "Unknown",         "language가 'Unknown'으로 저장됨 — 빈 문자열 또는 None이어야 함"

runner.run("ETL — language 기본값이 Unknown 아님 확인", test_etl_language_empty_not_unknown)


def test_etl_solved_at_provided_used():
    """baekjoon_problem_to_record에 solved_at 제공 시 해당 값 사용 확인"""
    from core.etl.platform_collector import DataTransformer
    from datetime import datetime, timezone
    t = DataTransformer()
    fixed_time = datetime(2026, 1, 15, 12, 0, 0, tzinfo=timezone.utc)
    raw = {"problemId": 1000, "titleKo": "A+B", "level": 1, "tags": []}
    record = t.baekjoon_problem_to_record(user_id=1, raw_problem=raw, solved_at=fixed_time)
    assert record.solved_at == fixed_time,         f"제공한 solved_at이 무시됨: {record.solved_at} != {fixed_time}"

runner.run("ETL — solved_at 제공 시 해당 값 사용 확인", test_etl_solved_at_provided_used)


# =============================================================
# 11. 캐시 추가 검증
# =============================================================

def test_cache_flush_removes_curriculum_with_hash():
    """flush_user가 goal_hash 포함 curriculum 키도 삭제하는지 확인"""
    cache = ElawCache()
    uid   = 42
    # goal_id=7로 커리큘럼 저장 (내부에서 hash 키 생성)
    cache.set_curriculum(user_id=uid, goal_id=7, data={"weeks": []})
    assert cache.get_curriculum(user_id=uid, goal_id=7) is not None,         "저장 후 HIT 실패"
    # flush 후 삭제 확인
    cache.flush_user(uid)
    assert cache.get_curriculum(user_id=uid, goal_id=7) is None,         "flush_user 후에도 curriculum 캐시가 남아있음"

runner.run("캐시 — flush_user가 curriculum:{uid}:{hash} 키 삭제 확인", test_cache_flush_removes_curriculum_with_hash)


def test_cache_health_check_returns_bool():
    """health_check가 항상 bool을 반환하는지 확인"""
    cache  = ElawCache()
    result = cache.health_check()
    assert isinstance(result, bool), f"health_check 반환값이 bool이 아님: {type(result)}"

runner.run("캐시 — health_check bool 반환 타입 확인", test_cache_health_check_returns_bool)


def test_cache_set_returns_bool():
    """set 계열 메서드가 bool을 반환하는지 확인"""
    cache = ElawCache()
    r1 = cache.set_dashboard(user_id=100, data={"x": 1})
    r2 = cache.set_weakness(user_id=100, data={"y": 2})
    assert isinstance(r1, bool), f"set_dashboard 반환값 타입 오류: {type(r1)}"
    assert isinstance(r2, bool), f"set_weakness 반환값 타입 오류: {type(r2)}"
    assert r1 is True, "set_dashboard가 False 반환 (저장 실패)"
    assert r2 is True, "set_weakness가 False 반환 (저장 실패)"

runner.run("캐시 — set 메서드 bool True 반환 확인", test_cache_set_returns_bool)

# =============================================================
# 결과 출력
# =============================================================
if __name__ == "__main__":
    logging.basicConfig(level=logging.WARNING)   # 테스트 중 로그 최소화
    ok = runner.summary()
    sys.exit(0 if ok else 1)
